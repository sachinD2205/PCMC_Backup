import React from "react";

// // Local - Urls
const urls = {
  BaseURL: "http://localhost:8095/hw/api",
  PtaxURLMaster: "http://localhost:8097/ptax/api",
  //AuthURL: "http://localhost:8080/pcmc/auth",
  CfcURLMaster: "http://localhost:8090/cfc/api/master",
  //AuthURL: "http://localhost:8080/pcmc/auth",
};

// UAT - Urls
// // ${urls.BaseURL}
// const urls = {
//   CFCMasterURL: "http://localhost:8090/cfc/api/master",
//   BaseURL: "http://203.129.224.92:5432/HawkerMS/hw/api",
//    PtaxURLMaster: "http://localhost:8097/ptax/api",
//   //AuthURL: "http://localhost:8080/pcmc/auth",
//   //AuthURL: "http://localhost:8080/pcmc/auth",
//   // AuthURL:"http://203.129.224.92:8091/pcmc/auth",
// };

export default urls;
