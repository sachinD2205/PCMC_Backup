import {
  BookFilled,
  BookOutlined,
  CopyFilled,
  FormOutlined,
  MailFilled,
} from "@ant-design/icons";
import { Card } from "@mui/material";
import { breadcrumbsClasses } from "@mui/material";
import FormattedLabel from "../reuseableComponents/FormattedLabel";

export default [
  {
    key: "/login",
    code: "LO",
  },

  {
    label: <FormattedLabel id='dashboard' />,
    key: "/dashboard",
    // icon: GoogleOutlined,
    code: "DB",

    innerCards: [
      {
        title: "HMS",
        key: "hawkerManagementSystem",
        content: "Description",
        icon: FormOutlined,
        clickTo: "/hawkerManagementSystem",
        code: "HMSZ",
      },
    ],
  },

  {
    label: <FormattedLabel id='streetVendorManagmentSystem' />,
    // icon: FormOutlined,
    key: "/hawkerManagementSystem",
    code: "HMS",
    innerCards: [
      {
        title: "master",
        content: "Description",
        icon: BookFilled,
        clickTo: "/hawkerManagementSystem/masters",
        code: "HMSM",
        breadcrumName: "masterPath",
        childrenCards: [
          {
            title: <FormattedLabel id='streetVendorType' />,
            content: "Description",
            icon: BookOutlined,
            clickTo: "/hawkerManagementSystem/masters/hawkerType",
            code: "C-HMSM02",
            breadcrumName: "Hawker Management System / masters / Hawker Type ",
          },

          {
            title: <FormattedLabel id='itemMaster' />,
            content: "Description",
            icon: BookOutlined,
            clickTo: "/hawkerManagementSystem/masters/itemMaster",
            code: "C-HMSM10",
            breadcrumName: "Hawker Management System / masters / Item Master ",
          },
          {
            title: <FormattedLabel id='itemCategoryMaster' />,
            content: "Description",
            icon: BookOutlined,
            clickTo: "/hawkerManagementSystem/masters/itemCategoryMaster",
            code: "C-HMSM11",
            breadcrumName:
              "Hawker Management System / masters / Item Category Master ",
          },

          {
            title: <FormattedLabel id='hawkingZone' />,
            content: "Description",
            icon: BookOutlined,
            clickTo: "/hawkerManagementSystem/masters/hawkingZone",
            code: "C-HMSM06",
            breadcrumName: "Hawker Management System / masters / HawkingZone",
          },

          {
            title: <FormattedLabel id='licenseValidity' />,
            content: "Description",
            icon: BookOutlined,
            clickTo: "/hawkerManagementSystem/masters/licenseValidity",
            code: "C-HMSM10",
            breadcrumName:
              "Hawker Management System / masters / License Validity",
          },

          {
            title: <FormattedLabel id='hawkingZoneWiseFacilities' />,
            content: "Description",
            icon: BookOutlined,
            clickTo:
              "/hawkerManagementSystem/masters/hawkingZoneWiseFacilities",
            code: "C-HMSM13",
            breadcrumName:
              "Hawker Management System / masters / Hawking Zone Wise Facilities",
          },

          {
            title: <FormattedLabel id='serviceTaxCollectionCycle' />,
            content: "Description",
            icon: BookOutlined,
            clickTo:
              "/hawkerManagementSystem/masters/serviceTaxCollectionCycle",
            code: "C-HMSM14",
            breadcrumName:
              "Hawker Management System / masters / service Tax Collection Cycle",
          },

          {
            title: <FormattedLabel id='noHawkingZone' />,
            content: "Description",
            icon: BookOutlined,
            clickTo: "/hawkerManagementSystem/masters/noHawkingZone",
            code: "C-HMSM14",
            breadcrumName:
              "Hawker Management System / masters / No Hawking Zone",
          },
          {
            title: "Streetvendor Applicant Category",
            content: "Description",
            icon: BookOutlined,
            clickTo:
              "/hawkerManagementSystem/masters/streetvendorApplicantCategory",
            code: "C-HMSM14",
            breadcrumName: "Hawker Management System / masters / Hawker Master",
          },
          {
            title: "Hawker Master",
            title: <FormattedLabel id='hawkerMaster' />,
            content: "Description",
            icon: BookOutlined,
            clickTo: "/hawkerManagementSystem/masters/hawkerMaster",
            code: "C-HMSM14",
            breadcrumName: "Hawker Management System / masters / Hawker Master",
          },
          // {
          //   title: "Business Type Master",
          //   content: "Description",
          //   icon: BookOutlined,
          //   clickTo: "/hawkerManagementSystem/masters/businessTypeMaster",
          //   code: "C-HMSM03",
          //   breadcrumName:
          //     "Hawker Management System / masters / Business Type Master ",
          // },
          // {
          //   title: "Business Sub Type",
          //   content: "Description",
          //   icon: BookOutlined,
          //   clickTo: "/hawkerManagementSystem/masters/BusinessSubType",
          //   code: "C-HMSM04",
          //   breadcrumName:
          //     "Hawker Management System / masters / Business Sub Type ",
          // },
          // {
          //   title: "Title",
          //   content: "Description",
          //   icon: BookOutlined,
          //   clickTo: "/hawkerManagementSystem/masters/title",
          //   code: "C-HMSM05",
          //   breadcrumName: "Hawker Management System / masters / title",
          // },
          // {
          //   title: "Cast Category",
          //   content: "Description",
          //   icon: BookOutlined,
          //   clickTo: "/hawkerManagementSystem/masters/castCategory",
          //   code: "C-HMSM08",
          //   breadcrumName: "Hawker Management System / masters / castCategory",
          // },
          // {
          //   title: "Cast Master",
          //   content: "Description",
          //   icon: BookOutlined,
          //   clickTo: "/hawkerManagementSystem/masters/castMaster",
          //   code: "C-HMSM07",
          //   breadcrumName: "Hawker Management System / masters / castMaster",
          // },

          // {
          //   title: "Religion",
          //   content: "Description",
          //   icon: BookOutlined,
          //   clickTo: "/hawkerManagementSystem/masters/religion",
          //   code: "C-HMSM01",
          //   breadcrumName: "Hawker Management System / masters / Religion ",
          // },
          // {
          //   title: "Sub Cast Master",
          //   content: "Description",
          //   icon: BookOutlined,
          //   clickTo: "/hawkerManagementSystem/masters/subCastMaster",
          //   code: "C-HMSM09",
          //   breadcrumName:
          //     "Hawker Management System / masters / Sub Cast Master",
          // },
          // {
          //   title: "Penalty",
          //   content: "Description",
          //   icon: BookOutlined,
          //   clickTo: "/hawkerManagementSystem/masters/penalty",
          //   code: "C-HMSM11",
          //   breadcrumName: "Hawker Management System / masters / Penalty",
          // },
          // {
          //   title: "Bank Master",
          //   content: "Description",
          //   icon: BookOutlined,
          //   clickTo: "/hawkerManagementSystem/masters/BankMaster",
          //   code: "C-HMSM12",
          //   breadcrumName:
          //     "Hawker Management System / masters / Bank Master",
          // },
          // {
          //   title: "Tax Type Master",
          //   content: "Description",
          //   icon: BookOutlined,
          //   clickTo: "/hawkerManagementSystem/masters/taxTypeMaster",
          //   code: "C-HMSM14",
          //   breadcrumName:
          //     "Hawker Management System / masters / Tax Type Master",
          // },
          // {
          //   title: "Tax Name Master",
          //   content: "Description",
          //   icon: BookOutlined,
          //   clickTo: "/hawkerManagementSystem/masters/taxNameMaster",
          //   code: "C-HMSM14",
          //   breadcrumName:
          //     "Hawker Management System / masters / Tax Name Master",
          // },
          // {
          //   title: "Tax Rate Chart Master",
          //   content: "Description",
          //   icon: BookOutlined,
          //   clickTo: "/hawkerManagementSystem/masters/taxRateChartMaster",
          //   code: "C-HMSM14",
          //   breadcrumName:
          //     "Hawker Management System / masters / Tax Rate Chart Master",
          // },
        ],
      },

      {
        title: "transactions",
        content: "Description",
        icon: BookFilled,
        clickTo: "/hawkerManagementSystem/transactions",
        code: "HMST",
        breadcrumName: "Hawker Management System / transactions",
        childrenCards: [
          {
            title: " Issuance of Hawker License",
            title: <FormattedLabel id='issuanceOfHawkerLicense' />,

            content: "Description",
            icon: BookFilled,
            clickTo:
              "/hawkerManagementSystem/transactions/issuanceOfHawkerLicense",
            code: "C-HMST02",
            breadcrumName:
              "Hawker Management System / Issuance of Hawker License",
          },
          {
            title: "Deparmental Clark Dashboard",
            content: "Description",
            icon: BookFilled,
            clickTo:
              "/hawkerManagementSystem/transactions/dashboards/deparmentalClark",
            code: "C-HMST02",
            breadcrumName:
              "Hawker Management System / Issuance of Hawker License",
          },

          {
            title: <FormattedLabel id='siteVisit' />,
            content: "Description",
            icon: BookFilled,
            clickTo: "/hawkerManagementSystem/transactions/siteVisit",
            code: "C-HMST02",
            breadcrumName: "Hawker Management System / siteVisit",
          },

          // title: (
          //   <div
          //     sx={{
          //       minWidth: 275,
          //       backgroundColor: "#F2F3F4",
          //       transform: "scale(0.8)",
          //       padding: 1,
          //       fontFamily: "Verdana",
          //       color: "#5D6D7E",
          //     }}
          //   >
          //     Isssuance of Hawker License
          //   </div>
          // ),

          // {
          //   title: "Task Transfer",
          //   title: <FormattedLabel id='taskTransfer' />,
          //   content: "Description",
          //   icon: BookFilled,
          //   clickTo: "/hawkerManagementSystem/transactions/taskTransfer",
          //   code: "C-HMST01",
          //   breadcrumName: "Hawker Management System / taskTransfer",
          // },
        ],
      },

      {
        title: "report",
        content: "Description",
        icon: BookFilled,
        clickTo: "/hawkerManagementSystem/reports",
        code: "HMST",
        breadcrumName: "Hawker Management System / reports",
        childrenCards: [
          {
            title: <FormattedLabel id='report' />,
            content: "Description",
            icon: BookOutlined,
            clickTo: "/hawkerManagementSystem/reports/ageProofDocument",
            code: "C-HMST01",
            breadcrumName:
              "Hawker Management System / reports / Age Proof Document",
          },
        ],
      },
    ],
  },
];

export const menuCodes = [
  {
    path: "login",
    code: "LO",
  },
  {
    path: "/hawkerManagementSystem",
    code: "HMS",
  },
  // {
  //   path: "",
  //   code: "HM",
  // },
  // {
  //   path: "dashboard",
  //   code: "M01",
  // },
];
