import React, { Children } from "react";
import { styled, useTheme } from "@mui/material/styles";
import {
  Box,
  Collapse,
  CssBaseline,
  Divider,
  Grid,
  IconButton,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Menu,
  MenuItem,
  Paper,
  Toolbar,
  Typography,
} from "@mui/material";
import Image from "next/image";
import AccountCircle from "@mui/icons-material/AccountCircle";
import MenuIcon from "@mui/icons-material/Menu";
import InboxIcon from "@mui/icons-material/MoveToInbox";
import styles from "./[BasicLayout].module.css";
import { useState } from "react";
import MuiDrawer from "@mui/material/Drawer";
import MuiAppBar from "@mui/material/AppBar";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import axios from "axios";
import { useEffect } from "react";
import { useRouter } from "next/router";
import { logout } from "../../features/userSlice";
import { useDispatch, useSelector } from "react-redux";
// import state from "sweetalert/typings/modules/state";
import { language } from "../../features/labelSlice";
import { toast } from "react-toastify";

const drawerWidth = 340;

const openedMixin = (theme) => ({
  width: drawerWidth,
  height: "92%",
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: "hidden",
});

const closedMixin = (theme) => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: "hidden",
  width: `calc(${theme.spacing(7)} + 1px)`,
  height: "92%",
  [theme.breakpoints.up("sm")]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const DrawerHeader = styled("div")(({ theme }) => ({
  display: "flex",
  backgroundColor: "#556CD6",
  alignItems: "center",
  justifyContent: "flex-end",
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
}));

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer + 1,
  transition: theme.transitions.create(["width", "margin"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const Drawer = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  width: drawerWidth,
  flexShrink: 0,
  whiteSpace: "nowrap",
  boxSizing: "border-box",
  ...(open && {
    ...openedMixin(theme),
    "& .MuiDrawer-paper": openedMixin(theme),
  }),
  ...(!open && {
    ...closedMixin(theme),
    "& .MuiDrawer-paper": closedMixin(theme),
  }),
}));

const BasicLayout = ({ children, titleProp }) => {
  const [open, setOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [openCollapse, setOpenCollapse] = React.useState(false);
  const [response, setResponse] = useState([]);
  const [openItemID, setOpenItemID] = useState(null);

  const [runAgain, setRunAgain] = useState(false);

  const router = useRouter();
  const dispatch = useDispatch();

  const underline = useSelector((state) => state?.labels.language);

  const theme = useTheme();

  useEffect(() => {
    onDepartmentLogin();
  }, []);

  const onDepartmentLogin = () => {
    const body = {
      userName: "ADMIN",
      password: "Admin@123",
      // userName: user,
      // password: pwd,
    };

    axios
      .post("http://localhost:8090/cfc/auth/signin", body)
      .then((r) => {
        if (r.status == 200) {
          console.log("department login response", r);
          setResponse(r.data);
        }
      })
      .catch((err) => {
        console.log("err", err);
        toast("Login Failed ! Please Try Again !", {
          type: "error",
        });
      });

    // if (user == "Admin" && pwd == 12345) {
    //   router.push("/DepartmentDashboard");
    // }
  };

  const handleMenuSubListItemClick = (value, index) => {
    console.log("value", value);
    router.push(value);
  };

  function handleListItemsClick(key) {
    if (openCollapse == false) {
      setOpenItemID(key);
      setOpenCollapse(true);
    } else {
      setOpenItemID(null);
      setOpenCollapse(false);
    }
  }

  let arr =
    response.menus &&
    response.menus.filter((val) => {
      return val.isParent;
    });

  let check =
    response.menus &&
    response.menus.map((test) => {
      console.log("test", test);
      return test.appKey == 4 && test;
    });

  const handleDrawerOpen = () => {
    console.log("drawer opem");
    setOpen(true);
  };
  const handleDrawerClose = () => {
    console.log("drawer opem");
    setOpen(false);
  };

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    setAnchorEl(null);
    dispatch(logout());
    router.push("/login");
  };

  return (
    <div style={{ display: "flex", flexDirection: "row" }}>
      {/**<div> */}
      {/**  <Box sx={{ display: "flex" }}>  */}
      <CssBaseline />
      <AppBar position='fixed' open={open}>
        <Toolbar>
          <Grid container>
            <Grid item xs={1} className={styles.drawerIconContainer}>
              <IconButton
                color='inherit'
                aria-label='open drawer'
                onClick={handleDrawerOpen}
                edge='start'
                sx={{
                  marginRight: 5,
                  ...(open && { display: "none" }),
                }}
              >
                <MenuIcon />
              </IconButton>
            </Grid>
            <Grid item xs={1} className={styles.appIcon}>
              <Image
                src='/logo.png'
                alt='Picturer'
                width={50}
                height={50}
                style={{ cursor: "pointer" }}
              />
            </Grid>
            <Grid item xs={6} className={styles.appNameContainer}>
              <Typography className={styles.title1}>
                PIMPRI CHINCHWAD
              </Typography>
              <Typography className={styles.title1}>
                MUNICIPAL CORPORATION
              </Typography>
            </Grid>
            {/* Code For Labels */}

            <div className={styles.menuIcon}>
              <div
                className={styles.lang}
                style={{
                  marginRight: "100px",
                  marginLefty: "500px",
                  marginTop: 13,
                }}
              >
                <div
                  className={
                    underline == "en" ? styles.chotuContainer : styles.language
                  }
                >
                  <span
                    className={styles.engLang}
                    style={{
                      color: "white",
                      fontSize: "15px",
                      marginRight: "10px",
                    }}
                    onClick={() => {
                      setRunAgain(true);
                      dispatch(language("en"));
                    }}
                  >
                    English
                  </span>
                </div>
                <div
                  className={
                    underline == "mr" ? styles.chotuContainer : styles.language
                  }
                >
                  <span
                    className={styles.language}
                    style={{
                      color: "white",
                      fontSize: "15px",
                      marginRight: "10px",
                    }}
                    onClick={() => {
                      setRunAgain(true);
                      dispatch(language("mr"));
                    }}
                  >
                    Marathi
                  </span>
                </div>
              </div>

              <div className={styles.menuIcon}>
                <IconButton
                  size='large'
                  aria-label='account of current user'
                  aria-controls='menu-appbar'
                  aria-haspopup='true'
                  onClick={handleMenu}
                  color='inherit'
                >
                  <AccountCircle />
                </IconButton>
                <Menu
                  id='menu-appbar'
                  anchorEl={anchorEl}
                  anchorOrigin={{
                    vertical: "top",
                    horizontal: "right",
                  }}
                  keepMounted
                  transformOrigin={{
                    vertical: "top",
                    horizontal: "right",
                  }}
                  open={Boolean(anchorEl)}
                  onClose={handleClose}
                >
                  <MenuItem className={styles.menuList}>
                    <Box
                      sx={{
                        width: "100%",
                      }}
                    >
                      <Typography variant='body2' className={styles.menuTitle}>
                        Name :{" "}
                      </Typography>
                      <Typography>ABCD MNOP</Typography>
                    </Box>
                    <Box className={styles.menuTitleContainer}>
                      <Typography variant='body2' className={styles.menuTitle}>
                        Role :{" "}
                      </Typography>
                      <Typography>Admin</Typography>
                    </Box>
                    <Box className={styles.menuTitleContainer}>
                      <Typography variant='body2' className={styles.menuTitle}>
                        Email ID :{" "}
                      </Typography>
                      <Typography>abcdmnop@gmail.component</Typography>
                    </Box>
                  </MenuItem>
                  <MenuItem onClick={handleLogout} style={{ color: "#2162DF" }}>
                    Logout
                  </MenuItem>
                </Menu>
              </div>
            </div>
          </Grid>
        </Toolbar>
      </AppBar>
      <Drawer variant='permanent' open={open}>
        <DrawerHeader>
          <IconButton onClick={handleDrawerClose} style={{ color: "white" }}>
            {theme.direction === "rtl" ? (
              <ChevronRightIcon />
            ) : (
              <ChevronLeftIcon />
            )}
          </IconButton>
        </DrawerHeader>
        <Divider />
        <List
          sx={{
            display: "flex",
            flexDirection: "column",
            width: "100%",
          }}
          component='nav'
          aria-labelledby='nested-list-subheader'
        >
          {arr && arr.length > 0
            ? arr &&
              arr.map((text, index) => {
                console.log("text", text);
                return (
                  <Box key={index}>
                    <ListItemButton
                      style={{
                        cursor: "pointer",
                        display: text.menuNameEng ? "flex" : "none",
                      }}
                      onClick={() => {
                        handleListItemsClick(text.id);
                      }}
                    >
                      {text.isParent !== null && (
                        <ListItemIcon>
                          <InboxIcon />
                        </ListItemIcon>
                      )}
                      {text.isParent !== null && (
                        <ListItemText primary={text.menuNameEng} />
                      )}
                      {text.isParent !== null &&
                        (openItemID === text.id ? (
                          <ExpandLessIcon />
                        ) : (
                          <ExpandMoreIcon />
                        ))}
                    </ListItemButton>
                  </Box>
                );
              })
            : "NA"}
          {check &&
            check.map((text, id) => {
              return (
                <Box key={id}>
                  <Collapse
                    in={openCollapse && openItemID === text.parentId}
                    timeout='auto'
                    unmountOnExit
                  >
                    <List
                      component='div'
                      disablePadding
                      onClick={(index) => {
                        handleMenuSubListItemClick(text.clickTo, index);
                      }}
                    >
                      <ListItemButton sx={{ pl: 4 }}>
                        <ListItemIcon>
                          <InboxIcon />
                        </ListItemIcon>
                        <ListItemText primary={text.menuNameEng} />
                      </ListItemButton>
                      <Divider />
                    </List>
                  </Collapse>
                </Box>
              );
            })}
        </List>
      </Drawer>
      <Box component='main' sx={{ flexGrow: 1, paddingTop: "6%" }}>
        {/* <Toolbar /> */}
        <Box>{children}</Box>
      </Box>
      {/** </Box> */}
    </div>
  );
};

export default BasicLayout;

// import React, { Children } from 'react'
// import { Card } from 'antd'
// import LayoutFooter from './components/LayoutFooter'
// import LayoutPageHeader from './components/LayoutPageHeader'
// import FirstHeader from './components/FirstHeader'
// import FormattedLabel from '../reuseableComponents/FormattedLabel'
// const BasicLayout = ({ children, titleProp }) => {
//   return (
//     <div className='wrapper'>
//       <FirstHeader />
//       <LayoutPageHeader />
//       <div className='layout-content'>
//         {titleProp === 'none' ? (
//           <Card>{children}</Card>
//         ) : (
//           <Card title={<FormattedLabel id={titleProp} />}>{children}</Card>
//         )}
//       </div>
//       <LayoutFooter />
//     </div>
//   )
// }

// export default BasicLayout

// import React, { Children } from 'react'
// import { Card } from 'antd'
// import LayoutFooter from './components/LayoutFooter'
// import LayoutPageHeader from './components/LayoutPageHeader'
// import FirstHeader from './components/FirstHeader'
// import LayoutHeader from './components/LayoutHeader'
// import UpperFooter from './components/upperFooter'
// const BasicLayout = ({ children, titleProp }) => {
//   return (
//     <div className="wrapper">
//       <FirstHeader />
//       <LayoutHeader />
//       <LayoutPageHeader />
//       <div className="layout-content">
//         {titleProp === 'none' ? (
//           <Card>{children}</Card>
//         ) : (
//           <Card title={titleProp}>{children}</Card>
//         )}
//       </div>
//       {/* <UpperFooter /> */}
//       <LayoutFooter />
//     </div>
//   )
// }

// export default BasicLayout
