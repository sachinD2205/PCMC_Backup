import axios from "axios";
import { useCallback } from "react";
// import { useModel } from "umi";
import { message } from "antd";

const useAxios = () => {
  //   const { token } = useModel("Auth");
  const langType =
    localStorage.getItem("umi_locale") === "ma-IN" ? "mr-IN" : "en-US";
  const customMessageError = (msgData) => {
    // switch (msgData) {
    //  case ''
    // }
    message.info(`${msgData}`);
  };

  //   const openNotification = (type, placement) => {
  //     notification[type]({
  //       message: "Data Fetched",
  //       description: `Modification Data for Village fetched!`,
  //       placement,
  //       onClick: () => {
  //         // function on notification click can be added here!
  //         console.log("Notification Clicked!");
  //       },
  //     });
  //   };

  const sendRequest = useCallback(
    async (url, type = "GET", reqData, callback, errorCallback) => {
      if (type === "POST") {
        await axios
          .post(url, reqData, {
            headers: {
              "Accept-Language": langType,
              //   Authorization: `Bearer ${token}`,
            },
          })
          .then((response) => {
            callback(response);
          })
          .catch((error) => {
            console.log(error);
            if (errorCallback) {
              errorCallback(error.response);
            }
          });
      } else if (type === "GET") {
        await axios
          .get(url, {
            headers: {
              "Accept-Language": langType,
              //   Authorization: `Bearer ${token}`,
            },
          })
          .then((response) => {
            if (response.data.status === "FAILURE") {
              message.error(response.data.message);
              console.log(response);
            }
            callback(response);
          })
          .catch((error) => {
            console.log("error", error);
            message.error(error.response.data.message);
            if (errorCallback) {
              errorCallback(error.response);
            }
            console.log(error);
          });
      }
    },
    []
  );

  return {
    sendRequest,
  };
};

export default useAxios;
