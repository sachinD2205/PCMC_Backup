import React, { useEffect, useState } from "react";
import styles from "./[header].module.css";
import HeaderAvatar from "./HeaderAvatar";
import { useRouter } from "next/router";
import { useDispatch, useSelector } from "react-redux";

import { language } from "../../../features/labelSlice";

const FirstHeader = () => {
  const router = useRouter();
  const dispatch = useDispatch();
  // @ts-ignore
  const underline = useSelector((state) => state?.labels.language);

  const [runAgain, setRunAgain] = useState(false);

  useEffect(() => {
    setRunAgain(false);
  }, [runAgain]);

  const handleClick = () => {
    router.push("/dashboard");
  };
  return (
    <>
      <div className={styles.header}>
        <div className={styles.leftheader}>
          <img onClick={handleClick} src='/logo.png' alt='' height='50px' />
          <div className={styles.heading}>
            <a onClick={handleClick}>
              <div className={styles.name}>
                {/* <label style={{ marginBottom: -10 }}>पिंपरी </label>
                <label style={{ marginBottom: -10 }}>चिंचवड</label>
                <label style={{ marginBottom: -10 }}> महानगर</label>
                <label style={{ marginBottom: -10 }}> पालिका</label> */}
                <label style={{ marginBottom: -5 }}>पिंपरी-चिंचवड </label>
                <label style={{ marginBottom: -10 }}> महानगरपालिका</label>
              </div>
            </a>
          </div>
        </div>
        <div className={styles.rightheader}>
          <div className={styles.lang} style={{ marginRight: "100px" }}>
            <div
              className={
                underline == "en" ? styles.chotuContainer : styles.language
              }
            >
              <span
                className={styles.engLang}
                style={{
                  color: "white",
                  fontSize: "15px",
                  marginRight: "10px",
                }}
                onClick={() => {
                  setRunAgain(true);
                  dispatch(language("en"));
                }}
              >
                English
              </span>
            </div>
            <div
              className={
                underline == "mr" ? styles.chotuContainer : styles.language
              }
            >
              <span
                className={styles.language}
                style={{
                  color: "white",
                  fontSize: "15px",
                  marginRight: "10px",
                }}
                onClick={() => {
                  setRunAgain(true);
                  dispatch(language("mr"));
                }}
              >
                Marathi
              </span>
            </div>
          </div>
          <HeaderAvatar />
        </div>
      </div>
    </>
  );
};

export default FirstHeader;
