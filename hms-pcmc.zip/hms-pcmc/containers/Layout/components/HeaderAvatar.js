import React from 'react'
import { Avatar, Popover, Row, Input, Col } from 'antd'
import { UserOutlined, SearchOutlined } from '@ant-design/icons'
import { useDispatch, useSelector } from 'react-redux'
import { logout } from '../../../features/userSlice'
import { useRouter } from 'next/router'

const HeaderAvatar = () => {
  const dispatch = useDispatch()
  const router = useRouter()
  // @ts-ignore
  const userDetailsInRedux = useSelector((state) => state.user.user[0])
  // const userDetailsInRedux = useSelector((state) => state.user.user)
  const handleLogout = () => {
    dispatch(logout())
    router.push('/login')
  }
  const content = (
    <>
      <p>
        <b>Name:</b>
        <br />
        {userDetailsInRedux?.fullName}
      </p>
      <p>
        <b>Role:</b>
        <br />
        {userDetailsInRedux?.designation}
      </p>
      <p>
        <b>E-Mail:</b>
        <br />
        {userDetailsInRedux?.email}
      </p>
      <a type='link' onClick={handleLogout}>
        <b>Logout</b>
      </a>
    </>
  )
  return (
    <>
      <>
        <Col>
          <Popover content={content}>
            <Avatar style={{ float: 'right' }} icon={<UserOutlined />} />
          </Popover>
          {/* <Input
            style={{ paddingRight: 10, width: '200px', float: 'right' }}
            addonBefore={<SearchOutlined style={{ color: 'black' }} />}
          /> */}
        </Col>
        {/* <p style={{ color: 'white', paddingLeft: 10 }}>{i.fullName}</p> */}
      </>
    </>
  )
}

export default HeaderAvatar
