import React from 'react'

const LayoutFooter = () => {
  return (
    <div className='layout-footer'>
      <b>PCMC ©2022 Powered by Atos Nascent</b>
    </div>
  )
}

export default LayoutFooter
