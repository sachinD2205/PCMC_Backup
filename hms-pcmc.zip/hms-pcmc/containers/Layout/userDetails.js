export default [
  {
    userName: 'PCMC02221',
    fullName: 'Ashish Dahale',
    role: 'admin',
    designation: 'Team Lead',
    email: 'ashishd@probitysoft.com',
  },
]
