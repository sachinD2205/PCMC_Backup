import { Card, Col, Row } from "antd";
import { useRouter } from "next/router";
import React from "react";
import { useSelector } from "react-redux";
import FormattedLabel from "../../reuseableComponents/FormattedLabel";
import menu from "../menu";

const InnerCards = ({ pageKey }) => {
  // @ts-ignore
  const backEndApiMenu = useSelector((state) => state.user.menu);

  const router = useRouter();
  const onClickHandler = (pageMode, linkToForSubMenu) => {
    // setCurrent(e.key)
    router.push({
      pathname: `${linkToForSubMenu}`,
    });
  };

  return (
    <div>
      <div className='site-card-wrapper'>
        <Row gutter={16}>
          {menu
            .filter((menuObj) => {
              return menuObj.key === "/" + pageKey;
            })
            .map((i) => {
              if (i.innerCards) {
                return i.innerCards
                  .filter(
                    (Obj) =>
                      backEndApiMenu.BackendInnerCards.indexOf(Obj.code) >= 0,
                  )
                  .map((j) => {
                    let pageMode, tempTitle;
                    tempTitle = j.titleprop;
                    console.log("Formatted Label: ", tempTitle);
                    const linkToForMenu = `${j.clickTo}`;
                    const Icon = j.icon;
                    if (j.pageMode) {
                      pageMode = j.pageMode;
                    }
                    return (
                      <>
                        <Col xl={8} lg={8} md={8} xs={24}>
                          <Card
                            onClick={() => {
                              onClickHandler(pageMode, linkToForMenu);
                            }}
                            style={{
                              height: 200,
                              color: "rgb(32, 159, 238)",
                              backgroundColor: "white",
                              marginBottom: 10,
                              margin: "10px",
                            }}
                            title={
                              <div
                                style={{
                                  textAlign: "center",
                                  textTransform: "capitalize",
                                }}
                              >
                                {/* {j.title} */}
                                {/* <FormattedLabel id='master' /> */}
                                {<FormattedLabel id={j.title} />}
                              </div>
                            }
                            hoverable
                            bordered={true}
                          >
                            {
                              <div
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                }}
                              >
                                <Icon
                                  style={{
                                    color: "rgb(32, 159, 238)",
                                    fontSize: "50px",
                                    paddingTop: 10,
                                  }}
                                />
                              </div>
                            }
                          </Card>
                        </Col>
                      </>
                    );
                  });
              }
            })}
        </Row>
      </div>
    </div>
  );
};

export default InnerCards;
