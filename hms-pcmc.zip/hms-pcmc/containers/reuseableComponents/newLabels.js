import tpLabels from "./labels/modules/tpLabels";
import cfcLabels from "./labels/modules/cfcLabels";
import fbsLabels from "./labels/modules/fbsLabels";
import hmsLabels from "./labels/modules/hmsLabels";
import lcLabels from "./labels/modules/lcLabels";
import mrLabels from "./labels/modules/mrLabels";
import msLabels from "./labels/modules/msLabels";
import ptaxLabels from "./labels/modules/ptaxLabels";
import spLabels from "./labels/modules/spLabels";
import sslLabels from "./labels/modules/sslLabels";
import gmLabels from "./labels/modules/gmLabels";
import dashboardlabels from "./labels/common/dashboardLabels";
import loginLabels from "./labels/common/loginLabels";
import homeLabels from "./labels/common/homeLabels";

export default {
  //common
  home: homeLabels,
  login: loginLabels,
  dashboard: dashboardlabels,

  //modules
  townPlanning: tpLabels,
  citizenFacilitationCenter: cfcLabels,
  FireBrigadeSystem: fbsLabels,
  hawkerManagementSystem: hmsLabels,
  LegalCase: lcLabels,
  marriageRegistration: mrLabels,
  grievanceMonitoring: gmLabels,
  municipalSecretary: msLabels,
  propertyTax: ptaxLabels,
  sportsPortal: spLabels,
  skySignLicense: sslLabels,
};
