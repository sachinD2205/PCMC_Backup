export default {
  en: [
    {
      type: "commonLabels",

      // fireBridageSystem: "Fire Brigade System",
      module: "Hawker Management System",
      // dashboard: 'PCMC Dashboard',
      dashboard: "Pimpri-Chinchwad Municipal Corporation Dashboard",
      masters: "Masters",
      transactions: "Transactions",
      reports: "Reports",
      masterPath: "Hawker Management System / masters",
      transactionPath: "Legal Case / Transaction ",
      reportPath: "Legal Case / Report ",
    },
    {
      type: "masters",
      masters: "Masters",
      masterPath: "FIRE BRIGADE SYSTEM / masters",

      religionPath: "Street Vendor Management System / masters / Religion",
      hawkerTypePath:
        "Street Vendor Management System / masters / Street Vendor Type",
      businessTypeMasterPath:
        "Street Vendor Management System / masters / Business Type Master",
      businessSubTypePath:
        "Street Vendor Management System / masters / Business Sub Type",
      titlePath: "Street Vendor Management System / masters / Title",
      itemMasterPath: "Street Vendor Management System / masters / Item Master",
      itemCategoryMasterPath:
        "Street Vendor Management System / masters / Item Category Master",
      castCategoryPath:
        "Street Vendor Management System / masters / Cast Category",
      castMasterPath: "Street Vendor Management System / masters / Cast Master",
      hawkingZonePath:
        "Street Vendor Management System / masters / Hawking Zone",
      subCastMasterPath:
        "Street Vendor Management System / masters / Sub Cast Master",
      licenseValidityPath:
        "Street Vendor Management System / masters / License Validity",
      penaltyPath: "Street Vendor Management System / masters / Penalty",
      bankMasterPath: "Street Vendor Management System / masters /Bank Master",
      hawkingZoneWiseFacilitiesPath:
        "Street Vendor Management System / masters / Hawking Zone Wise Facilities",
      taxTypeMasterPath:
        "Street Vendor Management System / masters / Tax Type Master",
      taxNameMasterPath:
        "Street Vendor Management System / masters / Tax Name Master",
      serviceTaxCollectionCyclePath:
        "Street Vendor Management System / masters / Service Tax Collection Cycle",
      taxRateChartMasterPath:
        "Street Vendor Management System / masters / Tax Rate Chart Master",
      noHawkingZonePath:
        "Street Vendor Management System / masters / No Hawking Zone",
      hawkerMasterPath:
        "Street Vendor Management System / masters / Street Vendor Master",

      //label title

      religion: "Religion",
      hawkerType: "Street Vendor Type",
      businessTypeMaster: "Business Type Master",
      businessSubType: "Business Sub Type",
      title: "Title",
      itemMaster: "Item Master",
      itemCategoryMaster: "Item Category Master",
      castCategory: "Cast Category",
      castMaster: "Cast Master",
      hawkingZone: "Hawking Zone",
      subCastMaster: "Sub Cast Master",
      licenseValidity: "License Validity",
      penalty: "Penalty",
      bankMaster: "Bank Master",
      hawkingZoneWiseFacilities: "Hawking Zone Wise Facilities",
      taxTypeMaster: "Tax Type Master",
      taxNameMaster: "Tax Name Master",
      serviceTaxCollectionCycle: "Service Tax Collection Cycle",
      taxRateChartMaster: "Tax Rate Chart Master",
      noHawkingZone: "No Hawking Zone",
      hawkerMaster: "Street Vendor Master",

      srNo: "Sr. No",
      actions: "Actions",

      srNo: "Sr No",
      hawkerTypePrefix: "Street Vendor Type Prefix",
      fromDate: "From Date",
      toDate: "To Date",
      hawkerType: "Street Vendor Type",
      remark: "Remark",
      actions: "Actions",

      //Hawker Zone

      actions: "Actions",
      remark: "Remark",
      zoneName: "Zone Name",
      hawkingZoneInfo: "Street Vendor Zone Info",
      itemName: "Item Name",
      noOfHawkersPresent: "No Of Street Vendors Present",
      capacityOfHawkingZone: "Capacity Of Street Vendor Zone",
      declarationOrder: "Declaration Order",
      declarationOrderNo: "Declaration Order No",
      declarationDate: "Declaration Date",
      areaName: "Area Name *",
      hawkingZoneName: "Street Vendor Zone Name",
      citySurveyNo: "City Survey No *",
      gisId: "GIS Id",
      hawkingZonePrefix: "Street Vendor Zone Prefix",
      constraint: "Constraint",
      serviceTaxCollectionCyclePrefix: "Service-Tax Collection Cycle Prefix",

      //License Validity
      hawkerTypeName: "Street Vendor Type Name",
      licenseValidityPrefix: "License Validity Prefix",
      noHawkingZoneName: "No Street Vendor Zone Name",
      noHawkingZoneprefix: "No Street Vendor Zone Prefix",
      itemCategoryPrefix: "Item Category Prefix",
      itemCategory: "Item Category",
      hawkingZoneWiseFacilitiesPrefix:
        "Street Vendor Zone Wise Facilities Prefix",
      facilities: "Facilities",
      hawkingZoneName: "Street Vendor Zone Name",
      hawkerPrefix: "Street Vendor Prefix",
      citySurveyNo: "City Survey No",
      firstName: "First Name",
      //buttons
      add: "Add",
      save: "Save",
      update: "Update",
      clear: "Clear",
      exit: "Exit",
      back: "Back",
      saveAndNext: "Save & Next",
      finish: "Finish",
    },
    {
      type: "transactions",

      issuanceOfHawkerLicensePath:
        "Street Vendor Management System / issuanceOfStreetVendorLicense",
      siteVisitPath: "Street Vendor Management System / Site Visit",
      taskTransfer: "Street Vendor Management System / Task Transfer",

      //Button
      viewLocationOnMap: "View Location On Map",

      issuanceOfHawkerLicensePath:
        "Street Vendor Management System / issuanceOfStreetVendorLicense",
      siteVisitPath: "Street Vendor Management System / Site Visit",
      taskTransfer: "Street Vendor Management System / Task Transfer",

      //Button
      viewLocationOnMap: "View Location On Map",
      back: "Back",
      next: "Next",
      finish: "Finish",

      //titles
      issuanceOfHawkerLicense: "Issuance Of Street Vendor License",
      siteVisit: "Site Visit",
      taskTransfer: "Task Transfer",

      //labels of "Hawker Details"

      basicApplicationDetails: "Basic Application Details",
      serviceName: "Service Name *",
      applicationNumber: "Application Number",
      applicationDate: "Application Date",
      citySurveyNo: "City Survey No",
      hawkingZoneName: "Street Vendor Zone Name *",
      areaName: "Area Name",
      basicApplicationDetails: "Basic Application Details",
      hawkerDetails: "Street Vendor Details",
      // addressOfHawker: "Address Of Hawker",
      addressOfHawker: "Address",
      aadharAuthentication: "Aadhaar Authentication",
      aadhaarNo: "Aadhaar No",
      verfiyOtp: "ओटीपी तपसा",
      sendOTP: "ओटीपी पाठवा",
      additionalDetails: "Additional Details",
      documentsUpload: "Documents Upload",
      title: "Title *",
      firstName: "First Name *",
      middleName: "Middle Name *",
      lastName: "Last Name / Surname",
      gender: "Gender",
      religion: "Religion",
      caste: "Caste",
      subCast: "Sub Caste",
      dateOfBirth: "Date of Birth *",
      age: "Age *",
      mobile: "Mobile No. *",
      emailAddress: "Email Address",
      disability: "Disability",
      rationCardNo: "Ration Card No",
      yes: "Yes",
      no: "No",
      typeOfDisability: "Type Of Disability",

      // labels of "Address Of Hawker"
      currentAddressofHawker: "Current Address",
      citySurveyNumber: "City Survey Number *",
      areaName: "Area Name *",
      landmarkName: "Landmark *",
      villageName: "Village Name *",
      cityName: "City Name *",
      state: "State *",
      pinCode: "Pin Code *",
      lattitude: "Lattitude *",
      logitude: "Longitude *",
      permanentPostalAddressOfHawker: "Permanent/Postal Address",
      permanentAddressAsTheCorrespondenceAddress:
        "Permanent Address As The Correspondence Address",
      citySurveyNumber: "City Survey Number",

      //Aadhar Authentication

      aadharAuthentication: "Aadhaar Authentication",
      verfiyOtp: "Verify OTP",
      sendOTP: "Send OTP",

      //Additional Details
      wardNo: "Ward No",
      wardName: "Ward Name",
      natureOfBusiness: "Nature of Business",
      hawkingDurationDaily: "Street Vendor Duration Daily",
      item: "Item",
      periodOfResidenceInMaharashtra: "Period of Residence In Maharashtra",
      periodOfResidenceInPcmc: "Period of Residence In PCMC",
      bankName: "Bank Name",
      branchName: "Branch Name",
      bankAccountNo: "Bank Account No",
      ifscCode: "IFSC Code",
      hawkerType: "Street Vendor Type",
      bankDetails: "Bank Details",

      //Labels Of Document Upload

      documentUpload: "Documents Upload *",
      adharCard: "Aadhaar Card *",
      panCard: "Pan Card *",
      rationCard: "Ration Card *",
      disablityCretificatePhoto: "Disability Certificate *",
      otherDocumentPhoto: "Other Documents ",
      affidaviteOnRS100StampAttachement:
        "Affidavite On RS.100 Stamp Attachement *",

      //Remarks
      selectDate: "Please select a date",
      selectTitle: "Please select a title",
      enterFName: "Please enter first name ",
      enterMName: "Please enter middle name ",
      enterLName: "Please enter last name ",
      enterArea: "Please enter area ",
      enterRoadName: "Please enter road name ",
      enterLandmark: "Please enter a landmark ",
      enterCity: "Please enter a city ",
      enterPinCode: "Please enter a pincode ",
      enterPhoneNo: "Please enter a phone no. ",
      enterMobileNo: "Please enter a mobile no. ",
      enterEmailAddress: "Please enter an e-mail. ",
      enteraadhaarNo: "Please enter an aadhaar no. ",
      enterpanNo: "Please enter an pan no. ",
      enterRemarks: "Please enter a remark. ",

      attachFile: "Attach File",
      srNo: "Sr. No",
      actions: "Actions",

      // Property and Water taxes
      tax: "Tax",
      waterAmount: "Water Amount",
      crPropertyTaxNumber: "Property Tax No",
      crWaterConsumerNo: "Water Consumer No",
      proprtyAmount: "Property Amount",
      viewBill: "View Bill",
      payBill: "Pay Bill",
      PropertyAndWaterTaxes: "Taxes",
      //buttons
      add: "Add",
      save: "Save",
      update: "Update",
      clear: "Clear",
      exit: "Exit",
      back: "Back",
      saveAndNext: "Save & Next",
      finish: "Finish",
    },
    { type: "report" },
  ],
  mr: [
    {
      type: "commonLabels",

      module: "अग्निशामक यंत्रणा",
      // dashboard: 'डॅशबोर्ड',
      dashboard: "पिंपरी-चिंचवड महानगरपालिका डॅशबोर्ड",
      masters: "मास्टर्स",
      transactions: "व्यवहार",
      reports: "अहवाल",
      masterPath: "अग्निशमन यंत्रणा / मास्टर ",
      transactionPath: "कायदेशीर प्रकरण/ व्यवहार ",
      reportPath: "कायदेशीर प्रकरण/ अहवाल ",
    },
    {
      type: "masters",
      masters: "मास्टर्स",
      masterPath: "तक्रार निरीक्षण / मास्टर्स",

      transaction: "व्यवहार",
      report: "अहवाल",
      religionPath: "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / धर्म",
      hawkerTypePath:
        "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / पथविक्रेता प्रकार",
      businessTypeMasterPath:
        "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / व्यवसाय प्रकार मास्टर",
      businessSubTypePath:
        "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / व्यवसाय उपप्रकार",
      titlePath: "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / शीर्षक",
      itemMasterPath: "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / वस्तु मास्टर",
      itemCategoryMasterPath:
        "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / वस्तु श्रेणी मास्टर",
      castCategoryPath: "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / कास्ट श्रेणी",
      castMasterPath: "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / कास्ट मास्टर",
      hawkingZonePath: "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर /  हॉकिंग झोन",
      subCastMasterPath:
        "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / सब कास्ट मास्टर",
      licenseValidityPath:
        "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / परवाना वैधता",
      penaltyPath: "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / दंड",
      bankMasterPath: "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / बँक मास्टर",
      hawkingZoneWiseFacilitiesPath:
        "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / हॉकिंग झोननिहाय सुविधा",
      taxTypeMasterPath:
        "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / कर प्रकार मास्टर",
      taxNameMasterPath:
        "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / कर नाव मास्टर",
      serviceTaxCollectionCyclePath:
        "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / सेवा कर संकलन सायकल",
      taxRateChartMasterPath:
        "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / कर दर चार्ट मास्टर",
      noHawkingZonePath:
        "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / हॉकिंग झोन नाही",
      hawkerMasterPath:
        "पथविक्रेता व्यवस्थापन प्रणाली / मास्टर / पथविक्रेता मास्टर",

      //titles

      religion: "धर्म",
      hawkerType: "पथविक्रीचा प्रकार",
      businessTypeMaster: "व्यवसाय प्रकार मास्टर",
      businessSubType: "व्यवसाय उपप्रकार",
      title: "शीर्षक",
      itemMaster: "वस्तु मास्टर",
      itemCategoryMaster: "वस्तु श्रेणी मास्टर",
      castCategory: "कास्ट श्रेणी",
      castMaster: "कास्ट मास्टर",
      hawkingZone: "पथविक्रेत्याचा झोन",
      subCastMaster: "सब कास्ट मास्टर",
      licenseValidity: "परवाना वैधता",
      penalty: " दंड",
      bankMaster: "बँक मास्टर",
      hawkingZoneWiseFacilities: "पथविक्रेत्याच्या झोननिहाय सुविधा",
      taxTypeMaster: " कर प्रकार मास्टर",
      taxNameMaster: "कर नाव मास्टर",
      serviceTaxCollectionCycle: "सेवा कर संकलन सायकल",
      taxRateChartMaster: "कर दर चार्ट मास्टर",
      noHawkingZone: "पथविक्रेत्याला झोन नाही",
      hawkerMaster: "पथविक्रेत्याचा मास्टर",

      //other labels
      courtName: "न्यायालयाचे नाव",

      roadName: "रस्त्याचे नाव",
      address: "पत्ता",
      landmark: "जवळची खूण",
      cityOrVillage: "शहर / गाव",
      pincode: "Pin Code",

      srNo: "अनुक्रमांक",
      actions: "क्रिया ",

      //buttons
      add: "जोडा",
      save: "जतन करा",
      update: "अद्यायावत करा",
      clear: "रिक्त",
      exit: "बाहेर पडा",

      //Hawker Type

      srNo: "अनु. क्र",
      hawkerTypePrefix: "पथविक्रेत्याचा उपसर्ग प्रकार ",
      fromDate: "या तारखेपासून",
      toDate: "आजपर्यंत",
      hawkerType: "पथविक्रीचा प्रकार",
      remark: "शेरा",

      actions: "क्रिया",
      remark: "शेरा",
      zoneName: "पथविक्रेत्याचे नाव",
      hawkingZoneInfo: "पथविक्रेत्याच्या झोनची माहिती",
      itemName: "वस्तु",
      noOfHawkersPresent: "उपस्थित हॉकर्सची संख्या",
      capacityOfHawkingZone: "पथविक्रेत्याच्या झोनची क्षमता",
      declarationOrder: "घोषणा आदेश",
      declarationOrderNo: "घोषणा आदेश क्र",
      declarationDate: "घोषणा तारीख",
      areaName: "क्षेत्राचे नाव",
      hawkingZoneName: "पथविक्रीच्या झोनचे नाव",
      citySurveyNo: "सिटी सर्व्हे क्र *",
      gisId: "GIS आयडी",
      serviceTaxCollectionCyclePrefix: "सेवा कर संकलन चक्र उपसर्ग",
      hawkingZonePrefix: "पथविक्रेत्याच्या झोनचा उपसर्ग",
      hawkerTypeName: "पथविक्रीच्या प्रकाराचे नाव",

      // License Validity
      licenseValidityPrefix: "परवाना वैधता उपसर्ग",
      noHawkingZoneName: "पथविक्रेत्याच्या झोनला नाव नाही",
      noHawkingZoneprefix: "पथविक्रेत्याच्या झोनचा उपसर्ग नाही",
      itemCategoryPrefix: "वस्तुच्या श्रेणीचा उपसर्ग",
      itemCategory: "वस्तुची श्रेणी",
      hawkingZoneWiseFacilitiesPrefix: "हॉकिंग झोननिहाय सुविधा उपसर्ग",
      facilities: "सुविधा",
      hawkingZoneName: "पथविक्रीच्या झोनचे नाव",
      hawkerPrefix: "पथविक्रेत्याचा उपसर्ग",
      citySurveyNo: "सिटी सर्व्हे क्र",

      // Property and water taxes
      crWaterConsumerNo: "पाणी ग्राहक क्र.",
      waterAmount: "रक्कम",
      proprtyAmount: "रक्कम",
      crPropertyTaxNumber: "मिळकत कर क्र.",
      tax: "कर",
      viewBill: "बिल पहा",
      payBill: "बिल भरा",
      PropertyAndWaterTaxes: "कर",

      //buttons
      add: "नवीन नोंदणी करा",
      save: "जतन करा",
      update: "अद्यायावत करा",
      clear: "रिक्त",
      exit: "बाहेर पडा",
      back: "मागे",
      saveAndNext: "जतन करा आणि पुढे",
      finish: "समाप्त",
    },
    {
      type: "transactions",

      transactions: "व्यवहार",
      transactionPath: "कायदेशीर प्रकरण/ व्यवहार ",

      //Path
      issuanceOfHawkerLicensePath:
        "पथविक्रेता व्यवस्थापन प्रणाली / पथविक्रेता परवाना जारी करणे",
      siteVisitPath: "पथविक्रेता व्यवस्थापन प्रणाली /साइटला भेट द्या",
      taskTransfer: "पथविक्रेता व्यवस्थापन प्रणाली / कार्य हस्तांतरण",

      //Buttons
      viewLocationOnMap: "नकाशावर स्थान पहा",
      back: "मागे",
      next: "पुढे",

      //titles

      issuanceOfHawkerLicense: "पथविक्रेता परवाना जारी करणे",
      taskTransfer: "कार्य हस्तांतरण",
      siteVisit: "साइटला भेट द्या",
      issuanceOfHawkerLicenseT: "पथविक्रेता परवाना",

      //other labels

      basicApplicationDetails: "मूलभूत अर्ज तपशील",
      serviceName: "सेवेचे नाव *",
      applicationNumber: "अर्ज क्रमांक",
      applicationDate: "अर्जाची तारीख",
      citySurveyNo: "शहर सर्वेक्षण क्रमांक",
      hawkingZoneName: "पथविक्रीच्या झोनचे नाव",
      areaName: "क्षेत्राचे नाव",
      basicApplicationDetails: "मूलभूत अर्ज तपशील",
      hawkerDetails: "पथविक्रेत्याच्या तपशील",
      addressOfHawker: "पत्ता",
      // addressOfHawker: "फेरीवाल्याचा पत्ता",
      aadharAuthentication: "आधार प्रमाणीकरण",
      aadhaarNo: "आधार क्रमांक",
      additionalDetails: "अतिरिक्त तपशील",
      documentsUpload: "दस्तऐवज अपलोड",
      title: "शीर्षक",
      firstName: "पहिले नाव",
      middleName: "वडीलांचे/पतीचे नाव",
      lastName: "आडनाव",
      gender: "लिंग",
      religion: "धर्म",
      caste: "जात",
      subCast: "पोटजात",
      dateOfBirth: "जन्मतारीख *",
      age: "वय",
      mobile: "दूरध्वनी क्रमांक",
      emailAddress: "ई-मेल आयडी ",
      disability: "दिव्यांग",
      rationCardNo: "शिधापत्रिका क्रमांक",
      yes: "होय",
      no: "नाही",
      typeOfDisability: "दिव्यांगाचा प्रकार",
      back: "मागे",
      next: "पुढे",
      finish: "प्रस्तुत करा",

      // labels of "Address Of Hawker"
      currentAddressofHawker: "सध्याचा पत्ता",
      citySurveyNumber: "शहर सर्वेक्षण क्रमांक *",
      areaName: "क्षेत्राचे नाव *",
      landmarkName: "जवळची खुण*",
      villageName: "गावाचे नाव *",
      cityName: "शहराचे नाव *",
      state: "राज्य *",
      pinCode: "पिन कोड *",
      lattitude: "अक्षांश *",
      logitude: "रेखांश *",
      permanentPostalAddressOfHawker: "कायमस्वरूपीचा/पत्रव्यवहाराचा पत्ता",
      permanentAddressAsTheCorrespondenceAddress:
        "पत्रव्यवहाराचा पत्ता म्हणून कायमचा पत्ता",
      citySurveyNumber: "शहर सर्वेक्षण क्रमांक",

      //Additional Details

      wardNo: "प्रभाग क्रमांक *",
      wardName: "प्रभागाचे नाव *",
      natureOfBusiness: "व्यवसायाचे स्वरूप *",
      hawkingDurationDaily: "पथविक्रीचा दैनिक कालावधी",
      item: "वस्तु",
      periodOfResidenceInMaharashtra: "महाराष्ट्रात राहण्याचा कालावधी",
      periodOfResidenceInPcmc: " पिसिमसी मध्ये राहण्याचा कालावधी",
      bankName: "बँकेचे नाव",
      branchName: "शाखेचे नाव",
      bankAccountNo: "बँक खाते क्रमांक",
      ifscCode: "आयफएससी कोड",
      hawkerType: "पथविक्रीचा प्रकार",
      bankDetails: "बँक तपशील",
      //Labels Of Document Upload

      documentUpload: "दस्तऐवज अपलोड करा *",
      adharCard: "आधार कार्ड *",
      rationCard: "शिधापत्रिका *",
      disablityCretificatePhoto: "दिव्यांग प्रमाणपत्र *",
      otherDocumentPhoto: "इतर दस्तऐवज ",
      affidaviteOnRS100StampAttachement:
        "रु. १००/- चे स्टॅम्प पेपरवर प्रतिज्ञा पत्र *",
      panCard: "पॅन कार्ड *",

      //Remarks
      selectDate: "कृपया तारीख निवडा",
      selectTitle: "कृपया शीर्षक निवडा",
      enterFName: "कृपया पहिले नाव भरा ",
      enterMName: "कृपया मधले  नाव भरा ",
      enterLName: "कृपया शेवटचे नाव भरा ",
      enterArea: "कृपया क्षेत्राचे नाव भरा ",
      enterRoadName: "कृपया रस्त्याचे नाव भरा ",
      enterLandmark: "कृपया  महत्त्वाची खूण भरा",
      enterCity: "कृपया  शहराचे / गावाचे नाव भरा ",
      enterPinCode: "कृपया पिनकोड भरा",
      enterPhoneNo: "कृपया दूरध्वनी नं. भरा",
      enterMobileNo: "कृपया मोबाईल नं. भरा",
      enterEmailAddress: "कृपया इलेक्ट्रॉनिक संदेश भरा",
      enteraadhaarNo: "कृपया आधार नं. भरा",
      enterpanNo: "कृपया पॅन नं. भरा",
      enterRemarks: "कृपया टिप्पणी. द्या",
      //buttons
      add: "जोडा",
      save: "जतन करा",
      update: "अद्यायावत करा",
      clear: "रिक्त",
      exit: "बाहेर पडा",
      back: "मागे",
      saveAndNext: "जतन करा आणि पुढे",
      finish: "समाप्त",
    },
    { type: "report" },
  ],
};
