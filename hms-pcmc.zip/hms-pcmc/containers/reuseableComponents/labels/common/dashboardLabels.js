export default {
  en: {
    module: 'Town Planning',
    dashboard: 'Pimpri-Chinchwad Municipal Corporation Dashboard',
    master: 'Masters',
    transactions: 'Transactions',
    report: 'Reports',
    masterPath: 'Town Planning / Master ',
    transactionPath: 'Town Planning / Transaction ',
    reportPath: 'Town Planning / Report ',
  },
  mr: {
    module: 'शहर नियोजन',
    dashboard: 'पिंपरी-चिंचवड महानगरपालिका डॅशबोर्ड',
    master: 'मास्टर्स',
    transactions: 'व्यवहार',
    report: 'अहवाल',
    masterPath: 'शहर नियोजन/ मास्टर ',
    transactionPath: 'शहर नियोजन/ व्यवहार ',
    reportPath: 'शहर नियोजन/ अहवाल ',
  },
}
