export default {
  en: {
    module: 'Town Planning',
    dashboard: 'Pimpri-Chinchwad Municipal Corporation Dashboard',
    master: 'Masters',
    transactions: 'Transactions',
    report: 'Reports',
    masterPath: 'Town Planning / Master ',
    transactionPath: 'Town Planning / Transaction ',
    reportPath: 'Town Planning / Report ',

    //breadcrum
    landReservationPath: 'Town Planning / Master / Land Reservation ',
    tdrZoneGatAndVillageMappingPath:
      'Town Planning / Master / TDR Zone Gat and Village Mapping',
    villageWiseLandReservationEntryPath:
      'Town Planning / Master / Village Wise Land Reservation Entry',
    villageMappingWithDesignationPath:
      'Town Planning / Master / Village Mapping With Designation',

    //label title
    landReservation: 'Land Reservation',
    tdrZoneGatAndVillageMapping: 'TDR Zone Gat and Village Mapping',
    villageWiseLandReservationEntry: 'Village Wise Land Reservation Entry',
    villageMappingWithDesignation: 'Village Mapping With Designation',

    //other labels
    landReservationID: 'Land Reservation ID',
    reservationName: 'Reservation Name',
    reservationNameEng: 'Reservation Name in English',
    reservationNameMr: 'Reservation Name in Marathi',
    surveyNumber: 'Survey No.',
    landReservationLegend: 'Land Reservation Legend',
    reservationAreaInHector: 'Reservation Area (In Hector)',
    landInPossession: 'Land in Possession',
    remark: 'Remark',
    villageName: 'Village Name',
    gatName: 'Gat Name',
    zoneName: 'Zone Name',
    landReservationName: 'Land Reservation Name',
    citySurveyNo: 'City Survey No.',
    reservationNo: 'Reservation No.',
    landNotInPossessionInHector: 'Land Not In Possession (in Hector)',
    landInPossessionInHector: 'Land in Possession (in Hector)',
    ddtp: 'DDTP ',
    deAndTp: 'Dy Engineer /Town Planner',
    atpAndJe: 'Asst. Town Planner /Junior Engineer',

    attachFile: 'Attach File',
    srNo: 'Sr. No',
    actions: 'Actions',

    //Remarks
    selectDate: 'Please select a date',
    selectTitle: 'Please select a title',
    enterFName: 'Please enter first name ',
    enterMName: 'Please enter middle name ',
    enterLName: 'Please enter last name ',
    selectAdvocateCategory: 'Please select a category',
    enterCouncilName: 'Please enter council name',
    enterArea: 'Please enter area ',
    enterRoadName: 'Please enter road name ',
    enterLandmark: 'Please enter a landmark ',
    enterCity: 'Please enter a city ',
    enterPinCode: 'Please enter a pincode ',
    enterPhoneNo: 'Please enter a phone no. ',
    enterMobileNo: 'Please enter a mobile no. ',
    enterEmailAddress: 'Please enter an e-mail. ',
    enteraadhaarNo: 'Please enter an aadhaar no. ',
    enterpanNo: 'Please enter an pan no. ',
    enterRemarks: 'Please enter a remark. ',

    //buttons
    add: 'Add',
    save: 'Save',
    update: 'Update',
    clear: 'Clear',
    exit: 'Exit',
    back: 'Back',
    saveAndNext: 'Save & Next',
    finish: 'Finish',
  },

  mr: {
    module: 'शहर नियोजन',
    dashboard: 'पिंपरी-चिंचवड महानगरपालिका डॅशबोर्ड',
    master: 'मास्टर्स',
    transactions: 'व्यवहार',
    report: 'अहवाल',
    masterPath: 'शहर नियोजन/ मास्टर ',
    transactionPath: 'शहर नियोजन/ व्यवहार ',
    reportPath: 'शहर नियोजन/ अहवाल ',

    //breadcrum
    landReservationPath: 'शहर नियोजन/ मास्टर / जमीन आरक्षण',
    tdrZoneGatAndVillageMappingPath:
      'शहर नियोजन/ मास्टर / टीडीआर प्रभाग-गट आणि गाव मॅपिंग',
    villageWiseLandReservationEntryPath:
      'शहर नियोजन/ मास्टर / गावनिहाय जमीन आरक्षण नोंद',
    villageMappingWithDesignationPath:
      'शहर नियोजन/ मास्टर / पदनामासह गाव मॅपिंग',

    //titles
    landReservation: 'जमीन आरक्षण',
    tdrZoneGatAndVillageMapping: 'टीडीआर प्रभाग-गट आणि गाव मॅपिंग',
    villageWiseLandReservationEntry: 'गावनिहाय जमीन आरक्षण नोंद',
    villageMappingWithDesignation: 'पदनामासह गाव मॅपिंग',

    //other labels
    landReservationID: 'जमीन आरक्षण क्र',
    reservationName: 'आरक्षणाचे नाव',
    reservationNameEng: 'आरक्षणाचे नाव इंग्रजीत',
    reservationNameMr: 'आरक्षणाचे नाव मराठीत',
    surveyNumber: 'सर्वेक्षण क्र',
    landReservationLegend: 'जमीन आरक्षण आख्यायिका',
    reservationAreaInHector: 'हेक्टर मध्ये आरक्षण क्षेत्र',
    landInPossession: 'ताब्यात जमीन',
    remark: 'टिप्पणी',
    villageName: 'गावाचे नाव',
    gatName: 'गटाचे नाव',
    zoneName: 'झोनचे नाव',
    landReservationName: 'जमीन आरक्षण नाव',
    citySurveyNo: 'शहर सर्वेक्षण क्र',
    reservationNo: 'आरक्षण क्र',
    landNotInPossessionInHector: 'ताब्यात नसलेली जमीन (हेक्टरमध्ये)',
    landInPossessionInHector: 'ताब्यात जमीन (हेक्टरमध्ये)',
    ddtp: 'डी.डी.टी.पी',
    deAndTp: 'उपअभियंता /नगर नियोजक',
    atpAndJe: 'सहाय्यक नगर नियोजक /कनिष्ठ अभियंता',

    attachFile: 'फाईल जोडा',
    srNo: 'अनु क्र',
    actions: 'क्रिया ',

    //Remarks
    selectDate: 'कृपया तारीख निवडा',
    selectTitle: 'कृपया शीर्षक निवडा',
    enterFName: 'कृपया पहिले नाव भरा ',
    enterMName: 'कृपया मधले  नाव भरा ',
    enterLName: 'कृपया शेवटचे नाव भरा ',
    selectAdvocateCategory: 'कृपया वकील श्रेणी निवडा',
    enterCouncilName: 'कृपया वकिलांचे मंडळचे प्रमाणपत्र परिषदचे नाव भरा',
    enterArea: 'कृपया क्षेत्राचे नाव भरा ',
    enterRoadName: 'कृपया रस्त्याचे नाव भरा ',
    enterLandmark: 'कृपया  महत्त्वाची खूण भरा',
    enterCity: 'कृपया  शहराचे / गावाचे नाव भरा ',
    enterPinCode: 'कृपया पिनकोड भरा',
    enterPhoneNo: 'कृपया दूरध्वनी नं. भरा',
    enterMobileNo: 'कृपया मोबाईल नं. भरा',
    enterEmailAddress: 'कृपया इलेक्ट्रॉनिक संदेश भरा',
    enteraadhaarNo: 'कृपया आधार नं. भरा',
    enterpanNo: 'कृपया पॅन नं. भरा',
    // enterRemarks: 'कृपया टिप्पणी. भरा',
    enterRemarks: 'कृपया टिप्पणी. द्या',

    //buttons
    add: 'जोडा',
    save: 'जतन करा',
    update: 'अद्यायावत करा',
    clear: 'रिक्त',
    exit: 'बाहेर पडा',
    back: 'मागे',
    saveAndNext: 'जतन करा आणि पुढे',
    finish: 'समाप्त',
  },
}
