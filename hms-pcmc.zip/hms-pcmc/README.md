## Getting Started

## Sachin Durge 🥇

First, run the development server:

```bash
npm run dev
# or
yarn dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `pages/index.js`. The page auto-updates as you edit the file.

[API routes](https://nextjs.org/docs/api-routes/introduction) can be accessed on [http://localhost:3000/api/hello](http://localhost:3000/api/hello). This endpoint can be edited in `pages/api/hello.js`.

The `pages/api` directory is mapped to `/api/*`. Files in this directory are treated as [API routes](https://nextjs.org/docs/api-routes/introduction) instead of React pages.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js/) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/deployment) for more details.

## Sachin Durge 🥇

## Yup Validation With - React Hook Form Version 7

<!-- - Create Schema.js -->

import yup from "yup"

<!-- Define Schema Object  -->

let Schema = yup.object().shape({

<!-- Define All Fileds Validation Here -->

})

<!-- export Schema  -->

export default Schema

<!-- Import yupResolver from "@hookform/resolvers/yup" Package where you want to apply validation && Also import Schema  -->

import { yupResolver } from "@hookform/resolvers/yup";
import Schema form "../validationFolder/Schema"

<!-- YupResolver Pass As Argument in UseForm or UseFormContex -->

resolver: yupResolver(Schema)

## Tostify

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

  <ToastContainer />

sendOtpNotify();

    const sendOtpNotify = () => {
    toast.success("Success Notification !", {
      position: toast.POSITION.TOP_RIGHT,
    });

};

# Hover

":hover": {
bgcolor: "red", // theme.palette.primary.main
color: "white",
},

# Using js PDF Generate - HTML To PDF

<!-- install dependency -->

npm install jspdf --save

<!-- import jspdf  -->

import { jsPDF } from "jspdf";
import { Button } from "@mui/material";

import React from "react";

// Pdf Main
const TestPdf = () => {

<!-- Function For Pdf Generate -->

const createPDF = async () => {

<!-- create object of jsPDF -->

const pdf = new jsPDF("portrait", "pt", "a4");

<!-- select pdf content  -->

    const data = await document.querySelector("#testPdf");

<!-- convert data into pdf  -->
<!-- give pdf name -->

    pdf.html(data).then(() => {
      pdf.save("First PDF");
    });

};

// View
return (
<>

<!-- give id to content which youwant generate as pdf  -->
<div id='testPdf'>
<h1> PDF Heading </h1>
<br />
<p>
Commodo proident enim irure ullamco. Mollit nulla aliquip ipsum Lorem
ullamco in deserunt tempor quis do sint ipsum enim sit. Dolore
voluptate fugiat irure reprehenderit. Enim ipsum consequat ea eu
ctetur nulla do esse nostrud eiusmod
irure. Consequat eiusmod dolor enim fugiat deserunt tempor sit esse
aute consectetur consectetur sint laboris consequat.
</p>
</div>

<!-- using button download pdf  -->
<Button type='primary' onClick={createPDF}>
Generate PDF
</Button>

</>
);
};

export default TestPdf;

# Using jsPDF / Html2 Canvas Generate - React Component To PDF

<!-- install dependency -->

npm install jspdf --save
npm install html2canvas --save

<!-- import jspdf  -->

import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { Button } from "@mui/material";

import React from "react";

// Pdf Main
const TestPdf = () => {

<!-- Function For Pdf Generate -->

const createPDF = async () => {

<!-- create object of jsPDF -->

const pdf = new jsPDF("portrait", "pt", "a4");

<!-- select pdf content  -->

    const data = await html2canvas(document.querySelector("#testPdf"));

<!-- convet Data Image  -->

const img = data.toDataURL("image/png");
const imgProperties = pdf.getImageProperties(img);
const pdfWidth = pdf.internal.pageSize.getWidth();
const pdfHeight = (imgProperties.height \* pdfWidth) / imgProperties.width;
pdf.addImage(img, "PNG", 0, 0, pdfWidth, pdfHeight);

<!-- save PDf  with this name-->

pdf.save("First PDF");

};

// View
return (
<>

<!-- give id to content/component which you want generate as pdf  -->
<div id='testPdf'>
<h1> PDF Heading </h1>
<br />
<p>
Commodo proident enim irure ullamco. Mollit nulla aliquip ipsum Lorem
ullamco in deserunt tempor quis do sint ipsum enim sit. Dolore
voluptate fugiat irure reprehenderit. Enim ipsum consequat ea eu
ctetur nulla do esse nostrud eiusmod
irure. Consequat eiusmod dolor enim fugiat deserunt tempor sit esse
aute consectetur consectetur sint laboris consequat.
</p>
</div>

<!-- using button download pdf  -->
<Button type='primary' onClick={createPDF}>
Generate PDF
</Button>

</>
);
};

export default TestPdf;

# create Pdf Using Compoent To Print

#### Drawer Code

<!-- const for Drawer -->

let drawerWidth;

<!-- Drawer Style -->

const Main = styled("main", { shouldForwardProp: (prop) => prop !== "open" })(
({ theme, open }) => ({
flexGrow: 1,
padding: theme.spacing(3),
transition: theme.transitions.create("margin", {
easing: theme.transitions.easing.sharp,
duration: theme.transitions.duration.leavingScreen,
}),
marginRight: -drawerWidth,
...(open && {
transition: theme.transitions.create("margin", {
easing: theme.transitions.easing.easeOut,
duration: theme.transitions.duration.enteringScreen,
}),
marginRight: 0,
}),
}),
);

<!-- Drawer Header -->

const DrawerHeader = styled("div")(({ theme }) => ({
display: "flex",
alignItems: "center",
padding: theme.spacing(0, 1),
// necessary for content to be below app bar
...theme.mixins.toolbar,
justifyContent: "flex-start",
}));

<!-- Main Component Code -->

const [open, setOpen] = React.useState(false);

// Open Drawer
const handleDrawerOpen = () => {
setOpen(!open);
drawerWidth = "50%";
};

// Close Drawer
const handleDrawerClose = () => {
setOpen(false);
drawerWidth = 0;
};

<!-- Return View  -->

{/\*_ Btton _/}
<Box
style={{
          right: 25,
          position: "absolute",
          top: "50%",
          backgroundColor: "#bdbdbd",
        }} >
<IconButton
color='inherit'
aria-label='open drawer'
// edge="end"
onClick={handleDrawerOpen}
sx={{ width: "30px", height: "75px", borderRadius: 0 }} >
<ArrowLeftIcon />
</IconButton>
</Box>

  <!-- Main Component   -->
   <Main > </Main>
    {/** Drawer  */}
      <Drawer
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: drawerWidth,
          },
        }}
        variant='persistent'
        anchor='right'
        open={open}
      >
        {/* <DrawerHeader>
          <IconButton onClick={handleDrawerClose}>
            {theme.direction === "rtl" ? (
              <ChevronLeftIcon />
            ) : (
              <ChevronRightIcon />
            )}
          </IconButton>
        </DrawerHeader> */}
        {/* <Divider /> */}

        <Box
          style={{
            left: 0,
            position: "absolute",
            top: "50%",
            backgroundColor: "#bdbdbd",
          }}
        >
          <IconButton
            color='inherit'
            aria-label='open drawer'
            // edge="end"
            onClick={handleDrawerClose}
            sx={{ width: "30px", height: "75px", borderRadius: 0 }}
          >
            <ArrowRightIcon />
          </IconButton>
        </Box>
        <img
          src='/ABC.jpg'
          //hegiht='300px'
          width='800px'
          alt='Map Not Found'
          style={{ width: "100%", height: "100%" }}
        />
      </Drawer>
      {/** End Drawer  */}

<!-- Button -->

<Button
sx={{
                marginTop: "5vh",
                margin: "normal",
                width: 230,
                // height: "40px",
              }}
variant='contained'
color='primary'
fullWidth
onClick={() => {
handleDrawerOpen();
}} >
View Location On Map
</Button>

<!-- Button Close -->

<!-- ////////////////// -->

# Material ui Component

// TextField

<TextField
label='Name' {/_{<FormattedLabel id='citySurveyNo' />}_/}
{...register("name")}
error={!!errors.name}
helperText={errors?.name ? errors.name.message : null}
/>

// ===============================================

// Select

// selectNames
const [selectNames, setSelectNames] = useState([]);

// getSelectNames
const getSelectNames = () => {
axios.get(`${urls.CFCUrlMaster}/selectName/getAll`).then((r) => {
if(r.status == 200){
setSelectNames(
r.data.selectName.map((row) => ({
id: row.id,
selectName: row.selectName,
selectNameMr: row.selectNameMr,
})))
} else {
message.error("Filed To Load !! Please Try Again !")
}
}).catch((err) => {
console.log(err);
toast("Filed To Load ! Please Try Again !"", {
type: "error",
});
});
};

<FormControl sx={{ marginTop: 2 }} error={!!errors.selectName}>
<InputLabel id='demo-simple-select-standard-label'>
{<FormattedLabel id='selectName' />}
</InputLabel>
<Controller
render={({ field }) => (
<Select
value={field.value}
onChange={(value) => field.onChange(value)}
label={<FormattedLabel id='selectName' />} >
{selectNames &&
selectNames.map((selectName, index) => (

<MenuItem key={index} value={selectName.id}>
{language == "en"
? selectName?.selectName
: selectName?.selectNameMr}
</MenuItem>
))}
</Select>
)}
name='selectName'
control={control}
defaultValue=''
/>
<FormHelperText>
{errors?.selectName ? errors.selectName.message : null}
</FormHelperText>
</FormControl>

// ==============================================================================

// Radion Button ==>
<FormControl flexDirection='row'>
<FormLabel id='demo-row-radio-buttons-group-label'>
{<FormattedLabel id='radioButton' />}
</FormLabel>
<Controller
name='radioButton'
control={control}
defaultValue="Yes"
render={({ field }) => (
<RadioGroup
value={field.value}
onChange={(value) => field.onChange(value)}
selected={field.value}
row
aria-labelledby='demo-row-radio-buttons-group-label' >
<FormControlLabel
value='Yes'
control={<Radio />}
label={<FormattedLabel id='yes' />}
error={!!errors.radioButton}
helperText={
errors?.radioButton ? errors.radioButton.message : null
}
/>
<FormControlLabel
value='NO'
control={<Radio />}
label={<FormattedLabel id='no' />}
error={!!errors.radioButton}
helperText={
errors?.radioButton ? errors.radioButton.message : null
}
/>
</RadioGroup>
)}
/>
</FormControl>

// =============================================================

// CheckBox

  <FormControl>
            <FormControlLabel
              error={!!errors.checkBox}
              label='Check Box'
              labelPlacement='End'
              control={
                <Controller
                  name='checkBox'
                  control={control}
                  defaultValue={false}
                  render={({ field: { value, ref, ...field } }) => (
                    <Checkbox
                      {...field}
                      inputRef={ref}
                      checked={!!value}
                      onChange={(value) => field.onChange(value)}
                    />
                  )}
                />
              }
            />
            <FormHelperText>
              {errors?.checkBox ? errors.checkBox.message : null}
            </FormHelperText>
          </FormControl>

// =============================================

// Date Picker ---->

<FormControl sx={{ marginTop: 0 }} error={!!errors.date}>
<Controller
name='date'
control={control}
defaultValue={null}
render={({ field }) => (
<LocalizationProvider dateAdapter={AdapterMoment}>
<DatePicker
inputFormat='DD/MM/YYYY'
label={
<span style={{ fontSize: 16, marginTop: 2 }}>
Date {/_{<FormattedLabel id='oldSVSLicenseDate' />}_/}
</span>
}
value={field.value}
onChange={(date) => field.onChange(moment(date).format("YYYY-MM-DD"))}
selected={field.value}
center
renderInput={(params) => (
<TextField
{...params}
size='small'
fullWidth
InputLabelProps={{
                style: {
                  fontSize: 12,
                  marginTop: 3,
                },
              }}
/>
)}
/>
</LocalizationProvider>
)}
/>
<FormHelperText>{errors?.date ? errors.date.message : null}</FormHelperText>
</FormControl>

// ================================================

// Time Picker

// Format on Submit  
 const timePicker = moment(data.timePicker).format("HH:mm:ss")

const finalBodyForApi = {
...data,
timePicker
}

<FormControl sx={{ marginTop: 0 }} error={!!errors.timePicker}>
<Controller
name='timePicker'
control={control}
defaultValue={null}
render={({ field }) => (
<LocalizationProvider dateAdapter={AdapterMoment}>
<TimePicker
inputFormat='hh:mm A'
label={
<span style={{ fontSize: 16, marginTop: 2 }}>
Time Picker
{/_{<FormattedLabel id='oldSVSLicenseDate' />}_/}
</span>
}
value={field.value}
onChange={(time) =>
moment(field.onChange(time)).format("hh:mm:ss A")
}
selected={field.value}
renderInput={(params) => (
<TextField
{...params}
size='small'
fullWidth
InputLabelProps={{
                          style: {
                            fontSize: 12,
                            marginTop: 3,
                          },
                        }}
/>
)}
/>
</LocalizationProvider>
)}
/>
<FormHelperText>
{errors?.timePicker ? errors.timePicker.message : null}
</FormHelperText>
</FormControl>
// =========================================

// Date and Time Picker

<FormControl sx={{ marginTop: 0 }} error={!!errors.dateAndTime}>
<Controller
name='dateAndTime'
control={control}
defaultValue={null}
render={({ field }) => (
<LocalizationProvider dateAdapter={AdapterMoment}>
<DateTimePicker
// inputFormat='DD/MM/YYYY'
label={
<span style={{ fontSize: 16, marginTop: 2 }}>
Date and Time Picker
{/_{<FormattedLabel id='oldSVSLicenseDate' />}_/}
</span>
}
value={field.value}
onChange={(date) =>
field.onChange(moment(date).format("YYYY-MM-DDTHH:mm:ss"))
}
renderInput={(params) => (
<TextField
{...params}
size='small'
fullWidth
InputLabelProps={{
                          style: {
                            fontSize: 12,
                            marginTop: 3,
                          },
                        }}
/>
)}
/>
</LocalizationProvider>
)}
/>
<FormHelperText>
{errors?.dateAndTime ? errors.dateAndTime.message : null}
</FormHelperText>
</FormControl>

// ======================================>

// Calender Picker ==>

<Controller
control={control}
name='calenderPicker'
defaultValue={null}
render={({ field }) => (
<LocalizationProvider dateAdapter={AdapterMoment}>
<CalendarPicker
orientation='landscape'
openTo='day'
inputFormat='DD/MM/YYYY'
shouldDisableDate={isWeekend}
value={field.value}
onChange={(date) => {
getSlot(moment(date).format("YYYY-MM-DD"));
setmodalforAppoitment(true),
field.onChange(moment(date).format("YYYY-MM-DD"));
}}
renderInput={(params) => <TextField {...params} />}
/>
</LocalizationProvider>
)}
/>

# Modal

const [otpModal, setOtpModal] = useState(false);
const otpModalOpen = () => setOtpModal(true);
const otpModalClose = () => setOtpModal(false);

<Modal
open={otpModal}
onClose={() => otpModalClose()}
aria-labelledby='modal-modal-title'
aria-describedby='modal-modal-description'
sx={{   display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: 5,
        }} >

      </Modal>
