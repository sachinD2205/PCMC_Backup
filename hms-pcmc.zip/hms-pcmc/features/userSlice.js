import { createSlice } from '@reduxjs/toolkit'
import { useRouter } from 'next/router'

const userSlice = createSlice({
  name: 'user',
  initialState: {
    isLoggedIn: false,
    user: null,
    menu: null,
  },
  reducers: {
    login: (state, action) => {
      state.user = action.payload
      state.isLoggedIn = true
    },
    logout: (state) => {
      state.user = []
      state.isLoggedIn = false
    },
    setMenu: (state, action) => {
      state.menu = action.payload
    },
  },
})

export const { setMenu, login, logout } = userSlice.actions

export default userSlice
