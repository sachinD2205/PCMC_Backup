// import { createSlice } from "@reduxjs/toolkit";

// const FileUploadSlice = createSlice({
//   name: "file",
//   initialState: {file: null},
//   reducers: {
//     file: (state, action) => {
//       state.adharCard = action.payload;
//     },
//   },
// });

// export const {
//   setSelectedApplicationId
// } = userSlice.actions;

// export default FileUploadSlice;
