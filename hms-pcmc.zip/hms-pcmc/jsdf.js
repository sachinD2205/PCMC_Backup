   <FormControl sx={{ marginTop: 0 }} error={!!errors.date}>
                          <Controller
                              name='date'
                              control={control}
                              defaultValue={null}
                              render={({ field }) => (
                                  <LocalizationProvider dateAdapter={AdapterMoment}>
                                      <DatePicker
                                          inputFormat='DD/MM/YYYY'
                                          label={
                                              <span style={{ fontSize: 16, marginTop: 2 }}>
                                                  Date {/_{<FormattedLabel id='oldSVSLicenseDate' / >}_/}
</span>
}
value={field.value}
onChange={(date) => field.onChange(moment(date).format("YYYY-MM-DD"))}
selected={field.value}
center
renderInput={(params) => (
<TextField
{...params}
size='small'
fullWidth
InputLabelProps={{
                style: {
                  fontSize: 12,
                  marginTop: 3,
                },
              }}
/>
)}
/>
</LocalizationProvider>
)}
/>
<FormHelperText>{errors?.date ? errors.date.message : null}</FormHelperText>
</FormControl>