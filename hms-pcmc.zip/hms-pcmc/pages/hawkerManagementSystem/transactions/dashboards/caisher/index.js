import React from "react";

// Cashier Dashboard - view
const index = () => {
  return <></>;
};

export default index;
