import {
  Box,
  Button,
  Divider,
  FormControl,
  FormHelperText,
  Grid,
  IconButton,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Slide,
  TextField,
} from "@mui/material";
import sweetAlert from "sweetalert";
import React, { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import schema from "../../../containers/schema/common/UsageChargeMaster";
import AddIcon from "@mui/icons-material/Add";
import { DataGrid } from "@mui/x-data-grid";
import ClearIcon from "@mui/icons-material/Clear";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";
import SaveIcon from "@mui/icons-material/Save";
import axios from "axios";
import moment from "moment";
import CheckIcon from "@mui/icons-material/Check";
import { yupResolver } from "@hookform/resolvers/yup";
import ToggleOnIcon from "@mui/icons-material/ToggleOn";
import ToggleOffIcon from "@mui/icons-material/ToggleOff";
import FormattedLabel from "../../../containers/reuseableComponents/FormattedLabel";
import styles from "../../../styles/[userChargeMaster].module.css";

const UserChargeMaster = () => {
  const {
    register,
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({ resolver: yupResolver(schema) });
  const [buttonInputState, setButtonInputState] = useState();
  const [dataSource, setDataSource] = useState([]);
  const [isOpenCollapse, setIsOpenCollapse] = useState(false);
  const [editButtonInputState, setEditButtonInputState] = useState(false);
  const [deleteButtonInputState, setDeleteButtonState] = useState(false);
  const [btnSaveText, setBtnSaveText] = useState("Save");
  const [slideChecked, setSlideChecked] = useState(false);
  const [id, setID] = useState();

  const [services, setServices] = useState([]);
  const [chargeName, setChargeName] = useState([]);
  const [chargeType, setChargeType] = useState([]);

  useEffect(() => {
    getServices();
    getChargeName();
    getChargeType();
    getBillType();
  }, []);

  const getServices = () => {
    axios
      .get("http://localhost:8090/cfc/api/master/service/getAll")
      .then((r) => {
        if (r.status == 200) {
          console.log("service res", r);
          let services = {};
          r.data.service.map((r) => (services[r.id] = r.serviceName));
          setServices(r.data.service);
        } else {
          message.error("Failed ! Please Try Again !");
        }
      })
      .catch((err) => {
        console.log(err);
        toast("Login Failed ! Please Try Again !", {
          type: "error",
        });
      });
  };

  const getChargeName = () => {
    axios
      .get("http://localhost:8090/cfc/api/master/chargeName/getAll")
      .then((r) => {
        if (r.status == 200) {
          console.log("service res", r);
          setChargeName(r.data.chargeName);
        } else {
          message.error("Failed ! Please Try Again !");
        }
      })
      .catch((err) => {
        console.log(err);
        toast("Login Failed ! Please Try Again !", {
          type: "error",
        });
      });
  };

  const getChargeType = () => {
    axios
      .get("http://localhost:8090/cfc/api/master/serviceChargeType/getAll")
      .then((r) => {
        if (r.status == 200) {
          console.log("service res", r);
          setChargeType(r.data.serviceChargeType);
        } else {
          message.error("Failed ! Please Try Again !");
        }
      })
      .catch((err) => {
        console.log(err);
        toast("Login Failed ! Please Try Again !", {
          type: "error",
        });
      });
  };
  const cancellButton = () => {
    reset({
      ...resetValuesCancell,
      id,
    });
  };

  const resetValuesCancell = {
    billPrefix: "",
    billType: "",
    fromDate: null,
    toDate: null,
    remark: "",
  };

  const exitButton = () => {
    reset({
      ...resetValuesExit,
    });
    setButtonInputState(false);
    setSlideChecked(false);
    setSlideChecked(false);
    setIsOpenCollapse(false);
    setEditButtonInputState(false);
    setDeleteButtonState(false);
  };

  //
  const resetValuesExit = {
    billPrefix: "",
    fromDate: "",
    toDate: "",
    billType: "",
  };

  //
  const [data, setData] = useState({
    rows: [],
    totalRows: 0,
    rowsPerPageOptions: [10, 20, 50, 100],
    pageSize: 10,
    page: 1,
  });

  // Biill Type
  const getBillType = (_pageSize = 10, _pageNo = 0) => {
    console.log("_pageSize,_pageNo", _pageSize, _pageNo);
    axios
      .get("http://localhost:8090/cfc/api/master/billType/getAll", {
        params: {
          pageSize: _pageSize,
          pageNo: _pageNo,
        },
      })
      .then((res) => {
        console.log(";res", res);
        let result = res.data.billType;
        let _res = result.map((val, i) => {
          return {
            activeFlag: val.activeFlag,
            srNo: val.id,
            billPrefix: val.billPrefix,
            billType: val.billType,
            id: val.id,
            fromDate: moment(val.fromDate).format("llll"),
            toDate: val.toDate,
            remark: val.remark,
            status: val.activeFlag === "Y" ? "Active" : "Inactive",
          };
        });
        setData({
          rows: _res,
          totalRows: res.data.totalElements,
          rowsPerPageOptions: [10, 20, 50, 100],
          pageSize: res.data.pageSize,
          page: res.data.pageNo,
        });
      });
  };

  // Delete
  const deleteById = (value, _activeFlag) => {
    let body = {
      activeFlag: _activeFlag,
      id: value,
    };
    if (_activeFlag === "N") {
      swal({
        title: "Inactivate?",
        text: "Are you sure you want to inactivate this Record ? ",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      }).then((willDelete) => {
        if (willDelete === true) {
          axios
            .post("http://localhost:8090/cfc/api/master/billType/save", body)
            .then((res) => {
              if (res.status == 200) {
                swal("Record is Successfully Deleted!", {
                  icon: "success",
                });
                getBillType();
                setButtonInputState(false);
              }
            });
        } else if (willDelete == null) {
          swal("Record is Safe");
        }
      });
    } else {
      swal({
        title: "Activate?",
        text: "Are you sure you want to activate this Record ? ",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      }).then((willDelete) => {
        if (willDelete === true) {
          axios
            .post("http://localhost:8090/cfc/api/master/billType/save", body)
            .then((res) => {
              console.log("delet res", res);
              if (res.status == 200) {
                swal("Record is Successfully Deleted!", {
                  icon: "success",
                });
                getBillType();
                setButtonInputState(false);
              }
            });
        } else if (willDelete == null) {
          swal("Record is Safe");
        }
      });
    }
  };

  // From Data
  const onSubmitForm = (formData) => {
    const fromDate = moment(formData.fromDate).format("YYYY-MM-DD");
    const toDate = moment(formData.toDate).format("YYYY-MM-DD");
    const finalBodyForApi = {
      ...formData,
      fromDate,
      toDate,
      activeFlag: btnSaveText === "Update" ? null : null,
    };

    axios
      .post(
        "http://localhost:8090/cfc/api/master/billType/save",
        finalBodyForApi,
      )
      .then((res) => {
        if (res.status == 200) {
          formData.id
            ? sweetAlert("Updated!", "Record Updated successfully !", "success")
            : sweetAlert("Saved!", "Record Saved successfully !", "success");
          getBillType();
          setButtonInputState(false);
          setIsOpenCollapse(false);
          setEditButtonInputState(false);
          setDeleteButtonState(false);
        }
      });
  };

  // Table Columns
  const columns = [
    {
      field: "srNo",
      headerName: <FormattedLabel id='srNo' />,
      flex: 1,
      align: "center",
      headerAlign: "center",
    },
    {
      field: "billPrefix",
      headerName: <FormattedLabel id='billPrefix' />,
      flex: 1,
      align: "center",
      headerAlign: "center",
    },
    {
      field: "fromDate",
      headerName: <FormattedLabel id='fromDate' />,
      // type: "number",
      flex: 1,
      minWidth: 250,
      align: "center",
      headerAlign: "center",
    },
    {
      field: "toDate",
      headerName: <FormattedLabel id='toDate' />,
      // type: "number",
      flex: 1,
      minWidth: 250,
      align: "center",
      headerAlign: "center",
    },
    {
      field: "billType",
      headerName: <FormattedLabel id='billType' />,
      // type: "number",
      flex: 1,
      align: "center",
      headerAlign: "center",
    },
    {
      field: "status",
      headerName: <FormattedLabel id='status' />,
      // type: "number",
      flex: 1,
      align: "center",
      headerAlign: "center",
    },
    {
      field: "actions",
      headerName: <FormattedLabel id='actions' />,
      width: 120,
      sortable: false,
      disableColumnMenu: true,
      renderCell: (params) => {
        return (
          <>
            <IconButton
              disabled={editButtonInputState}
              onClick={() => {
                setBtnSaveText("Update"),
                  setID(params.row.id),
                  setIsOpenCollapse(true),
                  setSlideChecked(true);
                setButtonInputState(true);
                reset(params.row);
              }}
            >
              <EditIcon style={{ color: "#556CD6" }} />
            </IconButton>
            <IconButton
              disabled={editButtonInputState}
              onClick={() => {
                setBtnSaveText("Update"),
                  setID(params.row.id),
                  //   setIsOpenCollapse(true),
                  setSlideChecked(true);
                setButtonInputState(true);
                console.log("params.row: ", params.row);
                reset(params.row);
              }}
            >
              {params.row.activeFlag == "Y" ? (
                <ToggleOnIcon
                  style={{ color: "green", fontSize: 30 }}
                  onClick={() => deleteById(params.id, "N")}
                />
              ) : (
                <ToggleOffIcon
                  style={{ color: "red", fontSize: 30 }}
                  onClick={() => deleteById(params.id, "Y")}
                />
              )}
            </IconButton>
          </>
        );
      },
    },
  ];

  return (
    <div>
      <Paper style={{ margin: "50px" }}>
        {isOpenCollapse && (
          <Slide direction='down' in={slideChecked} mountOnEnter unmountOnExit>
            <form onSubmit={handleSubmit(onSubmitForm)}>
              <Grid container style={{ padding: "10px" }}>
                <Grid
                  item
                  xs={4}
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <FormControl size='small' sx={{ m: 1, width: "50%" }}>
                    <InputLabel id='demo-simple-select-standard-label'>
                      {<FormattedLabel id='serviceId' />}
                    </InputLabel>
                    <Controller
                      render={({ field }) => (
                        <Select
                          labelId='demo-simple-select-label'
                          id='demo-simple-select'
                          label={<FormattedLabel id='serviceId' />}
                          value={field.value}
                          // {...register("applicationName")}
                          // onChange={(value) => field.onChange(value)}
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          style={{ backgroundColor: "white" }}
                        >
                          {services.length > 0
                            ? services.map((service, index) => {
                                return (
                                  <MenuItem key={index} value={service.id}>
                                    {service.serviceName}
                                  </MenuItem>
                                );
                              })
                            : "NA"}
                        </Select>
                      )}
                      name='serviceId'
                      control={control}
                      defaultValue=''
                    />
                    <FormHelperText style={{ color: "red" }}>
                      {errors?.serviceId ? errors.serviceId.message : null}
                    </FormHelperText>
                  </FormControl>
                </Grid>
                <Grid
                  item
                  xs={4}
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <FormControl size='small' sx={{ m: 1, width: "50%" }}>
                    <InputLabel id='demo-simple-select-standard-label'>
                      {<FormattedLabel id='chargeName' />}
                    </InputLabel>
                    <Controller
                      render={({ field }) => (
                        <Select
                          labelId='demo-simple-select-label'
                          id='demo-simple-select'
                          label={<FormattedLabel id='chargeName' />}
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          style={{ backgroundColor: "white" }}
                        >
                          {chargeName.length > 0
                            ? chargeName.map((service, index) => {
                                return (
                                  <MenuItem key={index} value={service.id}>
                                    {service.charge}
                                  </MenuItem>
                                );
                              })
                            : "NA"}
                        </Select>
                      )}
                      name='chargeName'
                      control={control}
                      defaultValue=''
                    />
                    <FormHelperText style={{ color: "red" }}>
                      {errors?.chargeName ? errors.chargeName.message : null}
                    </FormHelperText>
                  </FormControl>
                </Grid>
                <Grid
                  item
                  xs={4}
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <FormControl size='small' sx={{ m: 1, width: "50%" }}>
                    <InputLabel id='demo-simple-select-standard-label'>
                      {<FormattedLabel id='chargeType' />}
                    </InputLabel>
                    <Controller
                      render={({ field }) => (
                        <Select
                          labelId='demo-simple-select-label'
                          id='demo-simple-select'
                          label={<FormattedLabel id='chargeType' />}
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          style={{ backgroundColor: "white" }}
                        >
                          {chargeType.length > 0
                            ? chargeType.map((service, index) => {
                                return (
                                  <MenuItem key={index} value={service.id}>
                                    {service.serviceChargeType}
                                  </MenuItem>
                                );
                              })
                            : "NA"}
                        </Select>
                      )}
                      name='chargeType'
                      control={control}
                      defaultValue=''
                    />
                    <FormHelperText style={{ color: "red" }}>
                      {errors?.chargeType ? errors.chargeType.message : null}
                    </FormHelperText>
                  </FormControl>
                </Grid>
                <Grid
                  item
                  xs={4}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <TextField
                    size='small'
                    style={{ backgroundColor: "white" }}
                    id='outlined-basic'
                    // label="Bill Type"
                    label={<FormattedLabel id='amount' />}
                    variant='outlined'
                    {...register("amount")}
                    error={!!errors.amount}
                    helperText={errors?.amount ? errors.amount.message : null}
                  />
                </Grid>
                <Grid
                  item
                  xs={4}
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <FormControl size='small' sx={{ m: 1, width: "50%" }}>
                    <InputLabel id='demo-simple-select-standard-label'>
                      {<FormattedLabel id='dependsOn' />}
                    </InputLabel>
                    <Controller
                      render={({ field }) => (
                        <Select
                          labelId='demo-simple-select-label'
                          id='demo-simple-select'
                          label={<FormattedLabel id='dependsOn' />}
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          style={{ backgroundColor: "white" }}
                        >
                          {services.length > 0
                            ? services.map((service, index) => {
                                return (
                                  <MenuItem key={index} value={service.id}>
                                    {service.serviceName}
                                  </MenuItem>
                                );
                              })
                            : "NA"}
                        </Select>
                      )}
                      name='dependsOn'
                      control={control}
                      defaultValue=''
                    />
                    <FormHelperText style={{ color: "red" }}>
                      {errors?.dependsOn ? errors.dependsOn.message : null}
                    </FormHelperText>
                  </FormControl>
                </Grid>
                <Grid
                  item
                  xs={4}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <TextField
                    size='small'
                    style={{ backgroundColor: "white" }}
                    id='outlined-basic'
                    // label="Bill Type"
                    label={<FormattedLabel id='formula' />}
                    variant='outlined'
                    {...register("formula")}
                    error={!!errors.formula}
                    helperText={errors?.formula ? errors.formula.message : null}
                  />
                </Grid>
                <Grid
                  item
                  xs={4}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <TextField
                    size='small'
                    style={{ backgroundColor: "white" }}
                    id='outlined-basic'
                    // label="Bill Type"
                    label={<FormattedLabel id='description' />}
                    variant='outlined'
                    {...register("description")}
                    error={!!errors.description}
                    helperText={
                      errors?.description ? errors.description.message : null
                    }
                  />
                </Grid>
              </Grid>
              <Grid container style={{ padding: "10px" }}>
                <Grid
                  item
                  xs={4}
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Button
                    sx={{ marginRight: 8 }}
                    type='submit'
                    variant='contained'
                    color='success'
                    endIcon={<SaveIcon />}
                  >
                    <FormattedLabel id={btnSaveText} />
                  </Button>
                </Grid>
                <Grid
                  item
                  xs={4}
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Button
                    sx={{ marginRight: 8 }}
                    variant='contained'
                    color='primary'
                    endIcon={<ClearIcon />}
                    onClick={() => cancellButton()}
                  >
                    <FormattedLabel id='clear' />
                  </Button>
                </Grid>
                <Grid
                  item
                  xs={4}
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Button
                    variant='contained'
                    color='error'
                    endIcon={<ExitToAppIcon />}
                    onClick={() => exitButton()}
                  >
                    <FormattedLabel id='exit' />
                  </Button>
                </Grid>
              </Grid>
              <Divider />
            </form>
          </Slide>
        )}
        <Grid container style={{ padding: "10px" }}>
          <Grid item xs={9}></Grid>
          <Grid
            item
            xs={2}
            style={{ display: "flex", justifyContent: "center" }}
          >
            <Button
              variant='contained'
              endIcon={<AddIcon />}
              type='primary'
              disabled={buttonInputState}
              onClick={() => {
                reset({
                  ...resetValuesExit,
                });
                setEditButtonInputState(true);
                setDeleteButtonState(true);
                setBtnSaveText("Save");
                setButtonInputState(true);
                setSlideChecked(true);
                setIsOpenCollapse(!isOpenCollapse);
              }}
            >
              <FormattedLabel id='add' />
            </Button>
          </Grid>
        </Grid>

        <Box sx={{ height: "auto", overflow: "auto" }}>
          <DataGrid
            sx={{
              overflowY: "scroll",
              "& .MuiDataGrid-columnHeadersInner": {
                backgroundColor: "#556CD6",
                color: "white",
              },
              "& .MuiDataGrid-cell:hover": {
                color: "primary.main",
              },
            }}
            columns={columns}
            density='compact'
            autoHeight={true}
            pagination
            paginationMode='server'
            page={data.page}
            rowCount={data.totalRows}
            rowsPerPageOptions={data.rowsPerPageOptions}
            pageSize={data.pageSize}
            rows={data.rows}
            onPageChange={(_data) => {
              getBillType(data.pageSize, _data);
            }}
            onPageSizeChange={(_data) => {
              getBillType(_data, data.page);
            }}
            // loading={data.loading}
          />
        </Box>
      </Paper>
    </div>
  );
};

export default UserChargeMaster;
