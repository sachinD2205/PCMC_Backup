import { yupResolver } from "@hookform/resolvers/yup";
import AddIcon from "@mui/icons-material/Add";
import ClearIcon from "@mui/icons-material/Clear";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";
import SaveIcon from "@mui/icons-material/Save";
import {
  Box,
  Button,
  FormControl,
  FormControlLabel,
  FormHelperText,
  FormLabel,
  Grid,
  InputLabel,
  MenuItem,
  Paper,
  Radio,
  RadioGroup,
  Select,
  Slide,
  TextField,
  ThemeProvider,
  Typography,
} from "@mui/material";
import IconButton from "@mui/material/IconButton";
import { DataGrid } from "@mui/x-data-grid";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { message } from "antd";
import axios from "axios";
import moment from "moment";
import React, { useEffect, useState } from "react";
import {
  Controller,
  FormProvider,
  useForm,
  useFormContext,
} from "react-hook-form";
import BasicLayout from "../../../../containers/Layout/BasicLayout";
import urls from "../../../../URLS/urls";
import styles from "../../transactions/siteVisit/view.module.css";
import sweetAlert from "sweetalert";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import { TimePicker } from "@mui/x-date-pickers";
// import { ThemeProvider } from '@mui/styles'
import theme from "../../../../theme";

// func
const SiteVisit = () => {
  const {
    control,
    register,
    reset,
    setValue,
    getValues,
    formState: { errors },
  } = useFormContext();

  const [value, setValuee] = useState(null);

  // OnSubmit Form
  const onSubmitForm = (formData) => {
    // const fromDate = new Date(formData.fromDate).toISOString();
    // const toDate = moment(formData.toDate, "YYYY-MM-DD").format("YYYY-MM-DD");
    // const declarationDate = moment(formData.declarationDate, "YYYY-MM-DD").format("YYYY-MM-DD");
    // Update Form Data
    const finalBodyForApi = {
      // fromDate,
      // toDate,
      // declarationDate,
      ...formData,
    };

    axios
      .post(`${urls.BaseURL}/siteVisit/saveSiteVisit`, finalBodyForApi)
      .then((res) => {
        if (res.status == 201) {
          formData.id
            ? sweetAlert("Updated!", "Record Updated successfully !", "success")
            : sweetAlert("Saved!", "Record Saved successfully !", "success");
        }
      });
  };

  return (
    <>
      <div
        style={{
          backgroundColor: "#0084ff",
          color: "white",
          fontSize: 19,
          marginTop: 30,
          marginBottom: 30,
          padding: 8,
          paddingLeft: 30,
          marginLeft: "40px",
          marginRight: "65px",
          borderRadius: 100,
        }}
      >
        <strong>Site Visit</strong>
      </div>
      <Grid
        container
        sx={{
          paddingLeft: "50px",
          align: "center",
          marginTop: 2,
          marginBottom: 5,
        }}
      >
        <Grid item xs={6} sm={6} md={6} lg={6} xl={6}>
          <FormControl sx={{ marginTop: 0 }} error={!!errors.fromDate}>
            <Controller
              control={control}
              name='fromDate'
              defaultValue={null}
              render={({ field }) => (
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <DatePicker
                    sx={{ width: 400 }}
                    inputFormat='DD/MM/YYYY'
                    label={<span style={{ fontSize: 13 }}>From Date</span>}
                    value={field.value}
                    onChange={(date) =>
                      field.onChange(moment(date).format("YYYY-MM-DD"))
                    }
                    selected={field.value}
                    center
                    renderInput={(params) => (
                      <TextField
                        sx={{ width: 400 }}
                        {...params}
                        size='small'
                        fullWidth
                        InputLabelProps={{
                          style: {
                            fontSize: 12,
                            marginTop: 3,
                          },
                        }}
                      />
                    )}
                  />
                </LocalizationProvider>
              )}
            />
            <FormHelperText>
              {errors?.fromDate ? errors.fromDate.message : null}
            </FormHelperText>
          </FormControl>
        </Grid>

        <Grid item xs={6} sm={6} md={6} lg={6} xl={6}>
          <FormControl sx={{ marginTop: 0 }} error={!!errors.toDate}>
            <Controller
              control={control}
              name='toDate'
              defaultValue={null}
              render={({ field }) => (
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <DatePicker
                    sx={{ width: 400 }}
                    inputFormat='DD/MM/YYYY'
                    label={<span style={{ fontSize: 13 }}>To Date</span>}
                    value={field.value}
                    onChange={(date) =>
                      field.onChange(moment(date).format("YYYY-MM-DD"))
                    }
                    selected={field.value}
                    center
                    renderInput={(params) => (
                      <TextField
                        sx={{ width: 400 }}
                        {...params}
                        size='small'
                        fullWidth
                        InputLabelProps={{
                          style: {
                            fontSize: 12,
                            marginTop: 3,
                          },
                        }}
                      />
                    )}
                  />
                </LocalizationProvider>
              )}
            />
            <FormHelperText>
              {errors?.toDate ? errors.toDate.message : null}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={4} sm={4} md={4} lg={4} xl={4}>
          <FormControl error={!!errors.Online} sx={{ marginTop: 2 }}>
            <InputLabel id='demo-simple-select-standard-label'>
              Online *
            </InputLabel>
            <Controller
              render={({ field }) => (
                <Select
                  autoFocus
                  value={field.value}
                  onChange={(value) => field.onChange(value)}
                  label='Online *'
                  id='demo-simple-select-standard'
                  labelId="id='demo-simple-select-standard-label'"
                >
                  {/* {Onlines &&
                              Onlines.map((Online, index) => (
                                <MenuItem key={index} value={Online.id}>
                                  {Online.Online}
                                </MenuItem>
                              ))} */}
                  <MenuItem>online</MenuItem>
                </Select>
              )}
              name='Online'
              control={control}
              defaultValue=''
            />
            <FormHelperText>
              {errors?.Online ? errors.Online.message : null}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={4} sm={4} md={4} lg={4} xl={4}>
          <FormControl error={!!errors.CFC} sx={{ marginTop: 2 }}>
            <InputLabel id='demo-simple-select-standard-label'>
              CFC *
            </InputLabel>
            <Controller
              render={({ field }) => (
                <Select
                  autoFocus
                  value={field.value}
                  onChange={(value) => field.onChange(value)}
                  label='CFC *'
                  id='demo-simple-select-standard'
                  labelId="id='demo-simple-select-standard-label'"
                >
                  {/* {CFCs &&
                              CFCs.map((CFC, index) => (
                                <MenuItem key={index} value={CFC.id}>
                                  {CFC.CFC}
                                </MenuItem>
                              ))} */}
                </Select>
              )}
              name='CFC'
              control={control}
              defaultValue=''
            />
            <FormHelperText>
              {errors?.Online ? errors.Online.message : null}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={4} sm={4} md={4} lg={4} xl={4}>
          <TextField
            id='standard-basic'
            label='Application No *'
            {...register("applicationNo")}
            error={!!errors.applicationNo}
            helperText={
              errors?.applicationNo ? errors.applicationNo.message : null
            }
          />
        </Grid>

        <Grid
          item
          xs={12}
          sm={12}
          md={12}
          lg={12}
          xl={12}
          sx={{ display: "flex", justifyContent: "center" }}
        >
          <strong>Hawker Info</strong>
        </Grid>
      </Grid>
      <div
        style={{
          backgroundColor: "#0084ff",
          color: "white",
          fontSize: 19,
          marginTop: 30,
          marginBottom: 30,
          padding: 8,
          paddingLeft: 30,
          marginLeft: "40px",
          marginRight: "65px",
          borderRadius: 100,
        }}
      >
        <strong>Hawker Info</strong>
      </div>
      <Grid
        container
        sx={{
          paddingLeft: "50px",
          align: "center",
          marginTop: 2,
          marginBottom: 5,
        }}
      >
        <Grid item lg={4}>
          <TextField
            sx={{ width: 400 }}
            id='standard-basic'
            label='Remark form PCMC'
            // value={dataInForm && dataInForm.religion}
            {...register("remarkFromPCMC")}
            error={!!errors.remarkFromPCMC}
            helperText={
              errors?.remarkFromPCMC ? errors.remarkFromPCMC.message : null
            }
          />
        </Grid>

        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Button variant='contained' color='success' endIcon={<SaveIcon />}>
            Action
          </Button>
        </Grid>
      </Grid>

      <Grid
        container
        sx={{
          marginLeft: 5,
          marginTop: 1,
          marginBottom: 5,
          align: "center",
        }}
      >
        <Grid item lg={6}>
          <FormControl sx={{ marginTop: 0 }} error={!!errors.scheduleDate}>
            <Controller
              control={control}
              name='scheduleDate'
              defaultValue={null}
              render={({ field }) => (
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <DatePicker
                    inputFormat='DD/MM/YYYY'
                    label={<span style={{ fontSize: 13 }}>Schedule Date</span>}
                    value={field.value}
                    onChange={(date) =>
                      field.onChange(moment(date).format("YYYY-MM-DD"))
                    }
                    selected={field.value}
                    center
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        size='small'
                        fullWidth
                        InputLabelProps={{
                          style: {
                            fontSize: 12,
                            marginTop: 3,
                          },
                        }}
                      />
                    )}
                  />
                </LocalizationProvider>
              )}
            />
            <FormHelperText>
              {errors?.scheduleDate ? errors.scheduleDate.message : null}
            </FormHelperText>
          </FormControl>
        </Grid>

        <Grid item lg={6}>
          <FormControl style={{ marginTop: 10 }} error={!!errors.scheduleTime}>
            <Controller
              control={control}
              name='scheduleTime'
              defaultValue={null}
              render={({ field }) => (
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <TimePicker
                    label={<span style={{ fontSize: 16 }}>Schedule Time</span>}
                    value={field.value}
                    onChange={(date) =>
                      field.onChange(moment(date).format("YYYY-MM-DD"))
                    }
                    selected={field.value}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        size='small'
                        fullWidth
                        InputLabelProps={{
                          style: {
                            fontSize: 12,
                            marginTop: 3,
                          },
                        }}
                      />
                    )}
                  />
                </LocalizationProvider>
              )}
            />
            <FormHelperText>
              {errors?.scheduleTime ? errors.scheduleTime.message : null}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item lg={6}>
          <FormControl sx={{ marginTop: 0 }} error={!!errors.rescheduleTime}>
            <Controller
              control={control}
              name='rescheduleTime'
              defaultValue={null}
              render={({ field }) => (
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <TimePicker
                    label={
                      <span style={{ fontSize: 13 }}>Reschedule Time</span>
                    }
                    value={value}
                    onChange={(newValue) => {
                      setValuee(newValue);
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        size='small'
                        fullWidth
                        InputLabelProps={{
                          style: {
                            fontSize: 12,
                            marginTop: 3,
                          },
                        }}
                      />
                    )}
                  />
                </LocalizationProvider>
              )}
            />
            <FormHelperText>
              {errors?.rescheduleTime ? errors.rescheduleTime.message : null}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item lg={6}>
          <FormControl sx={{ marginTop: 0 }} error={!!errors.rescheduleDate}>
            <Controller
              control={control}
              name='rescheduleDate'
              defaultValue={null}
              render={({ field }) => (
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <DatePicker
                    inputFormat='DD/MM/YYYY'
                    label={
                      <span style={{ fontSize: 15 }}>Reschedule Date</span>
                    }
                    value={field.value}
                    onChange={(date) =>
                      field.onChange(moment(date).format("YYYY-MM-DD"))
                    }
                    selected={field.value}
                    center
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        size='small'
                        fullWidth
                        InputLabelProps={{
                          style: {
                            fontSize: 12,
                            marginTop: 3,
                          },
                        }}
                      />
                    )}
                  />
                </LocalizationProvider>
              )}
            />
            <FormHelperText>
              {errors?.rescheduleDate ? errors.rescheduleDate.message : null}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item lg={6}>
          <TextField
            id='standard-basic'
            label='Schedule Token No'
            sx={{ width: 400 }}
            {...register("scheduleTokenNo")}
            error={!!errors.scheduleTokenNo}
            helperText={
              errors?.scheduleTokenNo ? errors.scheduleTokenNo.message : null
            }
          />
        </Grid>

        <Grid item lg={6}>
          <TextField
            sx={{ width: 400 }}
            id='standard-basic'
            label='Status'
            {...register("Status")}
            error={!!errors.Status}
            helperText={errors?.Status ? errors.Status.message : null}
          />
        </Grid>
      </Grid>

      <Grid
        container
        sx={{
          marginLeft: 5,
          marginTop: 1,
          marginBottom: 5,
          align: "center",
        }}
      >
        <Grid item lg={4}>
          <Button
            type='submit'
            variant='contained'
            color='success'
            endIcon={<SaveIcon />}
          >
            Submit
          </Button>
        </Grid>
        <Grid item lg={4}>
          <Button
            variant='contained'
            color='primary'
            endIcon={<ClearIcon />}
            onClick={() => cancellButton()}
          >
            Clear
          </Button>
        </Grid>
        <Grid item lg={4}>
          <Button
            variant='contained'
            color='error'
            endIcon={<ExitToAppIcon />}
            onClick={() => exitButton()}
          >
            Exit
          </Button>
        </Grid>
      </Grid>
    </>
  );
};

export default SiteVisit;
