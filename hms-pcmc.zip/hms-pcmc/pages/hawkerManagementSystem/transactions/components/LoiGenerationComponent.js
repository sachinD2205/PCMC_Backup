import {
  Button,
  FormControl,
  FormHelperText,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import { ThemeProvider } from "@mui/styles";
import React, { useEffect, useState } from "react";
import { Controller, useForm, useFormContext } from "react-hook-form";
import FormattedLabel from "../../../../containers/reuseableComponents/FormattedLabel";
import theme from "../../../../theme.js";
import urls from "../../../../URLS/urls";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useSelector } from "react-redux";
import moment from "moment";

import axios from "axios";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import { Stack } from "@mui/system";
// Loi Generation
const LoiGenerationComponent = () => {
  const {
    control,
    register,
    getValues,
    reset,
    formState: { errors },
  } = useFormContext();
  const language = useSelector((state) => state?.labels.language);

  useEffect(() => {
    console.log("title", getValues("title"));
    console.log("serviceName", getValues("serviceName"));
    console.log("firstName", getValues("firstName"));
  }, []);

  // title
  const [titles, setTitles] = useState([]);

  // getTitles
  const getTitles = () => {
    axios.get(`${urls.CfcURLMaster}/title/getAll`).then((r) => {
      setTitles(
        r.data.title.map((row) => ({
          id: row.id,
          title: row.title,
          titleMr: row.titleMr,
        })),
      );
    });
  };

  // select
  const getserviceNames = () => {
    axios
      .get(`${urls.CfcURLMaster}/service/getAll`)
      .then((r) => {
        if (r.status == 200) {
          setServiceNames(
            r.data.service.map((row) => ({
              id: row.id,
              serviceName: row.serviceName,
              serviceNameMr: row.serviceNameMr,
            })),
          );
        } else {
          message.error("Filed To Load !! Please Try Again !");
        }
      })
      .catch((err) => {
        console.log(err);
        toast.success("Error !", {
          position: toast.POSITION.TOP_RIGHT,
        });
      });
  };

  useEffect(() => {
    getserviceNames();
    getTitles;
  }, []);

  // ServiceName
  const [serviceNames, setServiceNames] = useState([]);

  return (
    <>
      <ThemeProvider theme={theme}>
        <ToastContainer />
        <div
          style={{
            backgroundColor: "#0084ff",
            color: "white",
            fontSize: 19,
            marginTop: 30,
            marginBottom: 30,
            padding: 8,
            paddingLeft: 30,
            marginLeft: "40px",
            marginRight: "65px",
            borderRadius: 100,
          }}
        >
          <strong>LOI Generation</strong>
        </div>
        <Grid
          container
          sx={{
            marginTop: 1,
            marginBottom: 5,
            paddingLeft: "50px",
            align: "center",
          }}
        >
          <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
            <FormControl error={!!errors.serviceName} sx={{ marginTop: 2 }}>
              <InputLabel id='demo-simple-select-standard-label'>
                {<FormattedLabel id='serviceName' />}
              </InputLabel>
              <Controller
                render={({ field }) => (
                  <Select
                    sx={{ minWidth: "230px" }}
                    // // dissabled={inputState}
                    autoFocus
                    value={field.value}
                    onChange={(value) => field.onChange(value)}
                    label='Service Name *'
                    id='demo-simple-select-standard'
                    labelId="id='demo-simple-select-standard-label'"
                  >
                    {serviceNames &&
                      serviceNames.map((serviceName, index) => (
                        <MenuItem key={index} value={serviceName.id}>
                          {language == "en"
                            ? serviceName?.serviceName
                            : serviceName?.serviceNameMr}
                        </MenuItem>
                      ))}
                  </Select>
                )}
                name='serviceName'
                control={control}
                defaultValue=''
              />
            </FormControl>
          </Grid>
          <Grid item xs={3} sm={6} md={6} lg={6} xl={6}>
            <TextField
              label='Application No.'
              {...register("applicationNumber")}
              error={!!errors.applicationNumber}
              helperText={
                errors?.applicationNumber
                  ? errors.applicationNumber.message
                  : null
              }
            />
          </Grid>
          <Grid item xs={3} sm={6} md={6} lg={6} xl={6}>
            <FormControl sx={{ marginTop: 0 }} error={!!errors.applicationDate}>
              <Controller
                name='applicationDate'
                control={control}
                defaultValue={null}
                render={({ field }) => (
                  <LocalizationProvider dateAdapter={AdapterMoment}>
                    <DatePicker
                      inputFormat='DD/MM/YYYY'
                      label={
                        <span style={{ fontSize: 16, marginTop: 2 }}>
                          Application Date
                        </span>
                      }
                      value={field.value}
                      onChange={(date) =>
                        field.onChange(moment(date).format("YYYY-MM-DD"))
                      }
                      selected={field.value}
                      center
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          size='small'
                          fullWidth
                          InputLabelProps={{
                            style: {
                              fontSize: 12,
                              marginTop: 3,
                            },
                          }}
                        />
                      )}
                    />
                  </LocalizationProvider>
                )}
              />
              <FormHelperText>
                {errors?.applicationDate
                  ? errors.applicationDate.message
                  : null}
              </FormHelperText>
            </FormControl>
          </Grid>
        </Grid>
        <div
          style={{
            backgroundColor: "#0084ff",
            color: "white",
            fontSize: 19,
            marginTop: 30,
            marginBottom: 30,
            padding: 8,
            paddingLeft: 30,
            marginLeft: "40px",
            marginRight: "40px",
            borderRadius: 100,
          }}
        >
          <strong>Holders Details</strong>
        </div>
        <Grid
          container
          sx={{
            marginTop: 1,
            marginBottom: 5,
            paddingLeft: "50px",
            align: "center",
          }}
        >
          <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
            <FormControl error={!!errors.title} sx={{ marginTop: 2 }}>
              <InputLabel id='demo-simple-select-standard-label'>
                {<FormattedLabel id='title' />}
              </InputLabel>
              <Controller
                render={({ field }) => (
                  <Select
                    sx={{ width: "230px" }}
                    // disabled={inputState}
                    autoFocus
                    value={field.value}
                    onChange={(value) => field.onChange(value)}
                    label={<FormattedLabel id='title' />}
                    id='demo-simple-select-standard'
                    labelId="id='demo-simple-select-standard-label'"
                  >
                    {titles &&
                      titles.map((title, index) => (
                        <MenuItem key={index} value={title.id}>
                          {language == "en" ? title?.title : title?.titleMr}
                        </MenuItem>
                      ))}
                  </Select>
                )}
                name='title'
                control={control}
                defaultValue=''
              />
              <FormHelperText>
                {errors?.title ? errors.title.message : null}
              </FormHelperText>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
            <TextField
              id='standard-basic'
              // disabled={inputState}
              label={<FormattedLabel id='firstName' />}
              {...register("firstName")}
              error={!!errors.firstName}
              helperText={errors?.firstName ? errors.firstName.message : null}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
            <TextField
              id='standard-basic'
              // disabled={inputState}
              label={<FormattedLabel id='middleName' />}
              {...register("middleName")}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
            <TextField
              id='standard-basic'
              // disabled={inputState}
              label={<FormattedLabel id='lastName' />}
              {...register("lastName")}
              error={!!errors.lastName}
              helperText={errors?.lastName ? errors.lastName.message : null}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
            <TextField
              id='standard-basic'
              // disabled={inputState}
              label={<FormattedLabel id='mobile' />}
              {...register("mobile")}
              error={!!errors.mobile}
              helperText={errors?.mobile ? errors.mobile.message : null}
            />
          </Grid>
          <br />
          <br />
          <Grid
            item
            xs={12}
            sm={12}
            md={12}
            lg={12}
            xl={12}
            style={{
              display: "flex",
              justifyContent: "center",
              alignItem: "center",
            }}
          >
            <Stack spacing={5} direction='row'>
              <Button sx={{ width: "230 px" }} varaint='standard'>
                Preview LOI
              </Button>
              <Button sx={{ width: "230 px" }} varaint='standard'>
                Generate LOI
              </Button>
            </Stack>
          </Grid>
        </Grid>
      </ThemeProvider>
    </>
  );
};

export default LoiGenerationComponent;
