import Image from "next/image";
import React, { useRef } from "react";
import styles from "./LoiGenerationReport.module.css";
import { useReactToPrint } from "react-to-print";
import { Button, Card } from "@mui/material";
const LoiGenerationReport = () => {
  const componentRef = useRef(null);

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: "new document",
  });
  return (
    <>
      <div>
        <ComponentToPrint ref={componentRef} />
      </div>
      <div className={styles.btn}>
        <Button type='primary' onClick={handlePrint}>
          print
        </Button>
        <Button type='primary'>Exit</Button>
      </div>
    </>
  );
};
class ComponentToPrint extends React.Component {
  render() {
    return (
      <>
        <div className={styles.mainn}>
          <div className={styles.main}>
            <div className={styles.smain}>
              <div className={styles.logo}>
                <img src='/logo.png' alt='' height='100vh' width='100vw' />
              </div>
              <div>
                <h1>Pimpri Chinchwad Municipal Corporation</h1>
                <h3> Mumbai-Pune Road,</h3>
                <h3>Pimpri - 411018,</h3>
                <h3> Maharashtra, INDIA</h3>
              </div>
            </div>
            <div>
              <h2 className={styles.heading}>Payment Receipt</h2>
            </div>

            <div>
              <b>Department Name : Town Planning</b>
            </div>

            <div>
              <Card>
                <div>
                  <h4>Receipt No. :</h4>
                  <h4>Receipt Date :</h4>
                  <h4>Name :</h4>
                  <h4>Contact No :</h4>
                </div>
              </Card>
              <Card>
                <div className={styles.info}>
                  <table className={styles.payTable}>
                    <tr>
                      <th className={styles.srNumber}>SR.</th>
                      <th>PART PLAN</th>
                      <th>RS.</th>
                    </tr>
                    <tr>
                      <td>1</td>
                      <td>Application Fees </td>
                      <td>20.00</td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Certificate/Document/Map Fees </td>
                      <td>150.00</td>
                    </tr>
                    <tr>
                      <td colspan={2}>Total Amount:</td>
                      <td>170.00</td>
                    </tr>
                    <tr>
                      <td colSpan={3}>
                        Amount in Words : One Hundred and Seventy Rupees Only/--
                      </td>
                    </tr>
                  </table>
                </div>
              </Card>
              <div className={styles.mode}>Mode of Payment :</div>
              <div className={styles.mode}>
                <h4>Please read the important note given below.</h4>
                <h4>This is a Computer generated receipt </h4>
              </div>
              <div className={styles.mode}>
                <b>Important Note:</b>
                <p>
                  Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                  <br></br> Nihil nisi, adipisci voluptatem fugiat minima nemo
                  quia alias, labore harum exercitationem ipsum.<br></br>
                  Accusantium inventore enim deleniti esse ad nemo unde
                  explicabo veniam. Voluptate, <br></br>tempora! Cum, tempora
                  dolore culpa atque facere quidem ducimus a rerum reiciendis
                  hic, voluptatum quibusdam modi, vo<br></br>luptas ipsam
                  veritatis delectus quisquam soluta porro distinctio
                  consequatur. <br></br>Inventore rerum repellendus, ducimus, ab
                  cum magnam architecto eum impedit facere <br></br>non ipsa quo
                  doloremque autem, unde provident maiores aspernatur!
                  Exercitationem <br></br>doloribus omnis, reiciendis sed beatae
                  quisquam. Soluta maiores, doloribus obcaecati <br></br>
                  nesciunt saepe maxime explicabo adipisci illo rerum accusamus
                  praesentium atque. Soluta, id.
                </p>
              </div>
              <div className={styles.enquiry}>
                <div>
                  <b>For Contact :- Mobile No:-9999999999</b>
                </div>
                <div>
                  <b>email:-enquiry@pcmcindia.gov.in</b>
                </div>
              </div>
              {/* <div className={styles.btn}>
                <Button type="primary">print</Button>
                <Button type="primary">Exit</Button>
              </div> */}
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default LoiGenerationReport;
