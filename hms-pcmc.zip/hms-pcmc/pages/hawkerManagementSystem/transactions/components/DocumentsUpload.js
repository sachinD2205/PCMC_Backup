import { Add, Delete, Label, LabelOutlined } from "@mui/icons-material";
import React, { useState, useEffect } from "react";
import { Controller, useFormContext, useFieldArray } from "react-hook-form";
import styles from "../components/documentUpload.module.css";
import UploadButton from "../../FileUpload/UploadButton.js";
import { Grid, IconButton, Input, TextField, Typography } from "@mui/material";
import { convertBase } from "../../FileUpload/convertToBase.js";
import VisibilityIcon from "@mui/icons-material/Visibility";
import axios from "axios";
import { useRouter } from "next/router";
import { makeStyles } from "@mui/styles";
import Box from "@mui/material/Box";
import { yupResolver } from "@hookform/resolvers/yup";
import schema from "../issuanceOfHawkerLicense/Schema";
import FormattedLabel from "../../../../containers/reuseableComponents/FormattedLabel";

// make style
const useStyles = makeStyles({
  blue: {
    color: "blue",
  },
});

const DocumentsUpload = () => {
  // UseForm Context
  const {
    control,
    register,
    reset,
    getValues,
    setValue,
    formState: { errors },
  } = useFormContext();
  // { resolver: yupResolver(schema) }

  // UseField Array
  const { fields } = useFieldArray({
    control, // control props comes from useForm (optional: if you are using FormContext)
    name: "documents", // unique name for your Field Array
  });

  const classes = useStyles();
  const router = useRouter();

  let appName = "HMS";
  let serviceName = "H-IssuanceofHawkerLicense";

  const [aadhaarCardPhoto, setAadhaarCardPhoto] = useState(null);
  const [panCardPhoto, setPanCardPhoto] = useState(null);
  const [rationCardPhoto, setRationCardPhoto] = useState(null);
  const [disablityCertificatePhoto, setDisablityCertificatePhoto] =
    useState(null);
  const [otherDocumentPhoto, setOtherDocumentPhoto] = useState(null);
  const [affidaviteOnRS100StampAttache, seteAffidaviteOnRS100StampAttache] =
    useState(null);

  const i = 0;

  // useEffect =
  //   (() => {
  //     console.log("file Name", aadhaarCardPhoto);
  //     console.log("filePath", setAadhaarCardPhoto);
  //     console.log("fileData", aadhaarCardPhotoData);
  //   },
  //   [aadhaarCardPhoto, aadhaarCardPhotoData, setAadhaarCardPhoto]);

  // console.log("file Name", aadhaarCardPhoto);
  // console.log("filePath", setAadhaarCardPhoto);
  // console.log("fileData", aadhaarCardPhotoData);

  useEffect(() => {
    // alert("dss", i);
    console.log("aadhaarCardPhoto", getValues("aadhaarCardPhoto"));
    console.log(
      "first1",
      setValue("aadhaarCardPhoto", getValues("aadhaarCardPhoto")),
    );
    setValue("aadhaarCardPhoto", aadhaarCardPhoto);
    // localStorage.setItem("aadhaarCardPhoto", aadhaarCardPhoto);
    setValue("panCardPhoto", panCardPhoto);
    setValue("rationCardPhoto", setRationCardPhoto);
    setValue("disablityCertificatePhoto", disablityCertificatePhoto);
    setValue("otherDocumentPhoto", otherDocumentPhoto);
    setValue("affidaviteOnRS100StampAttache", affidaviteOnRS100StampAttache);
  }, [
    aadhaarCardPhoto,
    panCardPhoto,
    rationCardPhoto,
    disablityCertificatePhoto,
    otherDocumentPhoto,
    affidaviteOnRS100StampAttache,
  ]);

  // On Next
  useEffect(() => {
    console.log(
      "first",
      setValue("aadhaarCardPhoto", getValues("aadhaarCardPhoto")),
    );
    setValue("panCardPhoto", getValues("panCardPhoto"));
    setValue("rationCardPhoto", getValues("setRationCardPhoto"));
    setValue(
      "disablityCertificatePhoto",
      getValues("disablityCertificatePhoto"),
    );
    setValue("otherDocumentPhoto", getValues("otherDocumentPhoto"));
    setValue(
      "affidaviteOnRS100StampAttache",
      getValues("affidaviteOnRS100StampAttache"),
    );
    console.log("getValuesAadhaar", getValues("aadhaarCardPhoto"));
    setAadhaarCardPhoto(getValues("aadhaarCardPhoto"));
  }, []);

  let attachedFileEdit = null;

  useEffect(() => {
    router?.query?.attachedFile;
  }, []);

  useEffect(() => {
    //getDepartments();
    if (router.query.pageMode === "Edit") {
      // setAttachedFile(router.query.attachedFile);
      console.log("Data to Edit->", router.query);
      reset(router.query);
      attachedFileEdit = router.query.attachedFile;
    }
  }, []);

  // useEffect(() => {
  //   if (getValues("aadhaarCardPhoto") != null) {
  //     console.log("refreshh", getValues("aadhaarCardPhoto"));
  //     setAadhaarCardPhoto(getValues("aadhaarCardPhoto"));
  //   }
  // }, []);

  // useEffect(() => {
  //   setValue("aadhaarCardPhoto", aadhaarCardPhoto);
  //   // console.log("refreshh", getValues("aadhaarCardPhoto"));
  // }, [aadhaarCardPhoto]);

  return (
    <>
      <div
        style={{
          backgroundColor: "#0084ff",
          color: "white",
          fontSize: 19,
          marginTop: 30,
          marginBottom: 30,
          padding: 8,
          paddingLeft: 30,
          marginLeft: "40px",
          marginRight: "65px",
          borderRadius: 100,
        }}
      >
        <strong>{<FormattedLabel id='documentUpload' />}</strong>
      </div>
      <Grid
        container
        sx={{
          marginTop: 5,
          marginBottom: 5,
          paddingLeft: "50px",
          align: "center",
        }}
      >
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Typography variant='subtitle2'>
            <strong>{<FormattedLabel id='adharCard' />}</strong>
          </Typography>
          <div className={styles.attachFile}>
            <UploadButton
              appName='HMS'
              serviceName='H-IssuanceofHawkerLicense'
              filePath={setAadhaarCardPhoto}
              fileName={aadhaarCardPhoto}
            />
          </div>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Typography variant='subtitle2'>
            <strong>{<FormattedLabel id='panCard' />}</strong>
          </Typography>
          <UploadButton
            appName='HMS'
            serviceName='H-IssuanceofHawkerLicense'
            filePath={setPanCardPhoto}
            fileName={panCardPhoto}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Typography variant='subtitle2'>
            <strong>{<FormattedLabel id='rationCard' />}</strong>
          </Typography>
          <UploadButton
            appName='HMS'
            serviceName='H-IssuanceofHawkerLicense'
            filePath={setRationCardPhoto}
            fileName={rationCardPhoto}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Typography variant='subtitle2'>
            <strong>{<FormattedLabel id='disablityCretificatePhoto' />}</strong>
          </Typography>
          <UploadButton
            appName='HMS'
            serviceName='H-IssuanceofHawkerLicense'
            filePath={setDisablityCertificatePhoto}
            fileName={disablityCertificatePhoto}
          />
        </Grid>

        <Grid item xs={12} sm={6} md={4} lg={3} xl={2} sx={{ marginTop: 4 }}>
          <Typography variant='subtitle2'>
            <strong>{<FormattedLabel id='otherDocumentPhoto' />}</strong>
          </Typography>
          <UploadButton
            appName='HMS'
            serviceName='H-IssuanceofHawkerLicense'
            filePath={setOtherDocumentPhoto}
            fileName={otherDocumentPhoto}
          />
        </Grid>
        <Grid item xs={6} sm={4} md={3} lg={2} xl={1} sx={{ marginTop: 4 }}>
          <Typography variant='subtitle2'>
            <strong>
              {<FormattedLabel id='affidaviteOnRS100StampAttachement' />}
            </strong>
          </Typography>
          <UploadButton
            appName='HMS'
            serviceName='H-IssuanceofHawkerLicense'
            filePath={seteAffidaviteOnRS100StampAttache}
            fileName={affidaviteOnRS100StampAttache}
          />
        </Grid>
      </Grid>
    </>
  );
};

export default DocumentsUpload;
