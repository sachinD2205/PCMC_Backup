import {
  Box,
  Dialog,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Grid,
  Modal,
  Paper,
  Typography,
} from "@mui/material";
import AdditionalDetails from "./AdditionalDetails";
import AddressOfHawker from "./AddressOfHawker";
import HawkerDetails from "./HawkerDetails";
import BasicApplicationDetails from "./BasicApplicationDetails";
import DocumentsUpload from "./DocumentsUpload";
import React, { useState } from "react";
import AadharAuthentication from "./AadharAuthentication";
import PropertyAndWaterTaxes from "./PropertyAndWaterTaxes";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { Button } from "@mui/material";
import { TramOutlined } from "@mui/icons-material";
import { Stack } from "@mui/system";

const PdfIssuanceOfHawkerLicense = () => {
  const [formPreviewDailog, setFormPreviewDailog] = useState(false);
  const formPreviewDailogOpen = () => setFormPreviewDailog(true);
  const formPreviewDailogClose = () => setFormPreviewDailog(false);

  return (
    <>
      <Grid
        container
        alignItems='center'
        justify='center'
        style={{ minWidth: "500px" }}
      >
        <Grid xs='auto'>
          <Button
            type='button'
            onClick={() => {
              formPreviewDailogOpen();
            }}
            color='primary'
            variant='contained'
            //onClick={handleOpen}
          >
            Preview Application Form
          </Button>
        </Grid>
        <br />
        <br />
      </Grid>

      <>
        <Dialog
          fullWidth
          maxWidth={"lg"}
          open={formPreviewDailog}
          onClose={() => formPreviewDailogClose()}
        >
          <DialogTitle>Preview</DialogTitle>
          <DialogContent>
            {/** <DialogContentText
              style={{
                // backgroundColor: "#0084ff",
                color: "black",
                fontSize: 19,
                marginTop: 30,
                marginBottom: 30,
                padding: 8,
                paddingLeft: 30,
                marginLeft: "40px",
                marginRight: "65px",
                borderRadius: 100,
              }}
            >
              <Typography variant='h5'>Issuance Of Hawker License</Typography>
            </DialogContentText> */}

            <BasicApplicationDetails />
            <HawkerDetails />
            <AddressOfHawker />
            <AadharAuthentication />
            <PropertyAndWaterTaxes />
            <DocumentsUpload />
          </DialogContent>
        </Dialog>
      </>
    </>
  );
};

export default PdfIssuanceOfHawkerLicense;
