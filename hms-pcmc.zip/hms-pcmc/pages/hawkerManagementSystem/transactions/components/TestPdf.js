import { jsPDF } from "jspdf";
import {
  FormControl,
  FormHelperText,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Button,
  Typography,
} from "@mui/material";
import Box from "@mui/material/Box";
import html2canvas from "html2canvas";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import axios from "axios";
import moment, { now } from "moment";
import React, { useEffect, useState } from "react";
import { Controller, useFormContext, useForm } from "react-hook-form";
import urls from "../../../../URLS/urls";
import styles from "../components/view.module.css";
import FormattedLabel from "../../../../containers/reuseableComponents/FormattedLabel";
// import schema from "../issuanceOfHawkerLicense/Schema";
// crAreaNames

// http://localhost:4000/hawkerManagementSystem/transactions/components/BasicApplicationDetails
const TestPdf = () => {
  const {
    control,
    register,
    reset,
    formState: { errors },
  } = useForm();

  // crAreaNames
  const [areaNames, setAreaName] = useState([]);

  // getAreaName
  const getAreaName = () => {
    axios.get(`${urls.CFCUrlMaster}/area/getAll`).then((r) => {
      setAreaName(
        r.data.map((row) => ({
          id: row.id,
          areaName: row.areaName,
        })),
      );
    });
  };

  // ServiceName
  const [serviceNames, setServiceNames] = useState([]);

  // getserviceNames
  const getserviceNames = () => {
    axios.get(`${urls.CFCUrlMaster}/service/getAll`).then((r) => {
      setServiceNames(
        r.data.map((row) => ({
          id: row.id,
          serviceName: row.service,
        })),
      );
    });
  };

  // ServiceName
  const [hawkingZoneNames, setHawkingZoneName] = useState([]);

  // getserviceNames
  const getHawkingZoneName = () => {
    axios.get(`${urls.BaseURL}/hawingZone/getHawkigZoneData`).then((r) => {
      setHawkingZoneName(
        r.data.map((row) => ({
          id: row.id,
          hawkingZoneName: row.hawkingZoneName,
        })),
      );
    });
  };

  // useEffect
  useEffect(() => {
    getserviceNames();
    getHawkingZoneName();
    getAreaName();
  }, []);

  // Pdf Main

  // Function For Pdf Generate

  const createPDF = async () => {
    const pdf = new jsPDF("portrait", "pt", "a4");

    const data = await html2canvas(document.querySelector("#testPdf"));

    const img = data.toDataURL("image/png");
    const imgProperties = pdf.getImageProperties(img);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProperties.height * pdfWidth) / imgProperties.width;
    pdf.addImage(img, "PNG", 0, 0, pdfWidth, pdfHeight);
    pdf.save("First PDF");
  };

  // View
  return (
    <>
      <div>
        <div
          style={{
            backgroundColor: "#0084ff",
            color: "white",
            fontSize: 19,
            marginTop: 30,
            marginBottom: 30,
            padding: 8,
            paddingLeft: 30,
            marginLeft: "40px",
            marginRight: "65px",
            borderRadius: 100,
          }}
        >
          {/* <Typography variant='h6' sx={{ marginTop: 4 }}>
          <strong> Basic Application Details</strong>
        </Typography> */}
          <strong>
            <FormattedLabel id='basicApplicationDetails' />
          </strong>
        </div>
        <Grid
          id='testPdf'
          container
          sx={{ marginLeft: 5, marginTop: 1, marginBottom: 5, align: "center" }}
        >
          <Grid item xs={12} sm={6} md={4}>
            <FormControl error={!!errors.applicationDate} sx={{ marginTop: 2 }}>
              <InputLabel id='demo-simple-select-standard-label'>
                <FormattedLabel id='serviceName' />
              </InputLabel>
              <Controller
                render={({ field }) => (
                  <Select
                    autoFocus
                    value={field.value}
                    onChange={(value) => field.onChange(value)}
                    label='Service Name *'
                    id='demo-simple-select-standard'
                    labelId="id='demo-simple-select-standard-label'"
                  >
                    {serviceNames &&
                      serviceNames.map((serviceName, index) => (
                        <MenuItem key={index} value={serviceName.id}>
                          {serviceName.serviceName}
                        </MenuItem>
                      ))}
                  </Select>
                )}
                name='serviceName'
                control={control}
                defaultValue=''
              />
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <TextField
              id='standard-basic'
              label=<FormattedLabel id='applicationNumber' />
              disabled
              defaultValue='23848494848'
              {...register("applicationNumber")}
              error={!!errors.applicationNumber}
              helperText={
                errors?.applicationNumber
                  ? errors.applicationNumber.message
                  : null
              }
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl
              error={!!errors.applicationDate}
              sx={{ marginTop: 0 }}
              // sx={{ border: "solid 1px yellow" }}
            >
              <Controller
                control={control}
                name='applicationDate'
                defaultValue={Date.now()}
                render={({ field }) => (
                  <LocalizationProvider dateAdapter={AdapterMoment}>
                    <DatePicker
                      disabled
                      inputFormat='DD/MM/YYYY'
                      label={
                        <span style={{ fontSize: 16 }}>
                          <FormattedLabel id='applicationDate' />
                        </span>
                      }
                      value={field.value}
                      onChange={(date) =>
                        field.onChange(moment(date).format("YYYY-MM-DD"))
                      }
                      selected={field.value}
                      center
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          size='small'
                          fullWidth
                          InputLabelProps={{
                            style: {
                              fontSize: 12,
                              marginTop: 3,
                            },
                          }}
                        />
                      )}
                    />
                  </LocalizationProvider>
                )}
              />
              <FormHelperText>
                {errors?.applicationDate
                  ? errors.applicationDate.message
                  : null}
              </FormHelperText>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <TextField
              label=<FormattedLabel id='citySurveyNo' />
              //
              {...register("citySurveyNo")}
              error={!!errors.citySurveyNo}
              helperText={
                errors?.citySurveyNo ? errors.citySurveyNo.message : null
              }
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl
              variant='standard'
              error={!!errors.hawkingZoneName}
              sx={{ marginTop: 2 }}
            >
              <InputLabel id='demo-simple-select-standard-label'>
                <FormattedLabel id='hawkingZoneName' />{" "}
              </InputLabel>
              <Controller
                render={({ field }) => (
                  <Select
                    value={field.value}
                    onChange={(value) => field.onChange(value)}
                    label='hawkingZoneName *'
                  >
                    {hawkingZoneNames &&
                      hawkingZoneNames.map((hawkingZoneName, index) => (
                        <MenuItem key={index} value={hawkingZoneName.id}>
                          {hawkingZoneName.hawkingZoneName}
                        </MenuItem>
                      ))}
                  </Select>
                )}
                name='hawkingZoneName'
                control={control}
                defaultValue=''
              />
              <FormHelperText>
                {errors?.hawkingZoneName
                  ? errors.hawkingZoneName.message
                  : null}
              </FormHelperText>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl sx={{ marginTop: 2 }} error={!!errors.areaName}>
              <InputLabel id='demo-simple-select-standard-label'>
                <FormattedLabel id='areaName' />
              </InputLabel>
              <Controller
                render={({ field }) => (
                  <Select
                    value={field.value}
                    onChange={(value) => field.onChange(value)}
                    label=<FormattedLabel id='areaName' />
                  >
                    {areaNames &&
                      areaNames.map((areaName, index) => (
                        <MenuItem key={index} value={areaName.id}>
                          {areaName.areaName}
                        </MenuItem>
                      ))}
                  </Select>
                )}
                name='areaName'
                control={control}
                defaultValue=''
              />
              <FormHelperText>
                {errors?.areaName ? errors.areaName.message : null}
              </FormHelperText>
            </FormControl>
          </Grid>
        </Grid>

        <Button type='primary' onClick={createPDF}>
          Generate PDF
        </Button>
      </div>
    </>
  );
};

export default TestPdf;
