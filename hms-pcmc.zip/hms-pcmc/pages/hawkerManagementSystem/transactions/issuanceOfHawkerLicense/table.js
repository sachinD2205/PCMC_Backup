import React from "react";

const Table = () => {
  return (
    <>
      <h1> Hi</h1>
    </>
  );
};

export default Table;
