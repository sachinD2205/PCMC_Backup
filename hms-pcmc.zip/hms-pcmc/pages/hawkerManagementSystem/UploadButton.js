import { Add, Delete } from "@mui/icons-material";
import { useEffect } from "react";
import {
  Button,
  Dialog,
  DialogContent,
  DialogTitle,
  IconButton,
} from "@mui/material";
import React, { useState } from "react";
import style from "../FileUpload/upload.module.css";
import axios from "axios";

const UploadButton = (props) => {
  const [filePath, setFilePath] = useState(null);

  // let file;

  useEffect(() => {
    console.log("props.filePath <->", props);
    if (props?.fileName) {
      setFilePath(props?.fileName);
      // setConverted64(props?.fileNameD);
    }
  }, [props?.fileName]);

  const [converted64, setConverted64] = useState("");

  // Base 64
  const getBase64 = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);

      reader.onerror = (error) => reject(error);
    });

  // async function toConvert(file) {
  //   console.log("Response: ", file);
  //   // console.log("Jau dya na bhau saheb: ", base64File);
  //   // return base64File;
  //   // props.fileName(base64File);
  //   // setFilePath("Karan");
  //   return await toBase64(file);
  // }

  const handleFile = async (e) => {
    let formData = new FormData();
    formData.append("file", e.target.files[0]);
    formData.append("appName", props.appName);
    formData.append("serviceName", props.serviceName);
    axios
      .post(`http://localhost:8090/cfc/api/file/upload`, formData)
      .then((r) => {
        console.log(`Post File Path `, r.data.filePath);
        setFilePath(r.data.filePath);
        props.filePath(r.data.filePath);
        // let bas64 = getBase64(e.target.files[0]);
        // props.fileData(bas64)
        // setConverted64(bas64);
      });
  };

  function showFileName(fileName) {
    let fileNamee = [];
    fileNamee = fileName.split("__");
    return fileNamee[1];
  }

  // Delete
  const discard = async (e) => {
    swal({
      title: "Delete?",
      text: "Are you sure you want to delete the file ? ",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        axios
          .delete(
            `http://localhost:8090/cfc/api/file/discard?filePath=${filePath}`,
          )
          .then((res) => {
            if (res.status == 200) {
              setFilePath(null),
                props.filePath(null),
                swal("File Deleted Successfully!", { icon: "success" });
            } else {
              swal("Something went wrong..!!!");
            }
          });
      } else {
        swal("File is Safe");
      }
    });
  };

  // let url = null;

  // const [url, seturl] = useState("");
  const [open, setOpen] = useState(false);
  const [log, setLog] = useState();
  // const [handleClose, setHandleClose] = useState(false);
  const [blob1, setBlob1] = useState();
  const handleOpen = async (props) => {
    const filePath1 = props.filePath;
    console.log("filePath1", filePath1);
    axios
      .get(`http://localhost:8090/cfc/api/file/previewNew?filePath=${filePath}`)
      .then((r) => {
        console.log("r", r.data.fileName);
        var blob = new Blob([new Uint8Array(r.data.fileName)], {
          type: "jpeg/pdf/video/mp4",
        });
        setBlob1(blob);
        // const test = getBase64(blob);
        // console.log("log", log1);
        handlePreview(blob);
        // file = r.data;
        // console.log("file", file);
      });

    // seturl(await toBase64(file));
    // setOpen(true);
  };

  const handlePreview = async (bolb1) => {
    let preview = await getBase64(bolb1);

    setLog(preview);
    setOpen(true);
  };
  useEffect(() => {
    console.log("preview", log);
  }, [log]);

  // handleClose
  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div className={style.align}>
      <label className={style.uploadButton}>
        {!filePath && (
          <>
            <Add
              color='secondary'
              sx={{
                width: 30,
                height: 30,
                border: "1.4px dashed #9c27b0",
                marginRight: 1.5,
              }}
            />
            <input
              type='file'
              onChange={(e) => {
                handleFile(e);
                // toConvert(e.target.files[0]);
              }}
              hidden
            />
          </>
        )}
        {filePath ? (
          <>
            <Dialog
              fullWidth
              maxWidth={"md"}
              open={open}
              onClose={() => handleClose()}
            >
              <DialogTitle>Preview</DialogTitle>
              <DialogContent>
                <iframe
                  src={"data:application/pdf;base64,log"}
                  width='100%'
                  height='450px'
                />
              </DialogContent>
            </Dialog>
            <Button
              onClick={(filePath) => {
                handleOpen(filePath);
              }}
              type='button'
            >
              {showFileName(filePath)}
            </Button>
          </>
        ) : (
          <span className={style.fileName}>Add File</span>
        )}
      </label>
      {filePath && (
        <IconButton
          onClick={(e) => {
            discard(e);
          }}
        >
          <Delete color='error' />
        </IconButton>
      )}
    </div>
  );
};
export default UploadButton;
