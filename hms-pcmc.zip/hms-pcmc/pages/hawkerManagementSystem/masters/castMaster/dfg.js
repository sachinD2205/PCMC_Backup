<FormControl style={{ marginTop: 10 }} error={!!errors.toDate}>
  <Controller
    control={control}
    name='toDate'
    defaultValue={null}
    render={({ field }) => (
      <LocalizationProvider dateAdapter={AdapterMoment}>
        <DatePicker
          inputFormat='DD/MM/YYYY'
          label={<span style={{ fontSize: 16 }}>To Date</span>}
          value={field.value}
          onChange={(date) => field.onChange(moment(date).format("YYYY-MM-DD"))}
          selected={field.value}
          center
          renderInput={(params) => (
            <TextField
              {...params}
              size='small'
              fullWidth
              InputLabelProps={{
                style: {
                  fontSize: 12,
                  marginTop: 3,
                },
              }}
            />
          )}
        />
      </LocalizationProvider>
    )}
  />
  <FormHelperText>
    {errors?.toDate ? errors.toDate.message : null}
  </FormHelperText>
</FormControl>;
