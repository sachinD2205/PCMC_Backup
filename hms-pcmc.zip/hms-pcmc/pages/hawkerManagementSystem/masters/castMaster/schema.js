import * as yup from "yup";

// schema - validation
let schema = yup.object().shape({
  castMasterPrefix: yup.string().required("Cast Master Prefix is Required !!!"),
  fromDate: yup.string().nullable().required("From Date is Required !!!"),
  religion: yup.string().required("Religion is Required !!!"),
  cast: yup.string().required("Cast Category is Required !!!"),
});

export default schema;
