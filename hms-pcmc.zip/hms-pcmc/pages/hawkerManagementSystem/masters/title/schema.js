import * as yup from "yup";

// schema - validation
let schema = yup.object().shape({
  titleID: yup
    .number("Please Enter Number")
    .required("Title ID is Required !!!"),
  fromDate: yup.date().nullable().required("From Date is Required !!!"),
  title: yup.string().required("Title is Required !!!"),
});

export default schema;

yup
  .date("Expiration Date")
  .nullable()
  .min(
    yup.ref("enteredDate"),
    ({ min }) => `Expiration Date needs to be after Entered Date`,
  );
