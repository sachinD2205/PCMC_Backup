import * as yup from "yup";

// schema - validation
let schema = yup.object().shape({
  // applicantTypePrefix: yup
  //   .string()
  //   .required("Applicant Type Prefix is Required !!!"),
  // remark: yup.string().required("remark is Required !!!"),
  // applicantType: yup.string().required("Applicant Type  is Required !!!"),
  // applicantSubType: yup
  //   .string()
  //   .required("Applicant Sub Type  is Required !!!"),
});

export default schema;
