import * as yup from "yup";

// schema - validation
let schema = yup.object().shape({
    bankPrefix: yup
    .string()
    .required("Bank Prefix is Required !!!"),
  fromDate: yup.string().nullable().required("From Date is Required !!!"),
  bankName: yup.string().required("Bank Name is Required !!!"),
  branchName: yup.string().required("Branch Name is Required !!!"),
  bankAddress:yup.string().required("Bank Address is Required"),
  ifscCode:yup.string().required("IFSC Code is Required"),
  micrCode:yup.string().required("MICR Code is Required"),
});

export default schema;
