// // File Upload

// // UploadButton.js

// import { Add, Delete } from "@mui/icons-material";
// import { useEffect } from "react";
// import { IconButton } from "@mui/material";
// import { React,useState } from "react";
// import style from "../FileUpload/upload.module.css";
// import axios from 'axios';

// const UploadButton = (props) => {

//   const [filePath, setFilePath] = useState(null);

//   useEffect(() => {
//     console.log("props.filePath <->", props);
//     if(props?.fileName) {
//       setFilePath(props.fileName)
//     }
//   },[props?.fileName])

//   const handleFile = async (e) => {
//     let formData = new FormData();
//     formData.append("file", e.target.files[0]);
//     formData.append("appName", props.appName);
//     formData.append("serviceName", props.serviceName);
//     axios.post(`http://localhost:8090/cfc/api/file/upload`, formData).then((r) => {
//       setFilePath(r.data.filePath);
//       props.filePath(r.data.filePath);
//     });
//   };

//   function showFileName(fileName) {
//     let fileNamee=[];
//     fileNamee = fileName.split("__");
//     return fileNamee[1];
//   }

//   const discard = async (e) => {
//     swal({
//       title: "Delete?",
//       text: "Are you sure you want to delete the file ? ",
//       icon: "warning",
//       buttons: true,
//       dangerMode: true,
//     }).then((willDelete) => {
//       if (willDelete) {
//        axios
//         .delete(`http://localhost:8090/cfc/api/file/discard?filePath=${filePath}`)
//         .then((res) => {
//           if (res.status == 200) {
//             setFilePath(null),
//             props.filePath(null),
//             swal("File Deleted Successfully!", {icon: "success",});
//           } else {
//             swal("Something went wrong..!!!");
//           }
//         });
//       } else {
//             swal("File is Safe");
//       }
//     });
//   };

//   return (
//     <div className={style.align}>
//       <label className={style.uploadButton}>
//         {!filePath && (
//           <>
//             <Add
//               color="secondary"
//               sx={{
//                 width: 30,
//                 height: 30,
//                 border: "1.4px dashed #9c27b0",
//                 marginRight: 1.5,
//               }}
//             />
//             <input type="file" onChange={(e) => {handleFile(e)}} hidden />
//           </>
//           )}
//         {filePath ?
//         (
//             <a href={`http://localhost:8090/cfc/api/file/preview?filePath=${filePath}`} target='__blank'>
//               {showFileName(filePath)}</a>
//         )
//         :
//         (
//             <span className={style.fileName}>Add File</span>
//         )
//         }
//       </label>
//       {filePath && (
//         <IconButton onClick={(e) => {discard(e) /* setFilePath(null),props.filePath(null),discardFile() */}}>
//           <Delete color="error" />
//         </IconButton>
//       )}
//     </div>
//   );
// };
// export default UploadButton;

// ///=================================================================
// // ======================   upload.module.css

// .uploadButton:hover {
//   cursor: pointer;
// }

// .uploadButton {
//   display: flex;
//   flex-direction: row;
//   align-items: center;
//   width: max-content;
//   padding: 5px 5px;
// }

// .fileName {
//   color: #9c27b0;
//   font-size: 12;
//   font-weight: bold;
// }

// .align {
//   display: flex;
//   align-items: center;
// }

// //// ======================================================

// //
// import { useRouter } from "next/router";
// import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
// import { yupResolver } from "@hookform/resolvers/yup";
// import styles from "./view.module.css";
// import {
//   Card,
//   Button,
//   FormControl,
//   FormHelperText,
//   Grid,
//   InputLabel,
//   MenuItem,
//   Select,
//   TextField,
//   Paper,
//   Typography,
// } from "@mui/material";
// import BasicLayout from "../../../../containers/Layout/BasicLayout";
// import { Controller, FormProvider, useForm } from "react-hook-form";
// import schema from "./schema";
// import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
// import ClearIcon from "@mui/icons-material/Clear";
// import ExitToAppIcon from "@mui/icons-material/ExitToApp";
// import SaveIcon from "@mui/icons-material/Save";
// import { useEffect, useState } from "react";
// import axios from "axios";
// import sweetAlert from "sweetalert";
// import UploadButton from "../../FileUpload/UploadButton";

// const view = () => {
//   const {
//     register,
//     control,
//     handleSubmit,
//     methods,
//     setValue,
//     reset,
//     formState: { errors },
//   } = useForm({
//     criteriaMode: "all",
//     resolver: yupResolver(schema),
//     mode: "onChange",
//   });
//   const router = useRouter();
//   const [departments, setDepartments] = useState([]);
//   const [attachedFile, setAttachedFile] = useState(null);
//   // const [attachedFileEdit, setAttachedFileEdit] = useState(null);
//   let attachedFileEdit = null;

//   useEffect(() => {
//     setAttachedFile(router?.query?.attachedFile);
//   }, []);

//   useEffect(() => {
//     getDepartments();
//     if (router.query.pageMode === "Edit") {
//       // setAttachedFile(router.query.attachedFile);
//       console.log("Data to Edit->", router.query);
//       reset(router.query);
//       attachedFileEdit = router.query.attachedFile;
//     }
//   }, []);

//   useEffect(() => {
//     console.log("attachedFile", attachedFile);
//     setValue("attachedFile", attachedFile);
//   }, [attachedFile]);

//   const getDepartments = () => {
//     axios
//       .get(`http://localhost:8090/cfc/api/master/department/getAll`)
//       .then((res) => {
//         setDepartments(
//           res.data.map((r, i) => ({
//             id: r.id,
//             department: r.department,
//           }))
//         );
//       });
//   };

//   const onSubmitForm = (Data) => {
//     axios
//       .post(`http://localhost:8098/lc/api/notice/saveTrnNotice`, Data)
//       .then((res) => {
//         if (res.status == 201) {
//           sweetAlert("Saved!", "Record Saved successfully !", "success");
//           router.push(`/LegalCase/transaction/newNotice/`);
//         }
//       });
//   };

//   return (
//     <>
//       <BasicLayout>
//         {/* materialUI */}
//         <Card>
//           <Grid container mt={2} ml={5} mb={5} border px={5} height={10}>
//             <Grid item xs={5}></Grid>
//             <Grid item xs={5.7}>
//               <h2>Notice</h2>
//             </Grid>
//           </Grid>
//         </Card>

//         <Paper
//           sx={{
//             marginLeft: 5,
//             marginRight: 5,
//             marginTop: 5,
//             marginBottom: 5,
//             padding: 1,
//           }}
//         >
//           <div>
//             <FormProvider {...methods}>
//               <form onSubmit={handleSubmit(onSubmitForm)}>
//                 <div className={styles.small}>
//                   {/* First Row */}

//                   {/* 2nd Row */}
//                   <div className={styles.row}>
//                     <div className={styles.attachFile}>
//                       <Typography>Attached file</Typography>
//                       <UploadButton
//                         appName="LCMS"
//                         serviceName="L-Notice"
//                         filePath={setAttachedFile}
//                         fileName={attachedFile}
//                       />
//                     </div>
//                   </div>

//                   {/* Button Row */}
//                   <div className={styles.btn}>
//                     <Button
//                       sx={{ marginRight: 8 }}
//                       type="submit"
//                       variant="outlined"
//                       // color="success"
//                       color="primary"
//                       endIcon={<SaveIcon />}
//                     >
//                       Save
//                       {/* {btnSaveText} */}
//                     </Button>{" "}
//                     <Button
//                       sx={{ marginRight: 8 }}
//                       variant="outlined"
//                       color="primary"
//                       endIcon={<ClearIcon />}
//                       // onClick={() => cancellButton()}
//                     >
//                       Clear
//                     </Button>
//                     <Button
//                       variant="outlined"
//                       color="primary"
//                       endIcon={<ExitToAppIcon />}
//                       // onClick={() => exitButton()}
//                       onClick={() => {
//                         router.push(`/LegalCase/transaction/newNotice/`);
//                       }}
//                     >
//                       Exit
//                     </Button>
//                   </div>

//                   {/* <Grid container style={{ marginTop: 20 }}>
//                     <Grid item xs={4}></Grid>
//                     <Grid item xs={1}>
//                       <Button variant="outlined" type="submit">
//                         Save
//                       </Button>
//                     </Grid>

//                     <Grid item xs={0.5}></Grid>

//                     <Grid item xs={1}>
//                       <Button variant="outlined">Reset</Button>
//                     </Grid>
//                     <Grid item xs={0.5}></Grid>

//                     <Grid item xs={1}>
//                       <Button
//                         variant="outlined"
//                         onClick={() => {
//                           router.push(
//                             `/LegalCase/transaction/notices/NoticeSendToDepartment/`
//                           );
//                         }}
//                       >
//                         Cancel
//                       </Button>
//                     </Grid>
//                   </Grid> */}
//                 </div>
//               </form>
//             </FormProvider>
//           </div>
//         </Paper>
//       </BasicLayout>
//     </>
//   );
// };

// export default view;

// 					// ==================

// 					import { Row, Col, Form } from "antd";
// import Stack from "@mui/material/Stack";
// import { Collapse, Typography } from "@mui/material";
// import { useRouter } from "next/router";
// import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
// import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
// import { yupResolver } from "@hookform/resolvers/yup";
// import styles from "./view.module.css";
// import {
//   Card,
//   Button,
//   Checkbox,
//   FormControl,
//   FormControlLabel,
//   FormHelperText,
//   FormLabel,
//   Grid,
//   InputLabel,
//   MenuItem,
//   Radio,
//   RadioGroup,
//   Select,
//   TextField,
//   Paper,
// } from "@mui/material";
// import BasicLayout from "../../../../containers/Layout/BasicLayout";
// import { Controller, FormProvider, useForm } from "react-hook-form";
// import schema from "./schema";
// import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
// import AddIcon from "@mui/icons-material/Add";
// import ClearIcon from "@mui/icons-material/Clear";
// import DeleteIcon from "@mui/icons-material/Delete";
// import EditIcon from "@mui/icons-material/Edit";
// import ExitToAppIcon from "@mui/icons-material/ExitToApp";
// import SaveIcon from "@mui/icons-material/Save";
// import { useEffect, useState } from "react";
// import axios from "axios";
// import moment from "moment";
// import sweetAlert from "sweetalert";
// import UploadButton from "../../FileUpload/UploadButton";

// const view = () => {
//   let attachedFile = null;
//   const {
//     register,
//     control,
//     handleSubmit,
//     methods,
//     setValue,
//     reset,
//     formState: { errors },
//   } = useForm({
//     criteriaMode: "all",
//     resolver: yupResolver(schema),
//     mode: "onChange",
//   });
//   const router = useRouter();
//   const [noticeDate, setNoticeDate] = useState(null);
//   const [requisitionDate, setRequisitionDate] = useState(null);
//   // const [caseMainTypes, setCaseMainTypes] = useState([]);
//   const [departments, setDepartments] = useState([]);
//   const [id, setId] = useState();
//   let pageType = false;

//   if (router.query.pageMode === "Edit" || router.query.pageMode === "View") {
//     pageType = true;
//   }

//   useEffect(() => {
//     getDepartments();

//     //
//     if (router.query.pageMode === "Edit") {
//       pageType = true;
//       reset({
//         noticeRecivedFromAdvocatePerson:
//           router.query.noticeRecivedFromAdvocatePerson,
//         noticeDate: router.query.noticeDate,
//         department: router.query.department,
//         noticeRecivedDate: router.query.noticeRecivedDate,
//         requisitionDate: router.query.requisitionDate,
//         // documentOriName: router.query.documentOriName,
//       });
//     }
//   }, []);

//   const getDepartments = () => {
//     axios
//       .get(`http://localhost:8090/cfc/api/master/department/getAll`)
//       .then((res) => {
//         setDepartments(
//           res.data.map((r, i) => ({
//             id: r.id,
//             department: r.department,
//           }))
//         );
//       });
//   };

//   const onSubmitForm = (Data) => {
//     // let [Data.attachFile, ...Data]=Data;

//     // let { attachFile, ...Data };
//     // let attachFileJson = Data.attachFile;
//     // let formData = new FormData();
//     // formData.append("data", JSON.stringify(Data));
//     // formData.delete("attachFile");
//     // formData.append("attachFile", Data.attachFile);

//     console.log("A..", Data);
//     console.log("File..", attachedFile);
//     const finalBodyForApi = {
//       ...Data,
//       attachedFile,
//     };
//     if (router.query.pageMode === "Add") {
//       axios
//         .post(
//           `http://localhost:8098/lc/api/notice/saveTrnNotice`,
//           finalBodyForApi
//         )
//         .then((res) => {
//           if (res.status == 201) {
//             sweetAlert("Saved!", "Record Saved successfully !", "success");
//             router.push(`/LegalCase/transaction/newNotice/`);
//           }
//         });
//     } else if (router.query.pageMode === "Edit") {
//       axios
//         .post(
//           `http://localhost:8098/lc/api/notice/saveTrnNotice`,
//           finalBodyForApi
//           // validityOfMarriageBoardRegistration
//         )
//         .then((res) => {
//           if (res.status == 201) {
//             sweetAlert("Updated!", "Record Updated successfully !", "success");
//             router.push(`/LegalCase/transaction/newNotice/`);
//           }
//         });
//     }

//     // axios
//     //   .post(
//     //     `http://localhost:8098/lc/api/notice/saveTrnNotice`,
//     //     finalBodyForApi
//     //   )
//     //   .then((res) => {
//     //     if (res.status == 201) {
//     //       sweetAlert("Saved!", "Record Saved successfully !", "success");
//     //       router.push(`/LegalCase/transaction/newNotice/`);
//     //     }
//     //   });
//   };

//   // convertBase 64

//   const convertBase64 = (file) => {
//     return new Promise((resolve, reject) => {
//       const fileReader = new FileReader();
//       fileReader.readAsDataURL(file);
//       fileReader.onload = () => {
//         resolve(fileReader.result);
//       };
//       fileReader.onerror = (error) => {
//         reject(error);
//       };
//     });
//   };

//   // handleFile for Document
//   const [doc1type, setdoc1type] = useState();
//   const [document1, setDocument1] = useState();

//   const handleFile1 = async (e) => {
//     let formData = new FormData();
//     formData.append("file", e.target.files[0]);
//     axios
//       .post(`http://localhost:8098/lc/api/notice/upload`, formData)
//       .then((r) => {
//         console.log("Responsess", r);
//         if (r.status === 200) {
//           // attachedFile...(Dio Field)
//           attachedFile = r.data.filePath;
//           console.log("Response", r.data);
//           console.log("Res", attachedFile);
//         } else {
//           sweetAlert("Error");
//         }
//       });
//     setValue("attachedFile", attachedFile);
//     // if (labelName == advocate3) {
//     //   setValue("attachedFile", attachedFile);
//     // } else if (labelName == advocate1) {
//     //   setValue("attachedFile", attachedFile);
//     // } else if (labelName == advocate2) {
//     //   setValue("attachedFile", attachedFile);
//     // }
//   };

//   return (
//     <>
//       <BasicLayout>
//         {/* materialUI */}
//         <Card>
//           <Grid container mt={2} ml={5} mb={5} border px={5} height={10}>
//             <Grid item xs={5}></Grid>
//             <Grid item xs={5.7}>
//               <h2>Notice</h2>
//             </Grid>
//           </Grid>
//         </Card>

//         <Paper
//           sx={{
//             marginLeft: 5,
//             marginRight: 5,
//             marginTop: 5,
//             marginBottom: 5,
//             padding: 1,
//           }}
//         >
//           <div>
//             <FormProvider {...methods}>
//               <form onSubmit={handleSubmit(onSubmitForm)}>
//                 <div className={styles.small}>
//                   {/* First Row */}
//                   <div className={styles.row}>
//                     <div>
//                       <FormControl
//                         style={{ marginTop: 10 }}
//                         error={!!errors.fromDate}
//                       >
//                         <Controller
//                           control={control}
//                           name="noticeDate"
//                           defaultValue={null}
//                           render={({ field }) => (
//                             <LocalizationProvider dateAdapter={AdapterMoment}>
//                               <DatePicker
//                                 inputFormat="DD/MM/YYYY"
//                                 label={
//                                   <span style={{ fontSize: 16 }}>
//                                     Notice Date
//                                   </span>
//                                 }
//                                 value={field.value}
//                                 onChange={(date) => field.onChange(date)}
//                                 selected={field.value}
//                                 center
//                                 renderInput={(params) => (
//                                   <TextField
//                                     {...params}
//                                     size="small"
//                                     // fullWidth
//                                     sx={{ width: 230 }}
//                                     InputLabelProps={{
//                                       style: {
//                                         fontSize: 12,
//                                         marginTop: 3,
//                                       },
//                                     }}
//                                   />
//                                 )}
//                               />
//                             </LocalizationProvider>
//                           )}
//                         />
//                         <FormHelperText>
//                           {errors?.noticeDate
//                             ? errors.noticeDate.message
//                             : null}
//                         </FormHelperText>
//                       </FormControl>
//                     </div>

//                     <div>
//                       <FormControl
//                         style={{ marginTop: 10 }}
//                         error={!!errors.noticeRecivedDate}
//                       >
//                         <Controller
//                           control={control}
//                           name="noticeRecivedDate"
//                           defaultValue={null}
//                           render={({ field }) => (
//                             <LocalizationProvider dateAdapter={AdapterMoment}>
//                               <DatePicker
//                                 inputFormat="DD/MM/YYYY"
//                                 label={
//                                   <span style={{ fontSize: 16 }}>
//                                     Notice Received date
//                                   </span>
//                                 }
//                                 value={field.value}
//                                 onChange={(date) => field.onChange(date)}
//                                 selected={field.value}
//                                 center
//                                 renderInput={(params) => (
//                                   <TextField
//                                     {...params}
//                                     size="small"
//                                     // fullWidth
//                                     sx={{ width: 230 }}
//                                     InputLabelProps={{
//                                       style: {
//                                         fontSize: 12,
//                                         marginTop: 3,
//                                       },

// ////////////////////

// // import { Add, Delete } from "@mui/icons-material";
// // import { IconButton } from "@mui/material";
// // import React, { useState } from "react";
// // import axios from "axios";
// // import style from "../FileUpload/upload.module.css";

// // const UploadButton = ({ Change }) => {
// //   const [file, setFile] = useState(null);

// //   function openBase64NewTab(base64Pdf) {
// //     var blob = base64toBlob(base64Pdf);
// //     if (window.navigator && window.navigator.msSaveOrOpenBlob) {
// //       window.navigator.msSaveOrOpenBlob(blob, "pdfBase64.pdf");
// //     } else {
// //       const blobUrl = URL.createObjectURL(blob);
// //       window.open(blobUrl);
// //     }
// //   }

// //   function base64toBlob(base64Data) {
// //     const sliceSize = 1024;
// //     const byteCharacters = atob(base64Data);
// //     const bytesLength = byteCharacters.length;
// //     const slicesCount = Math.ceil(bytesLength / sliceSize);
// //     const byteArrays = new Array(slicesCount);
// //     for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
// //       const begin = sliceIndex * sliceSize;
// //       const end = Math.min(begin + sliceSize, bytesLength);
// //       const bytes = new Array(end - begin);
// //       for (let offset = begin, i = 0; offset < end; ++i, ++offset) {
// //         bytes[i] = byteCharacters[offset].charCodeAt(0);
// //       }
// //       byteArrays[sliceIndex] = new Uint8Array(bytes);
// //     }
// //     return new Blob(byteArrays, { type: "application/pdf" });
// //   }

// //   const toBase64 = (file) =>
// //     new Promise((resolve, reject) => {
// //       const reader = new FileReader();
// //       reader.readAsDataURL(file);
// //       reader.onload = () => resolve(reader.result);
// //       reader.onerror = (error) => reject(error);
// //     });

// //   const discardFile = () => {
// //     axios.post(
// //       `http://localhost:8090/cfc/api/file/upload?appName=${appName}&serviceName=${serviceName}`,
// //     );
// //   };

// //   async function Main() {
// //     let filee = await toBase64(file);
// //     if (file.type != "application/pdf") {
// //       var image = new Image();
// //       image.src = filee;
// //       var w = window.open("");
// //       w.document.write(image.outerHTML);
// //     } else {
// //       let pdfWindow = window.open("");
// //       // openBase64NewTab(filee);
// //       // window.open("data:application/octet-stream;charset=utf-16le;base64,"+filee);
// //       pdfWindow.document.write(
// //         "<iframe width='100%' height='100%' src={" + filee + "'></iframe>",
// //       );
// //     }
// //   }

// //   return (
// //     <div className={style.align}>
// //       <label className={style.uploadButton}>
// //         {!file && (
// //           <>
// //             <Add
// //               color='secondary'
// //               sx={{
// //                 width: 30,
// //                 height: 30,
// //                 border: "1.4px dashed #9c27b0",
// //                 marginRight: 1.5,
// //               }}
// //             />

// //             <input
// //               type='file'
// //               onChange={(e) => {
// //                 setFile(e.target.files[0]);
// //                 Change(e);
// //               }}
// //               hidden
// //             />
// //           </>
// //         )}
// //         {file ? (
// //           <span
// //             onClick={() => {
// //               Main();
// //             }}
// //             className={style.fileName}
// //           >
// //             {file.name}
// //           </span>
// //         ) : (
// //           <span className={style.fileName}>Add File</span>
// //         )}
// //       </label>
// //       {file && (
// //         <IconButton
// //           onClick={() => {
// //             setFile(null);
// //             discardFile();
// //           }}
// //         >
// //           <Delete color='error' />
// //         </IconButton>
// //       )}
// //     </div>
// //   );
// // };
// // export default UploadButton;
