import React from "react";

// Check File Size
export function checkFileSize(fileSize) {
  if (fileSize >= 2097152) {
    message.error("File Should not be more than 2 MB !");
    return false;
  } else {
    return true;
  }
}

// Check File Extension
export function checkFileExtension(filename) {
  const extension = filename.split(".").pop();
  // console.log(extension);
  if (["jpeg", "jpg", "png"].indexOf(extension) < 0) {
    message.error("Please Select Valid File Format JPEG,JPG,PNG,PDF!");
    return false;
  } else {
    return true;
  }
}

export default File;

// <>
//   <Dialog fullWidth maxWidth={"xl"} open={open} onClose={() => handleClose()}>
//     <DialogTitle>Preview</DialogTitle>
//     <iframe
//       src={`cfc/api/file/preview?filePath=${filePath}`}
//       width={1000}
//       height={500}
//       allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture full'
//     ></iframe>
//   </Dialog>
//   <Button onClick={handleOpen} type='button'>
//     {showFileName(filePath)}
//   </Button>
// </>;
