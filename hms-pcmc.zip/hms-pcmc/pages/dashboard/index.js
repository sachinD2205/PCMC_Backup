import React from "react";
import BasicLayout from "../../containers/Layout/BasicLayout";
import InnerCards from "../../containers/Layout/Inner-Cards/InnerCards";

const DashboardHome = () => {
  return (
    <div>
      {/** <BasicLayout titleProp={'PCMC Dashboard'}> */}
      <InnerCards pageKey={"dashboard"} />
      {/** </BasicLayout> */}
    </div>
  );
};

export default DashboardHome;
