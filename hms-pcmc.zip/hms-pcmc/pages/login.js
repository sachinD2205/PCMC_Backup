import React from 'react'
import { useRef, useState, useEffect } from 'react'
import { Form, Input, Button, Row, Col, Card, message } from 'antd'
import styles from '../styles/[login].module.css'
import { useRouter } from 'next/router'
import { useDispatch, useSelector } from 'react-redux'
import { login, setMenu } from '../features/userSlice'
import menu from '../containers/Layout/menu'
import backEndApiMenu from '../containers/Layout/backEndApiMenu'
import userDetails from '../containers/Layout/userDetails'
import labels from '../containers/reuseableComponents/newLabels'
import { TextField } from '@mui/material'
import { mountLabels } from '../features/labelSlice'
//import axios from 'axios'

const Login = () => {
  const userRef = useRef()
  const errRef = useRef()
  const [user, setUser] = useState('')
  const [pwd, setPwd] = useState('')
  const [err, setErr] = useState('')
  const [success, setSuccess] = useState(false)
  const [LoginForm] = Form.useForm()
  const router = useRouter()
  const [activeTabKey2, setActiveTabKey2] = useState('citizen')

  const dispatch = useDispatch()
  // @ts-ignore
  const checkLoginState = useSelector((state) => state.user.isLoggedIn)
  useEffect(() => {
    // redirect to home if already logged in
    if (checkLoginState) {
      router.push('/')
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const onFinish = (values) => {
    const body = LoginForm.getFieldsValue()
    setSuccess(true)
    // axios.post('http://localhost:5000/pcmc/loginApi', body).then((r) => {
    //   if (r.status == 200) {
    //     console.log('res', r.data.menuCodes)
    //     dispatch(login(r.data.userDetails))
    //     dispatch(setMenu(r.data.menuCodes))
    //     router.push('/')
    //   } else {
    //     message.error('Login Failed ! Please Try Again !')
    //   }
    // })

    if (user === 'Admin' && pwd === '12345') {
      dispatch(login(userDetails))
      dispatch(setMenu(backEndApiMenu))
      dispatch(mountLabels(labels))

      router.push('/dashboard')
    } else {
      message.error('Login Failed ! Please Try Again !')
    }

    //const returnUrl = router.query.returnUrl || '/'
    //router.push(`${returnUrl}`)
  }
  // const onTab2Change = (key) => {
  //   setActiveTabKey2(key)
  // }

  // const onFinishFailed = (errorInfo) => {
  //   console.log('Failed:', errorInfo)
  // }
  // const tabListNoTitle = [
  //   {
  //     key: 'citizen',
  //     tab: 'Citizen Portal Login',
  //   },
  //   {
  //     key: 'emp',
  //     tab: 'Employee Portal Login',
  //   },
  // ]

  // const contentListNoTitle = {
  //   citizen: (
  //     <>
  //       <Row>
  //         <Col span={4}></Col>
  //         <Col span={12}>
  //           <Form
  //             name='basic'
  //             labelCol={{
  //               span: 8,
  //             }}
  //             wrapperCol={{
  //               span: 16,
  //             }}
  //             initialValues={{
  //               remember: true,
  //             }}
  //             onFinish={onFinish}
  //             onFinishFailed={onFinishFailed}
  //             autoComplete='off'
  //           >
  //             <Form.Item
  //               label='Username'
  //               name='username'
  //               rules={[
  //                 {
  //                   required: true,
  //                   message: 'Please input your username!',
  //                 },
  //               ]}
  //             >
  //               <Input />
  //             </Form.Item>

  //             <Form.Item
  //               label='Password'
  //               name='password'
  //               rules={[
  //                 {
  //                   required: true,
  //                   message: 'Please input your password!',
  //                 },
  //               ]}
  //             >
  //               <Input.Password />
  //             </Form.Item>

  //             <Form.Item
  //               wrapperCol={{
  //                 offset: 8,
  //                 span: 16,
  //               }}
  //             >
  //               <Button type='primary' htmlType='submit'>
  //                 Login
  //               </Button>
  //             </Form.Item>
  //           </Form>
  //         </Col>
  //       </Row>
  //     </>
  //   ),
  //   emp: (
  //     <>
  //       <Row>
  //         <Col span={4}></Col>
  //         <Col span={12}>
  //           <Form
  //             name='basic'
  //             labelCol={{
  //               span: 8,
  //             }}
  //             wrapperCol={{
  //               span: 16,
  //             }}
  //             initialValues={{
  //               remember: true,
  //             }}
  //             onFinish={onFinish}
  //             onFinishFailed={onFinishFailed}
  //             autoComplete='off'
  //           >
  //             <Form.Item
  //               label='Username'
  //               name='username'
  //               rules={[
  //                 {
  //                   required: true,
  //                   message: 'Please input your username!',
  //                 },
  //               ]}
  //             >
  //               <Input />
  //             </Form.Item>

  //             <Form.Item
  //               label='Password'
  //               name='password'
  //               rules={[
  //                 {
  //                   required: true,
  //                   message: 'Please input your password!',
  //                 },
  //               ]}
  //             >
  //               <Input.Password />
  //             </Form.Item>

  //             <Form.Item
  //               wrapperCol={{
  //                 offset: 8,
  //                 span: 16,
  //               }}
  //             >
  //               <Button type='primary' htmlType='submit'>
  //                 Login
  //               </Button>
  //             </Form.Item>
  //           </Form>
  //         </Col>
  //       </Row>
  //     </>
  //   ),
  // }

  return (
    <div className={styles.main}>
      <div className={styles.bgImg}>
        {/* class containing 2 parts of background image  */}
        <div>
          {/* Left part of background image  */}
          <img className={styles.bgLeft} src={'/sign.jpg'} alt="test" />
        </div>
        <div>
          {/* Right part of background image  */}
          <img className={styles.bgRight} src={'/sign.jpg'} alt="bg-img" />
        </div>
      </div>

      <div className={styles.part}>
        <div className={styles.left}>
          <div className={styles.header}>
            <div className={styles.leftHeader}>
              <img
                className={styles.logoLeft}
                src={'/logo.png'}
                alt="pcmcLogo"
              />
              <h5>Pimpri-Chinchwad Municipal Corporation</h5>
            </div>
            <img
              className={styles.logoRight}
              src={'/logo.png'}
              alt="pcmcLogo"
            />
          </div>
          <div className={styles.welcome}>
            <h1>WELCOME TO</h1>
            <h2>Pimpri Chinchwad Citizen Service Portal</h2>
          </div>
          {/* +-+-+-+-+-+-+-+-+- ex-Card -+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            <Card
              className={styles.antCard}
              tabList={tabListNoTitle}
              activeTabKey={activeTabKey2}
              onTabChange={(key) => {
                onTab2Change(key)
              }}
            >
              {contentListNoTitle[activeTabKey2]}
            </Card>
          +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
        */}

          <div className={styles.tabs}>
            <div className={styles.leftTab}>
              <h3>Citizen</h3>
            </div>
            <div className={styles.rightTab}>
              <h3>Department</h3>
            </div>
          </div>

          <div className={styles.form}>
            <div className={styles.fields}>
              <label>Username</label>
              <Input
                placeholder="Username"
                onChange={(e) => setUser(e.target.value)}
              />

              <label>Password</label>
              <Input.Password
                placeholder="Password"
                onChange={(e) => setPwd(e.target.value)}
              />
              <Button
                type="primary"
                // danger
                onClick={onFinish}
                className={styles.button}
                style={{ backgroundColor: '#0c6dc9', borderColor: '#0c6dc9' }}

              >
                Login
              </Button>
            </div>
          </div>

          <div className={styles.formbottom}>
            <h4>Or</h4>
            <h4>Continue without login</h4>
            <h4>Don't have an account? Sign up here</h4>
          </div>
        </div>

        <div className={styles.right}>
          <div className={styles.footer}>
            <h4>PCMC ©2022 Powered by Atos Nascent</h4>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Login
