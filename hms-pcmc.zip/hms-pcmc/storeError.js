const isClient = typeof window !== "undefined";

let mainReducer;
if (isClient) {
  const { persistReducer } = require("redux-persist");
  const storage = require("redux-persist/lib/storage").default;

  const rootPersistConfig = {
    key: "root",
    storage: storage,
    blacklist: ["countries"],
  };

  const countriesPersistConfig = {
    key: "countries",
    storage: storage,
    whitelist: ["countriesList"],
  };

  /* COMBINE REDUCERS */
  const combinedReducers = combineReducers({
    countries: persistReducer(countriesPersistConfig, countries),
  });

  mainReducer = persistReducer(rootPersistConfig, combinedReducers);
} else {
  mainReducer = combineReducers({
    countries,
  });
}
