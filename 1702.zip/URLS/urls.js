// for local
const urls = {
  AuthURL: 'http://localhost:8090/cfc/auth',
  CFCURL: 'http://localhost:8090/cfc/api',
  MR: 'http://localhost:8091/mr/api',
  FbsURL: 'http://localhost:8092/fbs/api',
  TPURL: 'http://localhost:8093/tp/api',
  SSLM: 'http://localhost:8094/sslm/api',
  HMSURL: 'http://localhost:8095/hw/api',
  SPURL: 'http://localhost:8096/sp/api',
  PTAXURL: 'http://localhost:8097/ptax/api',
  LCMSURL: 'http://localhost:8098/lc/api',
  MSURL: 'http://localhost:8099/ms/api',
  GM: 'http://localhost:9003/gm/api',
  //change
  API_file: 'http://localhost:8090/cfc/api/file', //replace
  BaseURL: 'http://localhost:8090/cfc/api/master', //replace this to CFC url (CFCURL)
  CfcURLMaster: 'http://localhost:8090/cfc/api/master', //replace this to CFC url (CFCURL)
  CfcURLTransaction: 'http://localhost:8090/cfc/api/transaction', //replace this to CFC url (CFCURL)
  APPURL: 'http://localhost:4000',

  // SLB:"http://192.168.5.148:9011/slb/api",
  SLB:"http://localhost:9011/slb/api",

  
}

// For UAT
// const urls = {
//   AuthURL: 'http://122.15.104.76:8090/cfc/auth',
//   CFCURL: 'http://122.15.104.76:8090/cfc/api',
//   MR: 'http://122.15.104.76:8091/mr/api',
//   FbsURL: 'http://122.15.104.76:8092/fbs/api',
//   TPURL: 'http://122.15.104.76:8093/tp/api',
//   SSLM: 'http://122.15.104.76:8094/sslm/api',
//   HMSURL: 'http://122.15.104.76:8095/hw/api',
//   SPURL: 'http://122.15.104.76:8096/sp/api',
//   PTAXURL: 'http://122.15.104.76:8097/ptax/api',
//   LCMSURL: 'http://122.15.104.76:8098/lc/api',
//   MSURL: 'http://122.15.104.76:8099/ms/api',
//   //change
//   API_file: 'http://122.15.104.76:8090/cfc/api/file', //replace
//   BaseURL: 'http://122.15.104.76:8090/cfc/api/master', //replace this to CFC url (CFCURL)
//   CfcURLMaster: 'http://122.15.104.76:8090/cfc/api/master', //replace this to CFC url (CFCURL)
//   CfcURLTransaction: 'http://122.15.104.76:8090/cfc/api/transaction', //replace this to CFC url (CFCURL)
//   APPURL: 'http://122.15.104.76:3000',
// }

export default urls
