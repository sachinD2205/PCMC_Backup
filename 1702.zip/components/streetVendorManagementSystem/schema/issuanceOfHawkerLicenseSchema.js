import * as yup from "yup";

export let BasicApplicationDetailsSchema = yup.object().shape({
  // serviceName: yup.string().required("Service Name selection is required !!!"),
  citySurveyNo: yup.string().required("Business Type Name is required !!!"),
  hawkingZoneName: yup
    .string()
    .required("Hawking Zone Name selection is required !!!"),
  areaName: yup.string().required("Area Name is required !!!"),
});

export let HawkerDetailsSchema = yup.object().shape({
  title: yup.string().required("Title Selection is required !!!"),
  firstName: yup.string().required("First Name is required !!!"),
  middleName: yup.string().required("Middle Name is required !!!"),
  lastName: yup.string().required("Last Name is required !!!"),
  gender: yup.string().required("Gender selection is required !!!"),
  religion: yup.string().required("Religion selection is required !!!"),
  cast: yup.string().required("Caste selection is required !!!"),
  subCast: yup.string().required("SubCaste selection is required !!!"),
  dateOfBirth: yup
    .date()
    .typeError("Birth Date is required !!!")
    .required("Birth Date is required !!!"),
  age: yup.string().required("Age is required"),
  mobile: yup
    .string()
    .matches(/^[0-9]+$/, "Must be only digits")
    .typeError("Must be only digits")
    .min(10, "Mobile Number must be at least 10 number")
    .max(10, "Mobile Number not valid on above 10 number")
    .required("Mobile Number is Required !!!"),
  emailAddress: yup
    .string()
    .email("Please Enter Valid Email !!!")
    .required("Email is Required !!"),
  rationCardNo: yup
    .number()
    .typeError("Only digits are allowed")
    .required("Ration Card Number is required !!!"),
  applicantType: yup
    .string()
    .required("Applicant Type selection is Required !!!"),
  typeOfDisability: yup
    .string()
    .required("Type Of Disablity selection is Required !!!"),
});

export let AddressOfHawkerSchema = yup.object().shape({
  // crLattitude: yup.string().required("Business Type Name is Required !!!"),
});
