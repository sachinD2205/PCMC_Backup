export const filterDocketAddToLocalStorage = (key, doc) => {
  localStorage.setItem(key, JSON.stringify(doc))
}

export const filterDocketRemoveToLocalStorage = (key) => {
  localStorage.removeItem(key)
}
export const getFilterDocketFromLocalStorage = (key) => {
  const result = localStorage.getItem(key)
  const document = result ? JSON.parse(result) : null
  return document
}
