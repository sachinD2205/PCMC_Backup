import {
  Checkbox,
  FormControl,
  FormControlLabel,
  FormHelperText,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import { Controller, useFormContext } from "react-hook-form";
import styles from "../../../styles/fireBrigadeSystem/view.module.css";

import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormLabel from "@mui/material/FormLabel";
import UploadButton from "../UploadButton";
// import FormattedLabel from "../../../../../containers/reuseableComponents/FormattedLabel";
import FormattedLabel from "../../../containers/reuseableComponents/FormattedLabel";

// constructionLoss: r.constructionLoss,
//             insuranced: r.insuranced,
//             fireType: r.fireType,
//             fireTypeMr: r.fireTypeMr,
//             fireReason: r.fireReason,
//             fireReasonMr: r.fireReasonMr,

// http://localhost:4000/hawkerManagementSystem/transactions/components/AddressOfFire
const AddressOfFire = () => {
  // file uploading
  let documentsUpload = null;
  let appName = "MR";
  let serviceName = "M-MBR";
  let applicationFrom = "Web";

  //handel file
  // const handleFile1 = async (e, labelName) => {
  //   let formData = new FormData();
  //   formData.append("file", e.target.files[0]);
  //   axios
  //     .post(
  //       `${urls.CFCURL}/file/upload?appName=${appName}&serviceName=${serviceName}`,
  //       formData
  //     )
  //     .then((r) => {
  //       if (r.status == 200) {
  //         console.log(r.data);
  //         console.log(r.data.filePath);

  //         if (labelName === "documentsUpload") {
  //           console.log("File path sapadala Ka---?>", r.data.filePath);
  //           setValue("documentsUpload", r.data.filePath);
  //         } else if (labelName === "boardHeadPersonPhoto") {
  //           setValue("boardHeadPersonPhoto", r.data.filePath);
  //         } else if (labelName == "boardHeadPersonThumbImpression") {
  //           setValue("boardHeadPersonThumbImpression", r.data.filePath);
  //         }
  //       } else {
  //         sweetAlert("Error");
  //       }
  //     });
  // };

  const {
    control,
    register,
    reset,
    formState: { errors },
  } = useFormContext();

  // fireReason
  // fireReasonMr
  // fireType
  // fireTypeMr
  // fireLossInformationDetails
  // fireLossInformationDetailsMr
  // constructionLoss
  // fireLossInformationDetailsMr

  return (
    <>
      {/* <div className={styles.details}>
        <div className={styles.h1Tag}>
          <h3
            style={{
              color: "white",
              marginTop: "5px",
              paddingLeft: 10,
            }}
          >
            {<FormattedLabel id="fireDetails" />}
          </h3>
        </div>
      </div> */}
      <Grid
        container
        // spacing={{ xs: 2, md: 3 }}
        columns={{ xs: 4, sm: 8, md: 12 }}
        className={styles.feildres}
      >
        <Grid item xs={11} className={styles.feildres}>
          <TextField
            fullWidth
            id="standard-basic"
            label={<FormattedLabel id="firedThingsDuringAccuse" />}
            variant="standard"
            multiline
            maxRows={2}
            {...register("firedThingsDuringAccuse")}
            error={!!errors.firedThingsDuringAccuse}
            helperText={
              errors?.firedThingsDuringAccuse
                ? errors.firedThingsDuringAccuse.message
                : null
            }
          />
        </Grid>
        <Grid item xs={11} className={styles.feildres}>
          <TextField
            fullWidth
            id="standard-basic"
            label={<FormattedLabel id="firedThingsDuringAccuseMr" />}
            variant="standard"
            multiline
            maxRows={2}
            {...register("firedThingsDuringAccuseMr")}
            error={!!errors.firedThingsDuringAccuseMr}
            helperText={
              errors?.firedThingsDuringAccuseMr
                ? errors.firedThingsDuringAccuseMr.message
                : null
            }
          />
        </Grid>
        <Grid item xs={11} className={styles.feildres}>
          <TextField
            fullWidth
            multiline
            maxRows={2}
            id="standard-basic"
            label={<FormattedLabel id="insurancePolicyDetails" />}
            variant="standard"
            {...register("insurancePolicyDetails")}
            error={!!errors.insurancePolicyDetails}
            helperText={
              errors?.insurancePolicyDetails
                ? errors.insurancePolicyDetails.message
                : null
            }
          />
        </Grid>
        <Grid item xs={11} className={styles.feildres}>
          <TextField
            fullWidth
            multiline
            maxRows={2}
            id="standard-basic"
            label={<FormattedLabel id="insurancePolicyDetailsMr" />}
            variant="standard"
            {...register("insurancePolicyDetailsMr")}
            error={!!errors.insurancePolicyDetailsMr}
            helperText={
              errors?.insurancePolicyDetailsMr
                ? errors.insurancePolicyDetailsMr.message
                : null
            }
          />
        </Grid>
        <Grid item xs={11} className={styles.feildres}>
          <TextField
            fullWidth
            multiline
            maxRows={2}
            id="standard-basic"
            label={<FormattedLabel id="fireEquipments" />}
            variant="standard"
            {...register("fireEquipments")}
            error={!!errors.fireEquipments}
            helperText={
              errors?.fireEquipments ? errors.fireEquipments.message : null
            }
          />
        </Grid>
        <Grid item xs={11} className={styles.feildres}>
          <TextField
            fullWidth
            multiline
            maxRows={2}
            id="standard-basic"
            label={<FormattedLabel id="fireEquipmentsMr" />}
            variant="standard"
            {...register("fireEquipmentsMr")}
            error={!!errors.fireEquipmentsMr}
            helperText={
              errors?.fireEquipmentsMr ? errors.fireEquipmentsMr.message : null
            }
          />
        </Grid>
      </Grid>

      <Grid
        container
        // spacing={{ xs: 2, md: 3 }}
        columns={{ xs: 4, sm: 8, md: 12 }}
        className={styles.feildres}
      >
        {/* <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="fireReason" />}
            // label="Fire Reason (Tentetive)"
            variant="standard"
            {...register("fireReason")}
            error={!!errors.fireReason}
            helperText={errors?.fireReason ? errors.fireReason.message : null}
          />
        </Grid> */}
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="fireType" />}
            variant="standard"
            {...register("fireType")}
            error={!!errors.fireType}
            helperText={errors?.fireType ? errors.fireType.message : null}
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="fireLossInformationDetails" />}
            variant="standard"
            {...register("fireLossInformationDetails")}
            error={!!errors.fireLossInformationDetails}
            helperText={
              errors?.fireLossInformationDetails
                ? errors.fireLossInformationDetails.message
                : null
            }
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="constructionLoss" />}
            variant="standard"
            {...register("constructionLoss")}
            error={!!errors.constructionLoss}
            helperText={
              errors?.constructionLoss ? errors.constructionLoss.message : null
            }
          />
        </Grid>

        {/* <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="fireReasonMr" />}
            // label="Fire Reason (Tentetive)"
            variant="standard"
            {...register("fireReasonMr")}
            error={!!errors.fireReasonMr}
            helperText={
              errors?.fireReasonMr ? errors.fireReasonMr.message : null
            }
          /> 
        </Grid>*/}
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="fireTypeMr" />}
            variant="standard"
            {...register("fireTypeMr")}
            error={!!errors.fireTypeMr}
            helperText={errors?.fireTypeMr ? errors.fireTypeMr.message : null}
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="fireLossInformationDetailsMr" />}
            variant="standard"
            {...register("fireLossInformationDetailsMr")}
            error={!!errors.fireLossInformationDetailsMr}
            helperText={
              errors?.fireLossInformationDetailsMr
                ? errors.fireLossInformationDetailsMr.message
                : null
            }
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}></Grid>
      </Grid>

      <Grid
        container
        // spacing={{ xs: 2, md: 3 }}
        columns={{ xs: 4, sm: 8, md: 12 }}
        className={styles.feildres}
      >
        <Grid item xs={4} sx={{ marginTop: "2%" }} className={styles.feildres}>
          <FormControl>
            <FormLabel id="demo-radio-buttons-group-label">
              {<FormattedLabel id="insuranced" />}
            </FormLabel>
            <RadioGroup
              aria-labelledby="demo-radio-buttons-group-label"
              defaultValue="yes"
              name="radio-buttons-group"
            >
              <FormControlLabel value="yes" control={<Radio />} label="Yes" />
              <FormControlLabel value="no" control={<Radio />} label="No" />
            </RadioGroup>
          </FormControl>
        </Grid>
        <Grid item xs={4} className={styles.feildres}></Grid>
        <Grid item xs={4} className={styles.feildres}></Grid>
      </Grid>

      <div className={styles.details}>
        <div className={styles.h1Tag}>
          <h3
            style={{
              color: "white",
              marginTop: "5px",
              paddingLeft: 10,
            }}
          >
            {<FormattedLabel id="documentsUploadEmr" />}
          </h3>
        </div>
      </div>
      <Grid container columns={{ xs: 6, md: 8 }} className={styles.feildres}>
        <Grid item xs={4} className={styles.feildres}>
          <div>
            <br />
            <Typography
              sx={{
                color: "red",
                fontSize: "15px",
                fontFamily: "inherit",
              }}
            >
              Photo (upload.jpeg, .png, .doc, .pdf file)
            </Typography>
            <br />
            <UploadButton
              Change={(e) => {
                handleFile1(e, "documentsUpload");
              }}
              {...register("documentsUpload")}
            />
          </div>
        </Grid>
        <Grid item xs={6} md={4}></Grid>
      </Grid>
      {/* <FormControl component="fieldset">
  <FormLabel component="legend">Gender</FormLabel>
  <RadioGroup aria-label="gender" name="gender1" value={value} onChange={handleChange}>
    <FormControlLabel value="female" control={<Radio />} label="Female" />
    <FormControlLabel value="male" control={<Radio />} label="Male" />
    <FormControlLabel value="other" control={<Radio />} label="Other" />
    <FormControlLabel value="disabled" disabled control={<Radio />} label="(Disabled option)" />
  </RadioGroup>
</FormControl> */}
    </>
  );
};

export default AddressOfFire;
