import {
  FormControl,
  FormControlLabel,
  FormHelperText,
  FormLabel,
  InputLabel,
  handleSubmit,
  MenuItem,
  Radio,
  RadioGroup,
  Select,
  TextField,
  Grid,
} from "@mui/material";
import { DateTimePicker, TimePicker } from "@mui/x-date-pickers";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import axios from "axios";
import moment from "moment";
import React, { useEffect, useState } from "react";
import { Controller, useFormContext } from "react-hook-form";
import FormattedLabel from "../../../containers/reuseableComponents/FormattedLabel";
import styles from "../../../styles/fireBrigadeSystem/view.module.css";

import urls from "../../../URLS/urls";
import { useRouter } from "next/router";

// import style from "../../../../../styles/fireBrigadeSystem/view.module.css";

import { useSelector } from "react-redux";

// http://localhost:4000/hawkerManagementSystem/transactions/components/FireDetails
const FireDetails = () => {
  const {
    control,
    register,
    reset,
    formState: { errors },
  } = useFormContext();

  const router = useRouter();

  const [reason, setReason] = useState();
  const [showVardiOther, setShowVardiOther] = useState([]);
  const [showFireOther, setShowFireOther] = useState([]);
  const [SlipHandedOverTo, setSlipHandedOverTo] = useState([]);
  const [vardiTypes, setVardiTypes] = useState();
  const [userLst, setUserLst] = useState([]);

  const language = useSelector((state) => state?.labels.language);

  useEffect(() => {
    getPinCode();
    getVardiTypes();
    getFireReason();
  }, []);

  // get reason of fire
  const getFireReason = () => {
    axios.get(`${urls.FbsURL}/mstReasonOfFire/get`).then((res) => {
      setReason(res?.data);
    });
  };

  // get Vardi Types
  const getVardiTypes = () => {
    axios
      .get(`${urls.FbsURL}/vardiTypeMaster/getVardiTypeMasterData`)
      .then((res) => {
        setVardiTypes(res?.data);
      });
  };

  // fetch pin code from cfc
  const getPinCode = () => {
    axios
      .get(`${urls.CFCURL}/master/pinCode/getAll`)
      .then((res) => {
        console.log("pin", res?.data?.pinCode);
        setCrPinCodes(res?.data?.pinCode);
      })
      .catch((err) => console.log(err));
  };

  // useEffect(() => {
  //   if (router.query.pageMode == "Edit") {
  //     console.log("hello", router.query.informerName);
  //     setBtnSaveText("Update");

  //     // setValue("informerName", router.query.informerName);
  //     reset(router.query);
  //   }
  // }, []);

  useEffect(() => {
    if (router.query.pageMode === "Edit" || router.query.pageMode === "View")
      reset(router.query);
  }, []);

  // Titles
  const [titles, setTitles] = useState([]);

  //
  const [crPincodes, setCrPinCodes] = useState([]);

  // getTitles
  // const getTitles = () => {
  //   axios
  //     .get(`${urls.CFCURL}/religionMaster/getReligionMasterData`)
  //     .then((r) => {
  //       setTitles(
  //         r.data.map((row) => ({
  //           id: row.id,
  //           title: row.title,
  //         }))
  //       );
  //     });
  // };

  // Religions
  const [genders, setGenders] = useState([]);

  // getGenders
  // const getGenders = () => {
  //   axios
  //     .get(`${urls.FbsURL}/religionMaster/getReligionMasterData`)
  //     .then((r) => {
  //       setGenders(
  //         r.data.map((row) => ({
  //           id: row.id,
  //           gender: row.gender,
  //         }))
  //       );
  //     });
  // };

  // casts
  const [casts, setCasts] = useState([]);

  // getCasts
  // const getCasts = () => {
  //   axios
  //     .get(`${urls.FbsURL}/religionMaster/getReligionMasterData`)
  //     .then((r) => {
  //       setCasts(
  //         r.data.map((row) => ({
  //           id: row.id,
  //           cast: row.cast,
  //         }))
  //       );
  //     });
  // };

  // Religions
  const [religions, setReligions] = useState([]);

  // getReligions
  // const getReligions = () => {
  //   axios
  //     .get(`${urls.FbsURL}/religionMaster/getReligionMasterData`)
  //     .then((r) => {
  //       setReligions(
  //         r.data.map((row) => ({
  //           id: row.id,
  //           religion: row.religion,
  //         }))
  //       );
  //     });
  // };

  // subCasts
  const [subCasts, setSubCast] = useState([]);

  // getSubCast
  // const getSubCast = () => {
  //   axios
  //     .get(`${urls.FbsURL}/religionMaster/getReligionMasterData`)
  //     .then((r) => {
  //       setSubCast(
  //         r.data.map((row) => ({
  //           id: row.id,
  //           subCast: row.subCast,
  //         }))
  //       );
  //     });
  // };

  // typeOfDisabilitys
  const [typeOfDisabilitys, setTypeOfDisability] = useState([]);

  // getTypeOfDisability
  // const getTypeOfDisability = () => {
  //   axios
  //     .get(`${urls.FbsURL}/religionMaster/getReligionMasterData`)
  //     .then((r) => {
  //       setTypeOfDisability(
  //         r.data.map((row) => ({
  //           id: row.id,
  //           typeOfDisability: row.typeOfDisability,
  //         }))
  //       );
  //     });
  // };

  // useEffect
  // useEffect(() => {
  //   getTitles();
  //   getTypeOfDisability();
  //   getGenders();
  //   getCasts();
  //   getSubCast();
  //   getReligions();
  // }, []);

  return (
    <>
      <div className={styles.details}>
        <div className={styles.h1Tag}>
          <h3
            style={{
              color: "white",
              marginTop: "5px",
              paddingLeft: 10,
            }}
          >
            {<FormattedLabel id="informerDetails" />}
          </h3>
        </div>
      </div>
      <br />
      <Grid
        container
        columns={{ xs: 4, sm: 8, md: 12 }}
        className={styles.feildres}
      >
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            autoFocus
            id="standard-basic"
            label={<FormattedLabel id="informerName" />}
            variant="standard"
            {...register("informerName")}
            error={!!errors.informerName}
            helperText={
              errors?.informerName ? errors.informerName.message : null
            }
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="informerMiddleName" />}
            variant="standard"
            {...register("informerMiddleName")}
            error={!!errors.informerMiddleName}
            helperText={
              errors?.informerMiddleName
                ? errors.informerMiddleName.message
                : null
            }
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="informerLastName" />}
            variant="standard"
            {...register("informerLastName")}
            error={!!errors.informerLastName}
            helperText={
              errors?.informerLastName ? errors.informerLastName.message : null
            }
          />
        </Grid>
        {/* marathi */}
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            autoFocus
            id="standard-basic"
            label={<FormattedLabel id="informerNameMr" />}
            variant="standard"
            {...register("informerNameMr")}
            error={!!errors.informerNameMr}
            helperText={
              errors?.informerNameMr ? errors.informerNameMr.message : null
            }
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="informerMiddleNameMr" />}
            variant="standard"
            {...register("informerMiddleNameMr")}
            error={!!errors.informerMiddleNameMr}
            helperText={
              errors?.informerMiddleNameMr
                ? errors.informerMiddleNameMr.message
                : null
            }
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="informerLastNameMr" />}
            variant="standard"
            {...register("informerLastNameMr")}
            error={!!errors.informerLastNameMr}
            helperText={
              errors?.informerLastNameMr
                ? errors.informerLastNameMr.message
                : null
            }
          />
        </Grid>
      </Grid>
      <Grid
        container
        columns={{ xs: 4, sm: 8, md: 12 }}
        className={styles.feildres}
      >
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="area" />}
            variant="standard"
            {...register("area")}
            error={!!errors.area}
            helperText={errors?.area ? errors.area.message : null}
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="city" />}
            variant="standard"
            {...register("city")}
            error={!!errors.city}
            helperText={errors?.city ? errors.city.message : null}
          />
        </Grid>

        <Grid item xs={4} className={styles.feildres}>
          <FormControl
            variant="standard"
            sx={{ width: "65%" }}
            error={!!errors.crPincode}
          >
            <InputLabel id="demo-simple-select-standard-label">
              Pin Code
            </InputLabel>
            <Controller
              render={({ field }) => (
                <Select
                  value={field.value}
                  onChange={(value) => field.onChange(value)}
                  label="Pin Code"
                >
                  {crPincodes &&
                    crPincodes.map((crPincode, index) => (
                      <MenuItem key={index} value={crPincode.id}>
                        {crPincode.pinCode}
                      </MenuItem>
                    ))}
                </Select>
              )}
              name="pinCode"
              control={control}
              defaultValue=""
            />
            <FormHelperText>
              {errors?.pinCode ? errors.pinCode.message : null}
            </FormHelperText>
          </FormControl>
        </Grid>
        {/* marathi */}
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="areaMr" />}
            variant="standard"
            {...register("areaMr")}
            error={!!errors.areaMr}
            helperText={errors?.areaMr ? errors.areaMr.message : null}
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="cityMr" />}
            variant="standard"
            {...register("cityMr")}
            error={!!errors.cityMr}
            helperText={errors?.cityMr ? errors.cityMr.message : null}
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="contactNumber" />}
            variant="standard"
            {...register("contactNumber")}
            error={!!errors.contactNumber}
            helperText={
              errors?.contactNumber ? errors.contactNumber.message : null
            }
          />
        </Grid>
      </Grid>
      <br />
      <br />

      <div className={styles.details}>
        <div className={styles.h1Tag}>
          <h3
            style={{
              color: "white",
              marginTop: "5px",
              paddingLeft: 10,
            }}
          >
            {<FormattedLabel id="vardiDetails" />}

            {/* {<FormattedLabel id="ApplicatDetails" />}{" "} */}
          </h3>
        </div>
      </div>
      <Grid
        container
        columns={{ xs: 4, sm: 8, md: 12 }}
        className={styles.feildres}
      >
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="occurancePlace" />}
            variant="standard"
            {...register("occurancePlace")}
            error={!!errors.occurancePlace}
            helperText={
              errors?.occurancePlace ? errors.occurancePlace.message : null
            }
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="landmark" />}
            variant="standard"
            {...register("landmark")}
            error={!!errors.landmark}
            helperText={errors?.landmark ? errors.landmark.message : null}
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <FormControl
            error={!!errors.dateAndTimeOfVardi}
            sx={{ width: "75%" }}
          >
            <Controller
              control={control}
              defaultValue={moment().format("YYYY-DD-MMThh:mm:ss")}
              name="dateAndTimeOfVardi"
              render={({ field }) => (
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <DateTimePicker
                    readOnly
                    label={<FormattedLabel id="dateAndTimeOfVardi" />}
                    value={field.value}
                    onChange={(date) =>
                      field.onChange(moment(date).format("YYYY-DD-MM hh:mm:ss"))
                    }
                    //selected={field.value}
                    renderInput={(params) => (
                      <TextField size="small" {...params} />
                    )}
                  />
                </LocalizationProvider>
              )}
            />
            <FormHelperText>
              {errors?.dateAndTimeOfVardi
                ? errors.dateAndTimeOfVardi.message
                : null}
            </FormHelperText>
          </FormControl>
        </Grid>
        {/* marathi */}
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="occurancePlaceMr" />}
            variant="standard"
            {...register("occurancePlaceMr")}
            error={!!errors.occurancePlaceMr}
            helperText={
              errors?.occurancePlaceMr ? errors.occurancePlaceMr.message : null
            }
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="landmarkMr" />}
            variant="standard"
            {...register("landmarkMr")}
            error={!!errors.landmarkMr}
            helperText={errors?.landmarkMr ? errors.landmarkMr.message : null}
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <FormControl error={!!errors.departureTime} sx={{ width: "75%" }}>
            <Controller
              control={control}
              defaultValue={null}
              name="departureTime"
              render={({ field }) => (
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <TimePicker
                    label="Vardi Dispatch Time"
                    value={field.value}
                    onChange={(time) => {
                      field.onChange(time);
                    }}
                    renderInput={(params) => (
                      <TextField size="small" {...params} />
                    )}
                  />
                </LocalizationProvider>
              )}
            />
            <FormHelperText>
              {errors?.departureTime ? errors.departureTime.message : null}
            </FormHelperText>
          </FormControl>
        </Grid>
      </Grid>
      <Grid
        container
        columns={{ xs: 4, sm: 8, md: 12 }}
        className={styles.feildres}
      >
        <Grid item xs={4} className={styles.feildres}>
          <FormControl
            sx={{ minWidth: "70%" }}
            variant="standard"
            error={!!errors.typeOfVardiId}
          >
            <InputLabel id="demo-simple-select-standard-label">
              <FormattedLabel id="typeOfVardi" />
            </InputLabel>
            <Controller
              render={({ field }) => (
                <Select
                  fullWidth
                  value={field.value}
                  onChange={(value) => {
                    console.log("value", value);
                    field.onChange(value);
                    setShowVardiOther(value.target.value);
                  }}
                  label={<FormattedLabel id="typeOfVardi" />}
                >
                  {vardiTypes &&
                    vardiTypes.map((vardi, index) => (
                      <MenuItem key={index} value={vardi.id}>
                        {language == "en" ? vardi.vardiName : vardi.vardiNameMr}
                      </MenuItem>
                    ))}
                </Select>
              )}
              name="typeOfVardiId"
              control={control}
              defaultValue=""
            />
            <FormHelperText>
              {errors?.typeOfVardiId ? errors.typeOfVardiId.message : null}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          {showVardiOther === 4 && (
            <TextField
              id="standard-basic"
              label={<FormattedLabel id="other" />}
              variant="standard"
              {...register("typeOfVardiId")}
              error={!!errors.typeOfVardiId}
              helperText={
                errors?.typeOfVardiId ? errors.typeOfVardiId.message : null
              }
            />
          )}
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="manPowerLoss" />}
            variant="standard"
            {...register("manPowerLoss")}
            error={!!errors.manPowerLoss}
            helperText={
              errors?.manPowerLoss ? errors.manPowerLoss.message : null
            }
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <FormControl
            variant="standard"
            sx={{ minWidth: "65%" }}
            error={!!errors.slipHandedOverTo}
          >
            <InputLabel id="demo-simple-select-standard-label">
              {<FormattedLabel id="slipHandedOverToEmp" />}
            </InputLabel>
            <Controller
              render={({ field }) => (
                <Select
                  value={field.value}
                  onChange={(value) => {
                    console.log("value", value);
                    field.onChange(value);
                    setSlipHandedOverTo(value.target.value);
                  }}
                  // onChange={(value) => field.onChange(value)}
                  label={<FormattedLabel id="slipHandedOverToEmp" />}
                >
                  {[
                    { id: 1, menuNameEng: "Yes" },
                    { id: 2, menuNameEng: "No" },
                  ].map((menu, index) => {
                    return (
                      <MenuItem key={index} value={menu.id}>
                        {menu.menuNameEng}
                      </MenuItem>
                    );
                  })}
                </Select>
              )}
              name="slipHandedOverTo"
              control={control}
              defaultValue=""
            />
            <FormHelperText>
              {errors?.slipHandedOverTo
                ? errors.slipHandedOverTo.message
                : null}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          {SlipHandedOverTo === 1 && (
            <FormControl
              variant="standard"
              sx={{ minWidth: "70%" }}
              error={!!errors.slipHandedOverTo}
            >
              <InputLabel id="demo-simple-select-standard-label">
                {<FormattedLabel id="fireStationName" />}
              </InputLabel>
              <Controller
                render={({ field }) => (
                  <Select
                    value={field.value}
                    onChange={(value) => field.onChange(value)}
                    label={<FormattedLabel id="fireStationName" />}
                  >
                    {fireStation &&
                      fireStation.map((fire, index) => (
                        <MenuItem key={index} value={fire.id}>
                          {language == "en"
                            ? fire.fireStationName
                            : fire.fireStationNameMr}
                        </MenuItem>
                      ))}
                  </Select>
                )}
                name="slipHandedOverTo"
                control={control}
                defaultValue=""
              />
              <FormHelperText>
                {errors?.slipHandedOverTo
                  ? errors.slipHandedOverTo.message
                  : null}
              </FormHelperText>
            </FormControl>
          )}
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="lossInAmount" />}
            variant="standard"
            {...register("lossInAmount")}
            error={!!errors.lossInAmount}
            helperText={
              errors?.lossInAmount ? errors.lossInAmount.message : null
            }
          />
        </Grid>
      </Grid>
      <Grid
        container
        columns={{ xs: 4, sm: 8, md: 12 }}
        className={styles.feildres}
      >
        <Grid item xs={4} className={styles.feildres}>
          <FormControl
            variant="standard"
            sx={{ minWidth: "65%" }}
            // size="small"
            error={!!errors.reasonOfFire}
          >
            <InputLabel id="demo-simple-select-standard-label">
              <FormattedLabel id="reasonOfFire" />
            </InputLabel>
            <Controller
              render={({ field }) => (
                <Select
                  value={field.value}
                  // onChange={(value) => field.onChange(value)}
                  onChange={(value) => {
                    console.log("value", value);
                    field.onChange(value);
                    setShowFireOther(value.target.value);
                  }}
                  label={<FormattedLabel id="reasonOfFire" />}
                >
                  {reason &&
                    reason.map((res, index) => (
                      <MenuItem key={index} value={res.id}>
                        {language == "en"
                          ? res.reasonOfFire
                          : res.reasonOfFireMr}
                      </MenuItem>
                    ))}
                </Select>
              )}
              name="reasonOfFire"
              control={control}
              defaultValue=""
            />
            <FormHelperText>
              {errors?.reasonOfFire ? errors.reasonOfFire.message : null}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          {showFireOther === "Other" && (
            <TextField
              id="standard-basic"
              defaultValue={null}
              label={<FormattedLabel id="other" />}
              variant="standard"
              {...register("reasonOfFire")}
              error={!!errors.reasonOfFire}
              helperText={
                errors?.reasonOfFire ? errors.reasonOfFire.message : null
              }
            />
          )}
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          {" "}
          <FormControl
            variant="standard"
            sx={{ minWidth: "65%" }}
            error={!!errors.employeeDetailsDuringFireWorks}
          >
            <InputLabel id="demo-simple-select-standard-label">
              {<FormattedLabel id="employeeDetailsDuringFireWorks" />}
            </InputLabel>
            <Controller
              render={({ field }) => (
                <Select
                  value={field.value}
                  onChange={(value) => field.onChange(value)}
                  label="List"
                >
                  {userLst.map((user, index) => (
                    <MenuItem key={index} value={user.id}>
                      {user.firstName +
                        " " +
                        (typeof user.middleName === "string"
                          ? user.middleName
                          : " ") +
                        " " +
                        user.lastName}
                    </MenuItem>
                  ))}
                </Select>
              )}
              name="employeeDetailsDuringFireWorks"
              control={control}
              defaultValue=""
            />
            <FormHelperText>
              {errors?.employeeDetailsDuringFireWorks
                ? errors.employeeDetailsDuringFireWorks.message
                : null}
            </FormHelperText>
          </FormControl>
        </Grid>

        <Grid item xs={4} className={styles.feildres}>
          <FormControl
            variant="standard"
            sx={{ minWidth: "65%" }}
            error={!!errors.nameOfSubFireOfficer}
          >
            <InputLabel id="demo-simple-select-standard-label">
              {/* Name of Subfire Officer/Station Officer */}
              {<FormattedLabel id="nameOfSubFireOfficer" />}
            </InputLabel>
            <Controller
              render={({ field }) => (
                <Select
                  value={field.value}
                  onChange={(value) => field.onChange(value)}
                  label="List"
                >
                  {userLst &&
                    userLst
                      .filter((u) => u.desg === "SFO")
                      .map((user, index) => (
                        <MenuItem key={index} value={user.id}>
                          {user.firstName +
                            " " +
                            (typeof user.middleName === "string"
                              ? user.middleName
                              : " ") +
                            " " +
                            user.lastName}
                        </MenuItem>
                      ))}
                </Select>
              )}
              name="nameOfSubFireOfficer"
              control={control}
              defaultValue=""
            />
            <FormHelperText>
              {errors?.nameOfSubFireOfficer
                ? errors.nameOfSubFireOfficer.message
                : null}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          {" "}
          <FormControl
            variant="standard"
            sx={{ minWidth: "65%" }}
            error={!!errors.nameOfMainFireOfficer}
          >
            <InputLabel id="demo-simple-select-standard-label">
              {/* Name of main Fire Officer */}
              {<FormattedLabel id="nameOfMainFireOfficer" />}
            </InputLabel>
            <Controller
              render={({ field }) => (
                <Select
                  value={field.value}
                  onChange={(value) => field.onChange(value)}
                  label="List"
                >
                  {/* {businessTypes &&
                    businessTypes.map((businessType, index) => (
                      <MenuItem key={index} value={businessType.id}>
                        {businessType.businessType}
                      </MenuItem>
                    ))} */}
                </Select>
              )}
              name="nameOfMainFireOfficer"
              control={control}
              defaultValue=""
            />
            <FormHelperText>
              {errors?.nameOfMainFireOfficernameOfMainFireOfficer
                ? errors.nameOfMainFireOfficernameOfMainFireOfficer.message
                : null}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={4} className={styles.feildres}></Grid>
        <Grid item xs={4} className={styles.feildres}></Grid>
      </Grid>

      {/** Third Row */}
      <Grid
        container
        columns={{ xs: 4, sm: 8, md: 12 }}
        className={styles.feildres}
      >
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="nameOfTenant" />}
            variant="standard"
            {...register("nameOfOwner")}
            error={!!errors.nameOfTenant}
            helperText={
              errors?.nameOfTenant ? errors.nameOfTenant.message : null
            }
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="nameOfTenant" />}
            variant="standard"
            {...register("nameOfTenant")}
            error={!!errors.nameOfTenant}
            helperText={
              errors?.nameOfTenant ? errors.nameOfTenant.message : null
            }
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="distanceFromSubFireStation" />}
            variant="standard"
            {...register("distanceFromSubFireStation")}
            error={!!errors.distanceFromSubFireStation}
            helperText={
              errors?.distanceFromSubFireStation
                ? errors.distanceFromSubFireStation.message
                : null
            }
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="nameOfOwnerMr" />}
            variant="standard"
            {...register("nameOfOwnerMr")}
            error={!!errors.nameOfOwnerMr}
            helperText={
              errors?.nameOfOwnerMr ? errors.nameOfOwnerMr.message : null
            }
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="nameOfTenantMr" />}
            variant="standard"
            {...register("nameOfTenantMr")}
            error={!!errors.nameOfTenantMr}
            helperText={
              errors?.nameOfTenantMr ? errors.nameOfTenantMr.message : null
            }
          />
        </Grid>
        <Grid item xs={4} className={styles.feildres}>
          <TextField
            id="standard-basic"
            label={<FormattedLabel id="distanceFromMainFireStation" />}
            variant="standard"
            {...register("distanceFromMainFireStation")}
          />
        </Grid>
      </Grid>

      <br />
      <br />
      <br />
    </>
  );
};

export default FireDetails;

// Address
// House Number
// Buildig name
// Road name
// area
// city
// pincode
