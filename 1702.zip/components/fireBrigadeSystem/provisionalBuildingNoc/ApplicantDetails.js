import { yupResolver } from "@hookform/resolvers/yup";
import AddIcon from "@mui/icons-material/Add";
import ClearIcon from "@mui/icons-material/Clear";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";
import SaveIcon from "@mui/icons-material/Save";
import {
  Box,
  Button,
  FormControl,
  FormHelperText,
  InputLabel,
  Paper,
  Select,
  MenuItem,
  Slide,
  TextField,
  List,
  Grid,
  Card,
  Typography,
  AppBar,
  Toolbar,
  FormControlLabel,
  FormGroup,
  Checkbox,
  NativeSelect,
} from "@mui/material";
import IconButton from "@mui/material/IconButton";
import { DataGrid } from "@mui/x-data-grid";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { message } from "antd";
import axios from "axios";
import moment from "moment";
import React, { useEffect, useState } from "react";
import {
  Controller,
  FormProvider,
  useForm,
  useFormContext,
  useFieldArray,
} from "react-hook-form";

import { useRouter } from "next/router";
import dayjs from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import MenuIcon from "@mui/icons-material/Menu";
import FormattedLabel from "../../../containers/reuseableComponents/FormattedLabel";

import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import { DatePicker } from "@mui/x-date-pickers";
import styles from "../../../styles/fireBrigadeSystem/view.module.css";

const ApplicantDetails = () => {
  // Exit button Routing
  const [valueDate, setValueDate] = React.useState(dayjs(""));
  const [valueDateTime, setValueDateTime] = React.useState(dayjs(""));

  // Set Current Date and Time
  const currDate = new Date().toLocaleDateString();
  const currTime = new Date().toLocaleTimeString();

  const {
    control,
    register,
    reset,
    getValues,
    formState: { errors },
  } = useFormContext();

  const router = useRouter();

  // const {
  //   register,
  //   control,
  //   handleSubmit,
  //   methods,
  //   setValue,
  //   reset,
  //   formState: { errors },
  // } = useForm({
  //   criteriaMode: "all",
  //   resolver: yupResolver(schema),
  //   mode: "onChange",
  // });

  const [btnSaveText, setBtnSaveText] = useState("Save");
  const [dataSource, setDataSource] = useState([]);
  const [buttonInputState, setButtonInputState] = useState();
  const [isOpenCollapse, setIsOpenCollapse] = useState(false);
  const [id, setID] = useState();
  const [editButtonInputState, setEditButtonInputState] = useState(false);
  const [deleteButtonInputState, setDeleteButtonState] = useState(false);
  const [slideChecked, setSlideChecked] = useState(false);
  const [businessTypes, setBusinessTypes] = useState([]);
  const [fetchData, setFetchData] = useState(null);

  // useEffect - Reload On update , delete ,Saved on refresh
  //   useEffect(() => {
  //     getBusinessTypes();
  //   }, []);

  //   useEffect(() => {
  //     getBusinesSubType();
  //   }, [businessTypes]);

  //   const getBusinessTypes = () => {
  //     axios.get(`${urls.FbsURL}/businessType/getBusinessTypeData`).then((r) => {
  //       setBusinessTypes(
  //         r.data.map((row) => ({
  //           id: row.id,
  //           businessType: row.businessType,
  //         }))
  //       );
  //     });
  //   };
  const [activeStep, setActiveStep] = useState(0);
  const steps = getSteps();
  //useEffect
  useEffect(() => {
    if (getValues(`groupDetails.length`) == 0) {
      appendFun();
    }
  }, []);
  // useEffect(() => {
  //   if (router.query.pageMode == "") {
  //     setId(router.query.id1);
  //     //setId(208);
  //     // console.log(id);
  //   }
  // }, []);

  function getSteps() {
    return [
      // "",
      "Applicant Details",
      "Forms Details",
      "Purpose Of Building Use",
      "Other Details",
    ];
  }

  //key={field.id}
  const { fields, append, prepend, remove, swap, move, insert } = useFieldArray(
    {
      control, // control props comes from useForm (optional: if you are using FormContext)
      name: "groupDetails", // unique name for your Field Array
    }
  );
  const appendFun = () => {
    append({
      applicantName: "",
      applicantMiddleName: "",
      applicantLastName: "",
      applicantNameMr: "",
      applicantMiddleNameMr: "",
      applicantLastNameMr: "",
      officeContactNo: "",
      workingSiteOnsitePersonMobileNo: "",
      emailId: "",
    });
  };

  // cancell Button
  const cancellButton = () => {
    reset({
      ...resetValuesCancell,
      id,
    });
  };
  const [btnValue, setButtonValue] = useState(false);

  // Disable Add Button After Three Wintess Add
  const buttonValueSetFun = () => {
    if (getValues(`groupDetails.length`) >= 5) {
      setButtonValue(true);
    } else {
      appendFun();
      // reset();
      setButtonValue(false);
    }
  };

  // Reset Values Cancell
  // const resetValuesCancell = {
  //   applicantName: "",
  //   applicantMiddleName: "",
  //   applicantLastName: "",
  //   applicationDate: "",
  //   officeContactNo: "",
  //   workingSiteOnsitePersonMobileNo: "",
  //   emailId: "",
  // };

  // Reset Values Exit
  // const resetValuesExit = {
  //   applicantName: "",
  //   applicationDate: "",
  //   officeContactNo: "",
  //   workingSiteOnsitePersonMobileNo: "",
  //   emailId: "",
  // };

  return (
    <>
      {fields.map((groupDetails, index) => {
        return (
          <>
            <div>
              <h3
                style={{
                  color: "black",
                  marginTop: "7px",
                }}
              >
                Member
                {`: ${index + 1}`}
              </h3>
              <Grid
                container
                columns={{ xs: 4, sm: 8, md: 12 }}
                // className={styles.feildres}
                sx={{ marginLeft: "6%" }}
              ></Grid>
              <Grid
                container
                columns={{ xs: 4, sm: 8, md: 12 }}
                className={styles.feildres}
              >
                <Grid item xs={4} className={styles.feildres}>
                  <TextField
                    id="standard-basic"
                    label={<FormattedLabel id="applicantName" />}
                    variant="standard"
                    key={groupDetails.id}
                    {...register(`groupDetails.${index}.applicantName`)}
                    error={!!errors.applicantName}
                    helperText={
                      errors?.applicantName
                        ? errors.applicantName.message
                        : null
                    }
                  />
                </Grid>
                <Grid item xs={4} className={styles.feildres}>
                  <TextField
                    id="standard-basic"
                    label={<FormattedLabel id="applicantMiddleName" />}
                    variant="standard"
                    key={groupDetails.id}
                    {...register(`groupDetails.${index}.applicantMiddleName`)}
                    error={!!errors.applicantMiddleName}
                    helperText={
                      errors?.applicantMiddleName
                        ? errors.applicantMiddleName.message
                        : null
                    }
                  />
                </Grid>
                <Grid item xs={4} className={styles.feildres}>
                  <TextField
                    id="standard-basic"
                    label={<FormattedLabel id="applicantLastName" />}
                    variant="standard"
                    key={groupDetails.id}
                    {...register(`groupDetails.${index}.applicantLastName`)}
                    error={!!errors.applicantLastName}
                    helperText={
                      errors?.applicantLastName
                        ? errors.applicantLastName.message
                        : null
                    }
                  />
                </Grid>
                <Grid item xs={4} className={styles.feildres}>
                  <TextField
                    id="standard-basic"
                    label={<FormattedLabel id="applicantNameMr" />}
                    variant="standard"
                    key={groupDetails.id}
                    {...register(`groupDetails.${index}.applicantNameMr`)}
                    error={!!errors.applicantNameMr}
                    helperText={
                      errors?.applicantNameMr
                        ? errors.applicantNameMr.message
                        : null
                    }
                  />
                </Grid>
                <Grid item xs={4} className={styles.feildres}>
                  <TextField
                    id="standard-basic"
                    label={<FormattedLabel id="applicantMiddleNameMr" />}
                    variant="standard"
                    {...register(`groupDetails.${index}.applicantMiddleNameMr`)}
                    key={groupDetails.id}
                    error={!!errors.applicantMiddleNameMr}
                    helperText={
                      errors?.applicantMiddleNameMr
                        ? errors.applicantMiddleNameMr.message
                        : null
                    }
                  />
                </Grid>
                <Grid item xs={4} className={styles.feildres}>
                  <TextField
                    id="standard-basic"
                    label={<FormattedLabel id="applicantLastNameMr" />}
                    variant="standard"
                    key={groupDetails.id}
                    {...register(`groupDetails.${index}.applicantLastNameMr`)}
                    error={!!errors.applicantLastNameMr}
                    helperText={
                      errors?.applicantLastNameMr
                        ? errors.applicantLastNameMr.message
                        : null
                    }
                  />
                </Grid>
              </Grid>
              <Grid
                container
                columns={{ xs: 4, sm: 8, md: 12 }}
                className={styles.feildres}
              >
                <Grid item xs={4} className={styles.feildres}>
                  <TextField
                    id="standard-basic"
                    label={<FormattedLabel id="mobileNo" />}
                    variant="standard"
                    key={groupDetails.id}
                    {...register(`groupDetails.${index}.mobileNo`)}
                    // type="number"
                    error={!!errors.officeContactNo}
                    helperText={
                      errors?.officeContactNo
                        ? errors.officeContactNo.message
                        : null
                    }
                  />
                </Grid>
                {/* <Grid item xs={4} className={styles.feildres}>
                  <TextField
                    id="standard-basic"
                    label={
                      <FormattedLabel id="workingSiteOnsitePersonMobileNo" />
                    }
                    variant="standard"
                    // type="number"
                    key={groupDetails.id}
                    {...register(
                      `groupDetails.${index}.workingSiteOnsitePersonMobileNo`
                    )}
                    error={!!errors.workingSiteOnsitePersonMobileNo}
                    helperText={
                      errors?.workingSiteOnsitePersonMobileNo
                        ? errors.workingSiteOnsitePersonMobileNo.message
                        : null
                    }
                  />
                </Grid> */}
                <Grid item xs={4} className={styles.feildres}>
                  <TextField
                    id="standard-basic"
                    label={<FormattedLabel id="emailId" />}
                    variant="standard"
                    key={groupDetails.id}
                    {...register(`groupDetails.${index}.emailId`)}
                    error={!!errors.emailId}
                    helperText={errors?.emailId ? errors.emailId.message : null}
                  />
                </Grid>
                <Grid item xs={4} className={styles.feildres}></Grid>
              </Grid>
            </div>
          </>
        );
      })}
      <br></br>
      <br></br>

      <br></br>
      <Grid item xs={4} className={styles.feildres}>
        <Button
          disabled={btnValue}
          onClick={() => buttonValueSetFun()}
          variant="contained"
        >
          Add Multiple Details
        </Button>
      </Grid>
    </>
  );
};

export default ApplicantDetails;
