import ClearIcon from "@mui/icons-material/Clear"
import ExitToAppIcon from "@mui/icons-material/ExitToApp"
import {
  Box,
  Button,
  Checkbox,
  FormControl,
  FormControlLabel,
  FormHelperText,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material"
import axios from "axios"
import { useRouter } from "next/router"
import React, { useEffect, useState } from "react"
import { Controller, useFormContext } from "react-hook-form"
import { useDispatch, useSelector } from "react-redux"
import styles from "./view.module.css"
import FormattedLabel from "../../containers/reuseableComponents/FormattedLabel"
import urls from "../../URLS/urls"
const Form = () => {
  const {
    register,
    control,
    handleSubmit,
    methods,
    setValue,
    reset,
    formState: { errors },
  } = useFormContext({
    criteriaMode: "all",
    // resolver: yupResolver(schema),
    mode: "onChange",
  })

  const [btnSaveText, setBtnSaveText] = useState("Save")
  const [dataSource, setDataSource] = useState([])
  const [buttonInputState, setButtonInputState] = useState()
  const [isOpenCollapse, setIsOpenCollapse] = useState(false)
  const [id, setID] = useState()
  const [userDetails, setUserDetails] = useState()
  const [editButtonInputState, setEditButtonInputState] = useState(false)
  const [deleteButtonInputState, setDeleteButtonState] = useState(false)
  const [slideChecked, setSlideChecked] = useState(false)
  const [businessTypes, setBusinessTypes] = useState([])
  const router = useRouter()
  const [activeStep, setActiveStep] = useState()
  const [checked, setChecked] = useState(true)
  //   const steps = getSteps();
  const dispach = useDispatch()
  const [titles, setTitles] = useState([])

  const user = useSelector((state) => {
    console.log("userDetails", state?.user?.user?.userDao)
    return state?.user?.user?.userDao
  })

  useEffect(() => {
    getTitles()
  }, [])

  // useEffect(() => {
  //   getUserDetails()
  // }, [])

  // const getUserDetails = () => {
  //   axios.get(`${urls.GM}/master/user/getById?id=1`).then((r) => {
  //     reset(r.data)
  //   })
  // }

  const getTitles = () => {
    axios.get(`${urls.CFCURL}/master/title/getAll`).then((r) => {
      setTitles(
        r.data.title.map((row) => ({
          id: row.id,
          title: row.title,
        }))
      )
    })
  }

  useEffect(() => {
    // if (router.query.pageMode === 'EDIT' || router.query.pageMode === 'View') {
    //   reset(router.query)
    // }
    // console.log("user123", user)
    setValue("firstName", user?.firstNameEn)
    setValue("middleName", user?.middleNameEn)
    setValue("surname", user?.lastNameEn)
    setValue("email", user?.email)
  }, [user])

  const editRecord = (rows) => {
    setBtnSaveText("Update"),
      setID(rows.id),
      setIsOpenCollapse(true),
      setSlideChecked(true)
    reset(rows)
  }

  // cancell Button
  const cancellButton = () => {
    reset({
      ...resetValuesCancell,
      id,
    })
  }

  const resetValuesCancell = {
    fromDate: null,
    toDate: null,
    businessType: "",
    businessSubType: "",
    businessSubTypePrefix: "",
    pinCode: "",
    remark: "",
  }

  // Reset Values Exit
  const resetValuesExit = {
    fromDate: null,
    toDate: null,
    businessType: "",
    businessSubType: "",
    businessSubTypePrefix: "",
    remark: "",
    id: null,
  }

  // Handle Back
  const handleBack = () => {
    setActiveStep(activeStep - 1)
  }
  // View
  return (
    <Box>
      {/* <div className={styles.details}>
            <div className={styles.h1Tag}>
              <h3
                style={{
                  color: "white",
                  marginTop: "7px",
                }}
              >
                {" "}
                {<FormattedLabel id="personalDetails" />}
              </h3>
            </div>
          </div> */}

      <Box
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          padding: "1%",
        }}
      >
        <Box
          className={styles.details1}
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            width: "80%",
            height: "auto",
            overflow: "auto",
            padding: "0.2%",
            color: "black",
            fontSize: 15,
            fontWeight: 400,
            borderRadius: 100,
          }}
        >
          <strong>
            {/* <FormattedLabel id="amenitiesMaster" /> */}
            PERSONAL DETAILS
          </strong>
        </Box>
      </Box>

      <Grid
        container
        spacing={2}
        style={{
          padding: "10px",
          display: "flex",
          alignItems: "baseline",
        }}
      >
        <Grid
          item
          xs={12}
          sm={6}
          md={4}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <FormControl style={{ minWidth: "230px" }} error={!!errors.title}>
            <InputLabel id="demo-simple-select-standard-label">
              Title
            </InputLabel>
            <Controller
              render={({ field }) => (
                <Select
                  autoFocus
                  value={field.value}
                  onChange={(value) => field.onChange(value)}
                  label="Title"
                >
                  {titles &&
                    titles.map((title, index) => (
                      <MenuItem key={index} value={title.id}>
                        {title.title}
                      </MenuItem>
                    ))}
                </Select>
              )}
              name="title"
              control={control}
              defaultValue=""
            />
            <FormHelperText>
              {errors?.title ? errors.title.message : null}
            </FormHelperText>
          </FormControl>
        </Grid>

        <Grid
          item
          xs={12}
          sm={6}
          md={4}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <TextField
            disabled={user ? true : false}
            InputLabelProps={{ shrink: user ? true : false }}
            id="standard-basic"
            label="First Name"
            variant="standard"
            {...register("firstName")}
            error={!!errors.firstName}
            helperText={errors?.firstName ? errors.firstName.message : null}
          />
        </Grid>

        <Grid
          item
          xs={12}
          sm={6}
          md={4}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <TextField
            disabled={user ? true : false}
            InputLabelProps={{ shrink: user ? true : false }}
            id="standard-basic"
            label="Middle Name"
            variant="standard"
            {...register("middleName")}
            error={!!errors.middleName}
            helperText={errors?.middleName ? errors.middleName.message : null}
          />
        </Grid>

        <Grid
          item
          xs={12}
          sm={6}
          md={4}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <TextField
            disabled={user ? true : false}
            InputLabelProps={{ shrink: user ? true : false }}
            id="standard-basic"
            label="Sur Name"
            variant="standard"
            {...register("surname")}
            error={!!errors.surname}
            helperText={errors?.surname ? errors.surname.message : null}
          />
        </Grid>

        <Grid
          item
          xs={12}
          sm={6}
          md={4}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <TextField
            id="standard-basic"
            label="House Number"
            variant="standard"
            {...register("houseNo")}
            error={!!errors.houseNo}
            helperText={errors?.houseNo ? errors.houseNo.message : null}
          />
        </Grid>

        <Grid
          item
          xs={12}
          sm={6}
          md={4}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <TextField
            id="standard-basic"
            label="Building No"
            variant="standard"
            {...register("buildingNo")}
            error={!!errors.buildingNo}
            helperText={errors?.buildingNo ? errors.buildingNo.message : null}
          />
        </Grid>

        <Grid
          item
          xs={12}
          sm={6}
          md={4}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <TextField
            id="standard-basic"
            label="Road Name"
            variant="standard"
            {...register("roadName")}
            error={!!errors.roadName}
            helperText={errors?.roadName ? errors.roadName.message : null}
          />
        </Grid>

        <Grid
          item
          xs={12}
          sm={6}
          md={4}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <TextField
            // sx={{ width: 280 }}
            id="standard-basic"
            label="Area"
            variant="standard"
            {...register("area")}
            error={!!errors.area}
            helperText={errors?.area ? errors.area.message : null}
          />
        </Grid>

        <Grid
          item
          xs={12}
          sm={6}
          md={4}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <TextField
            // sx={{ width: 250 }}
            id="standard-basic"
            label="Location"
            variant="standard"
            {...register("location")}
            error={!!errors.location}
            helperText={errors?.location ? errors.location.message : null}
          />
        </Grid>

        <Grid
          item
          xs={12}
          sm={6}
          md={4}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <TextField
            // sx={{ width: 250 }}
            id="standard-basic"
            label="City"
            variant="standard"
            {...register("city")}
            error={!!errors.city}
            helperText={errors?.city ? errors.city.message : null}
          />
        </Grid>

        <Grid
          item
          xs={12}
          sm={6}
          md={4}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <TextField
            // sx={{ width: 250 }}
            id="standard-basic"
            label="Pin Code"
            variant="standard"
            {...register("pincode")}
            error={!!errors.pincode}
            helperText={errors?.pincode ? errors.pincode.message : null}
          />
        </Grid>

        <Grid
          item
          xs={12}
          sm={6}
          md={4}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <TextField
            disabled={user ? true : false}
            InputLabelProps={{ shrink: user ? true : false }}
            // sx={{ width: 250 }}
            id="standard-basic"
            label="Email Id"
            variant="standard"
            {...register("email")}
            error={!!errors.email}
            helperText={errors?.email ? errors.email.message : null}
          />
        </Grid>
      </Grid>
    </Box>
  )
}

export default Form
