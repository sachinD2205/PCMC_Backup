import React from "react";

const Index = () => {
  return (
    <div style={{ color: "white" }}>
      <h1 style={{ textTransform: "uppercase" }}>
        StreetVendor Management System Dashboard
      </h1>
    </div>
  );
};

export default Index;
