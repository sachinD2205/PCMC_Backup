import { yupResolver } from "@hookform/resolvers/yup";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import BabyChangingStationIcon from "@mui/icons-material/BabyChangingStation";
import BrandingWatermarkIcon from "@mui/icons-material/BrandingWatermark";
import Check from "@mui/icons-material/Check";
import HomeIcon from "@mui/icons-material/Home";
import PermIdentityIcon from "@mui/icons-material/PermIdentity";
import UploadFileIcon from "@mui/icons-material/UploadFile";
import VideoLabelIcon from "@mui/icons-material/VideoLabel";
import {
  Button,
  Grid,
  Paper,
  Stack,
  Step,
  StepLabel,
  Stepper,
  ThemeProvider,
  Typography,
} from "@mui/material";
import StepConnector, {
  stepConnectorClasses,
} from "@mui/material/StepConnector";
import { styled } from "@mui/material/styles";
import axios from "axios";
import moment from "moment";
import { useRouter } from "next/router";
import PropTypes from "prop-types";
import React, { useEffect, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { useDispatch } from "react-redux";
import sweetAlert from "sweetalert";
import AadharAuthentication from "../../../../components/streetVendorManagementSystem/components/AadharAuthentication";
import AdditionalDetails from "../../../../components/streetVendorManagementSystem/components/AdditionalDetails";
import AddressOfHawker from "../../../../components/streetVendorManagementSystem/components/AddressOfHawker";
import BasicApplicationDetails from "../../../../components/streetVendorManagementSystem/components/BasicApplicationDetails";
import DocumentsUpload from "../../../../components/streetVendorManagementSystem/components/DocumentsUpload";
import HawkerDetails from "../../../../components/streetVendorManagementSystem/components/HawkerDetails";
import PropertyAndWaterTaxes from "../../../../components/streetVendorManagementSystem/components/PropertyAndWaterTaxes";
// import BasicApplicationDetailsSchema from "../../../../components/streetVendorManagementSystem/schema/BasicApplicationDetailsSchema";
import {
  AddressOfHawkerSchema,
  BasicApplicationDetailsSchema,
  HawkerDetailsSchema,
} from "../../../../components/streetVendorManagementSystem/schema/issuanceOfHawkerLicenseSchema";
import FormattedLabel from "../../../../containers/reuseableComponents/FormattedLabel";
import theme from "../../../../theme.js";
import urls from "../../../../URLS/urls";
// import AddressOfHawkerSchema from "../../../../components/streetVendorManagementSystem/schema/AddressOfHawkerSchema";
// import HawkerDetailsSchema from "../../../../components/streetVendorManagementSystem/schema/HawkerDetailsSchema";
const QontoStepIconRoot = styled("div")(({ theme, ownerState }) => ({
  color: theme.palette.mode === "dark" ? theme.palette.grey[700] : "#eaeaf0",
  display: "flex",
  height: 22,
  alignItems: "center",
  ...(ownerState.active && {
    color: "#784af4",
  }),
  "& .QontoStepIcon-completedIcon": {
    color: "#784af4",
    zIndex: 1,
    fontSize: 18,
  },
  "& .QontoStepIcon-circle": {
    width: 8,
    height: 8,
    borderRadius: "50%",
    backgroundColor: "currentColor",
  },
}));

function QontoStepIcon(props) {
  const { active, completed, className } = props;

  return (
    <QontoStepIconRoot ownerState={{ active }} className={className}>
      {completed ? (
        <Check className='QontoStepIcon-completedIcon' />
      ) : (
        <div className='QontoStepIcon-circle' />
      )}
    </QontoStepIconRoot>
  );
}

QontoStepIcon.propTypes = {
  /**
   * Whether this step is active.
   * @default false
   */
  active: PropTypes.bool,
  className: PropTypes.string,
  /**
   * Mark the step as completed. Is passed to child components.
   * @default false
   */
  completed: PropTypes.bool,
};

const ColorlibConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 22,
  },
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage:
        "linear-gradient( 95deg,rgb(100,255,253,1) 0%,rgb(93,99,252,1) 50%,rgb(16,21,145,1) 100%)",
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage:
        "linear-gradient( 95deg,rgb(100,255,253,1) 0%,rgb(93,99,252,1) 50%,rgb(16,21,145,1) 100%)",
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor:
      theme.palette.mode === "dark" ? theme.palette.grey[800] : "#eaeaf0",
    borderRadius: 1,
  },
}));

const ColorlibStepIconRoot = styled("div")(({ theme, ownerState }) => ({
  backgroundColor:
    theme.palette.mode === "dark" ? theme.palette.grey[700] : "#ccc",
  zIndex: 1,
  color: "#fff",
  width: 50,
  height: 50,
  display: "flex",
  borderRadius: "50%",
  justifyContent: "center",
  alignItems: "center",
  ...(ownerState.active && {
    // background: rgb(9,32,121),
    // background: linear-gradient(90deg, rgba(9,32,121,1) 1%, rgba(0,212,255,1) 76%);
    backgroundImage:
      "linear-gradient(90deg, rgba(58,81,180,1) 0%, rgba(29,162,253,1) 68%, rgba(69,252,243,0.9700922605370274) 100%)",
    // "radial-gradient(circle, rgba(100,255,250,1) 11%, rgba(16,21,145,1) 100%)",
    boxShadow: "0 4px 10px 0 rgba(0,0,0,.25)",
  }),
  ...(ownerState.completed && {
    backgroundImage:
      "linear-gradient(90deg, rgba(58,81,180,1) 0%, rgba(29,162,253,1) 68%, rgba(69,252,243,0.9700922605370274) 100%)",
  }),
}));

function ColorlibStepIcon(props) {
  const { active, completed, className } = props;

  const icons = {
    // 1: <SettingsIcon />,
    1: <PermIdentityIcon />,
    2: <BabyChangingStationIcon />,
    3: <HomeIcon />,
    4: <BrandingWatermarkIcon />,
    5: <VideoLabelIcon />,
    6: <AddCircleIcon />,
    7: <UploadFileIcon />,
  };

  return (
    <ColorlibStepIconRoot
      ownerState={{ completed, active }}
      className={className}
    >
      {icons[String(props.icon)]}
    </ColorlibStepIconRoot>
  );
}

ColorlibStepIcon.propTypes = {
  /**
   * Whether this step is active.
   * @default false
   */
  active: PropTypes.bool,
  className: PropTypes.string,
  /**
   * Mark the step as completed. Is passed to child components.
   * @default false
   */
  completed: PropTypes.bool,
  /**
   * The label displayed in the step icon.
   */
  icon: PropTypes.node,
};

// Get steps - Name
function getSteps(i) {
  return [
    <strong key={1}>
      {<FormattedLabel id='basicApplicationDetails' key={1} />}
    </strong>,
    <strong key={1}>{<FormattedLabel id='hawkerDetails' />}</strong>,
    <strong key={2}>{<FormattedLabel id='addressOfHawker' />}</strong>,
    <strong key={3}>{<FormattedLabel id='aadharAuthentication' />}</strong>,
    <strong key={4}>{<FormattedLabel id='PropertyAndWaterTaxes' />}</strong>,
    <strong key={5}>
      {<FormattedLabel id='additionalDetails' key={5} />}
    </strong>,
    <strong key={6}>{<FormattedLabel id='documentsUpload' key={6} />}</strong>,
  ];
}

// Get Step Content Form
function getStepContent(step) {
  switch (step) {
    case 0:
      return <BasicApplicationDetails key={1} />;

    case 1:
      return <HawkerDetails key={2} />;

    case 2:
      return <AddressOfHawker key={3} />;

    case 3:
      return <AadharAuthentication key={4} />;

    case 4:
      return <PropertyAndWaterTaxes key={5} />;

    case 5:
      return <AdditionalDetails key={6} />;

    case 6:
      return <DocumentsUpload key={7} />;

    default:
      return "unknown step";
  }
}

// Linear Stepper - sachin
const LinaerStepper = () => {
  const methods = useForm();
  const [dataValidation, setDataValidation] = useState(
    BasicApplicationDetailsSchema,
  );

  const [activeStep, setActiveStep] = useState(0);
  // Const
  const steps = getSteps();
  const dispach = useDispatch();

  useEffect(() => {
    console.log("steps", activeStep);
    if (activeStep == "0") {
      setDataValidation(BasicApplicationDetailsSchema);
    } else if (activeStep == "1") {
      setDataValidation(HawkerDetailsSchema);
    } else if (activeStep == "2") {
      setDataValidation(AddressOfHawkerSchema);
    }
  }, [activeStep]);

  const router = useRouter();

  // Handle Next
  const handleNext = (data) => {
    console.log("activeStep", activeStep);
    // dispach(addIsssuanceofHawkerLicense(data));
    console.log(data);
    if (activeStep == steps.length - 1) {
      axios
        .post(
          `${urls.HMSURL}/IssuanceofHawkerLicense/saveIssuanceOfHawkerLicense`,
          data,
          {
            headers: {
              role: "CITIZEN",
            },
          },
        )
        .then((res) => {
          if (res.status == 200) {
            data.id
              ? sweetAlert(
                  "Updated!",
                  "Record Updated successfully !",
                  "success",
                )
              : sweetAlert(
                  "Submitted !",
                  "Application Form  successfully Submitted !!!",
                  "success",
                );
            router.push(`/dashboard`);
          }
        });
    } else {
      setActiveStep(activeStep + 1);
    }
  };

  // Handle Back
  const handleBack = () => {
    setActiveStep(activeStep - 1);
  };

  // View
  return (
    <>
      <div style={{ backgroundColor: "white" }}>
        <ThemeProvider theme={theme}>
          <Paper
            square
            sx={{
              // margin: 5,
              padding: 1,
              // paddingTop: 5,
              paddingTop: 5,
              paddingBottom: 5,
              backgroundColor: "white",
            }}
            elevation={5}
          >
            <marquee>
              <Typography
                variant='h5'
                style={{
                  textAlign: "center",
                  justifyContent: "center",
                  marginTop: "2px",
                }}
              >
                <strong>
                  {<FormattedLabel id='streetVendorManagmentSystem' />}
                </strong>
              </Typography>
            </marquee>
            <br /> <br />
            <br />
            <Grid container>
              <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
                <Stack sx={{ width: "100%" }} spacing={4}>
                  <Stepper
                    alternativeLabel
                    activeStep={activeStep}
                    connector={<ColorlibConnector />}
                  >
                    {steps.map((label) => {
                      const labelProps = {};
                      const stepProps = {};

                      return (
                        <Step key={label} {...stepProps}>
                          <StepLabel
                            // error={true}
                            {...labelProps}
                            StepIconComponent={ColorlibStepIcon}
                          >
                            {label}
                          </StepLabel>
                        </Step>
                      );
                    })}
                  </Stepper>
                </Stack>
              </Grid>
            </Grid>
            <FormProvider {...methods}>
              <form
                onSubmit={methods.handleSubmit(handleNext)}
                sx={{ marginTop: 10 }}
              >
                <div id='issuanceOfHawkerLicensePDFContent'>
                  {getStepContent(activeStep)}
                </div>
                <Stack
                  direction='row'
                  sx={{ paddingLeft: "30px", align: "center" }}
                >
                  <Button
                    disabled={activeStep === 0}
                    // disabled
                    onClick={handleBack}
                    variant='contained'
                    sx={{
                      marginRight: "40px",
                      marginLeft: "40px",
                    }}
                  >
                    {<FormattedLabel id='back' />}
                  </Button>
                  <Button variant='contained' type='submit'>
                    {activeStep === steps.length - 1 ? (
                      <FormattedLabel id='finish' />
                    ) : (
                      <FormattedLabel id='saveAndNext' />
                    )}
                  </Button>
                </Stack>
              </form>
            </FormProvider>
          </Paper>
        </ThemeProvider>
      </div>
    </>
  );
};

export default LinaerStepper;
